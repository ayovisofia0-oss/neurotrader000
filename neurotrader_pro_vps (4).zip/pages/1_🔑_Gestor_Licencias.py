"""
NEUROTRADER PRO — Gestor de Licencias
Licencias vinculadas al correo del cliente: semanal, mensual, vitalicio.
"""
import streamlit as st
import json
import os
import random
import string
import calendar
from datetime import datetime, date, timedelta
from typing import Optional

st.set_page_config(
    page_title="Gestor de Licencias — NeuroTrader",
    page_icon="🔑",
    layout="wide",
)

LICENCIAS_FILE = "licencias.json"
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "neurotrader2007")

MESES_ES = [
    "Enero","Febrero","Marzo","Abril","Mayo","Junio",
    "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"
]

# ─── ESTILOS ──────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@400;500;600;700&display=swap');
html,body,.stApp{
    background:radial-gradient(ellipse at 20% 50%,#0d1b2a,#0a0c15 60%,#060810)!important;
    font-family:'Rajdhani',sans-serif;
}
section[data-testid="stSidebar"]{
    background:linear-gradient(180deg,#0d1520,#0a0e1a)!important;
    border-right:1px solid rgba(0,163,255,.2);
}
.title-glow{
    font-family:'Orbitron',monospace;font-size:1.9rem;font-weight:900;
    background:linear-gradient(135deg,#00a3ff,#00ffcc 50%,#0066ff);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:3px;
}
.stat-box{
    background:linear-gradient(145deg,#1a2035,#0f1628);
    border-radius:10px;padding:16px;text-align:center;
    border:1px solid rgba(0,163,255,.2);
}
.stat-num{font-size:2rem;font-weight:700;}
.stat-lbl{font-size:.72rem;color:rgba(150,180,220,.7);letter-spacing:2px;}
.card{
    background:linear-gradient(145deg,#151e30,#0f1525);
    border-radius:12px;padding:16px 20px;margin:7px 0;
    border:1px solid rgba(0,163,255,.14);
}
.card.active  {border-color:rgba(0,255,136,.3);}
.card.expired {border-color:rgba(255,75,75,.3);}
.card.inactive{border-color:rgba(180,180,180,.15);}
.code-big{
    font-family:'Orbitron',monospace;font-size:1.5rem;
    color:#00ffcc;letter-spacing:4px;font-weight:700;
    background:#0a1520;border:2px solid rgba(0,255,200,.35);
    border-radius:10px;padding:14px 20px;display:inline-block;
    margin:8px 0;width:100%;text-align:center;
}
.code-sm{font-family:'Orbitron',monospace;font-size:.9rem;color:#00a3ff;letter-spacing:2px;}
.plan-badge{
    display:inline-block;padding:2px 10px;border-radius:20px;
    font-size:.7rem;font-weight:700;letter-spacing:1px;
}
.plan-semanal  {background:rgba(0,200,255,.15);color:#00c8ff;}
.plan-mensual  {background:rgba(160,100,255,.15);color:#a064ff;}
.plan-vitalicio{background:rgba(0,255,136,.15);color:#00ff88;}
.badge-act{color:#00ff88;font-weight:700;}
.badge-exp{color:#ff4b4b;font-weight:700;}
.badge-ina{color:#888;font-weight:700;}
</style>
""", unsafe_allow_html=True)

# ─── HELPERS ──────────────────────────────────────────────────────────────────

def cargar() -> dict:
    if os.path.exists(LICENCIAS_FILE):
        try:
            with open(LICENCIAS_FILE, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def guardar(data: dict) -> bool:
    try:
        with open(LICENCIAS_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        st.error(f"Error al guardar: {e}")
        return False


def gen_codigo() -> str:
    chars = string.ascii_uppercase + string.digits
    return '-'.join(''.join(random.choices(chars, k=4)) for _ in range(3))


def estado_lic(lic: dict) -> str:
    if not lic.get('active', True):
        return 'inactive'
    exp = lic.get('expires')
    if exp:
        try:
            if datetime.now() > datetime.fromisoformat(exp):
                return 'expired'
        except Exception:
            pass
    return 'active'


def dias_restantes(exp_str: Optional[str]) -> Optional[int]:
    if not exp_str:
        return None
    try:
        return (datetime.fromisoformat(exp_str) - datetime.now()).days
    except Exception:
        return None


def ultimo_dia_mes(anio: int, mes: int) -> date:
    return date(anio, mes, calendar.monthrange(anio, mes)[1])


def badge_plan(plan: str) -> str:
    return {
        'semanal':   '<span class="plan-badge plan-semanal">SEMANAL</span>',
        'mensual':   '<span class="plan-badge plan-mensual">MENSUAL</span>',
        'vitalicio': '<span class="plan-badge plan-vitalicio">VITALICIO</span>',
    }.get(plan, f'<span class="plan-badge" style="background:rgba(255,255,255,.07);color:#aaa">{plan or "—"}</span>')


def licencias_de_email(email: str, lics: dict) -> list:
    em = email.strip().lower()
    return [
        {'codigo': c, **l}
        for c, l in lics.items()
        if l.get('email', '').strip().lower() == em
    ]


def licencia_activa_de(email: str, lics: dict) -> Optional[dict]:
    activas = [
        l for l in licencias_de_email(email, lics)
        if estado_lic(l) == 'active'
    ]
    if not activas:
        return None
    return sorted(activas, key=lambda x: x.get('creado', ''), reverse=True)[0]


def emails_registrados(lics: dict) -> list:
    emails = set()
    for l in lics.values():
        em = l.get('email', '').strip().lower()
        if em:
            emails.add(em)
    return sorted(emails)


# ─── AUTENTICACIÓN ────────────────────────────────────────────────────────────
if 'lic_auth' not in st.session_state:
    st.session_state.lic_auth = False

if not st.session_state.lic_auth:
    st.markdown('<p class="title-glow">🔑 GESTOR DE LICENCIAS</p>', unsafe_allow_html=True)
    st.markdown("---")
    _, col_c, _ = st.columns([1, 2, 1])
    with col_c:
        st.markdown("### Acceso de Administrador")
        pwd = st.text_input("Contraseña", type="password", key="pwd_input")
        if st.button("INGRESAR", use_container_width=True, type="primary"):
            if pwd == ADMIN_PASSWORD:
                st.session_state.lic_auth = True
                st.rerun()
            else:
                st.error("Contraseña incorrecta")
    st.stop()

# ─── SIDEBAR ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<p style="font-family:Orbitron,monospace;color:#00a3ff;font-size:.9rem;letter-spacing:2px">🔑 LICENCIAS</p>', unsafe_allow_html=True)
    st.caption("✅ Sesión activa")
    if st.button("Cerrar sesión", use_container_width=True):
        st.session_state.lic_auth = False
        st.rerun()
    st.markdown("---")
    st.caption(f"Archivo: `{LICENCIAS_FILE}`")
    st.caption("Admin: var env `ADMIN_PASSWORD`")

# ─── CARGA DE DATOS ───────────────────────────────────────────────────────────
lics = cargar()
emails = emails_registrados(lics)

# Solo licencias con correo registrado para métricas
lics_con_email = {c: l for c, l in lics.items() if l.get('email')}
activas_cnt   = sum(1 for l in lics_con_email.values() if estado_lic(l) == 'active')
expiradas_cnt = sum(1 for l in lics_con_email.values() if estado_lic(l) == 'expired')
vitalicias_cnt= sum(1 for l in lics_con_email.values() if l.get('plan') == 'vitalicio' and estado_lic(l) == 'active')

# ─── ENCABEZADO ───────────────────────────────────────────────────────────────
st.markdown('<p class="title-glow">🔑 GESTOR DE LICENCIAS</p>', unsafe_allow_html=True)
st.markdown('<div style="color:rgba(0,163,255,.5);font-size:.72rem;letter-spacing:4px;margin-bottom:18px">NEUROTRADER PRO — ADMINISTRACIÓN</div>', unsafe_allow_html=True)

for col, num, lbl, color in zip(
    st.columns(4),
    [len(emails), activas_cnt, expiradas_cnt, vitalicias_cnt],
    ["CLIENTES", "ACTIVAS", "EXPIRADAS", "VITALICIAS"],
    ["#00a3ff", "#00ff88", "#ff4b4b", "#a064ff"],
):
    with col:
        st.markdown(
            f'<div class="stat-box"><div class="stat-num" style="color:{color}">{num}</div>'
            f'<div class="stat-lbl">{lbl}</div></div>',
            unsafe_allow_html=True
        )

st.markdown("---")

# ══════════════════════════════════════════════════════════════════════════════
# PESTAÑAS
# ══════════════════════════════════════════════════════════════════════════════
tab_nueva, tab_clientes, tab_renovar, tab_eliminar = st.tabs([
    "➕  NUEVA LICENCIA",
    "👥  MIS CLIENTES",
    "🔄  RENOVAR",
    "🗑️  ELIMINAR",
])


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — NUEVA LICENCIA
# ══════════════════════════════════════════════════════════════════════════════
with tab_nueva:
    st.markdown("### Crear licencia para cliente")

    # Si acaba de crearse una licencia, mostrarla prominentemente
    if st.session_state.get('lic_creada'):
        datos = st.session_state.lic_creada
        st.success("✅ Licencia creada correctamente")
        st.markdown(
            f'<div style="background:#071520;border:2px solid rgba(0,255,200,.4);'
            f'border-radius:12px;padding:20px 24px;margin:10px 0;">'
            f'<div style="font-size:.7rem;color:rgba(0,255,200,.6);letter-spacing:3px;margin-bottom:8px">CÓDIGO DE ACCESO — ENTREGAR AL CLIENTE</div>'
            f'<div class="code-big">{datos["codigo"]}</div>'
            f'<div style="font-size:.85rem;color:rgba(180,220,255,.8);margin-top:12px">'
            f'📧 Correo: <b>{datos["email"]}</b><br>'
            f'{badge_plan(datos["plan"])} &nbsp; '
            f'{"⏳ Vence: <b>" + datos["expires"] + "</b>" if datos["expires"] else "♾️ <b>Vitalicio</b>"}'
            f'</div></div>',
            unsafe_allow_html=True
        )
        st.info("💡 Este código solo funciona con el correo registrado. El cliente lo ingresa en el bot junto con su correo y contraseña de IQ Option.")
        if st.button("➕ Crear otra licencia", use_container_width=True):
            del st.session_state['lic_creada']
            st.rerun()
        st.stop()

    # ── Formulario de creación ─────────────────────────────────────────────
    col_izq, col_der = st.columns([3, 2])

    with col_izq:
        email_nuevo = st.text_input(
            "📧 Correo del cliente (IQ Option)",
            placeholder="correo@ejemplo.com",
            key="email_nuevo_input",
        )

        # Advertencia si ya tiene licencia activa
        if email_nuevo and '@' in email_nuevo:
            lic_existente = licencia_activa_de(email_nuevo.strip().lower(), lics)
            if lic_existente:
                st.warning(
                    f"⚠️ Este cliente ya tiene una licencia activa: "
                    f"`{lic_existente['codigo']}` "
                    f"({lic_existente.get('plan','').upper()}). "
                    f"Usa la pestaña **🔄 RENOVAR** para cambiar su plan."
                )

        st.markdown("**Plan de licencia**")
        plan_nuevo = st.radio(
            "Plan",
            ["Semanal (7 días)", "Mensual", "Vitalicio"],
            horizontal=True,
            label_visibility="collapsed",
            key="plan_radio",
        )

        hoy = date.today()
        fecha_expiry = None

        if plan_nuevo == "Semanal (7 días)":
            fecha_expiry = hoy + timedelta(days=7)
            st.info(f"📅 Vence el **{fecha_expiry.strftime('%d/%m/%Y')}** (7 días desde hoy)")

        elif plan_nuevo == "Mensual":
            st.markdown("**¿Hasta qué mes debe estar vigente?**")
            col_m, col_y = st.columns(2)
            with col_m:
                mes_sel = st.selectbox(
                    "Mes",
                    range(1, 13),
                    format_func=lambda m: MESES_ES[m - 1],
                    index=hoy.month - 1,
                    key="mes_sel",
                )
            with col_y:
                anio_sel = st.selectbox(
                    "Año",
                    [hoy.year, hoy.year + 1],
                    index=0,
                    key="anio_sel",
                )
            fecha_expiry = ultimo_dia_mes(anio_sel, mes_sel)
            st.info(f"📅 Vence el **{fecha_expiry.strftime('%d/%m/%Y')}** (fin de {MESES_ES[mes_sel-1]} {anio_sel})")

        else:
            st.info("♾️ Sin fecha de vencimiento — acceso permanente")

        st.markdown("")

        if st.button("⚡ GENERAR LICENCIA", use_container_width=True, type="primary"):
            email_limpio = email_nuevo.strip().lower() if email_nuevo else ''
            if not email_limpio or '@' not in email_limpio:
                st.error("Ingresa un correo válido.")
            else:
                lic_act = licencia_activa_de(email_limpio, lics)
                if lic_act:
                    st.error(
                        f"Este cliente ya tiene licencia activa ({lic_act['codigo']}). "
                        f"Ve a la pestaña **🔄 RENOVAR** para actualizarla."
                    )
                else:
                    # Generar código único
                    nuevo_cod = gen_codigo()
                    while nuevo_cod in lics:
                        nuevo_cod = gen_codigo()

                    plan_key = {
                        "Semanal (7 días)": "semanal",
                        "Mensual":          "mensual",
                        "Vitalicio":        "vitalicio",
                    }[plan_nuevo]

                    lics[nuevo_cod] = {
                        'email':       email_limpio,
                        'plan':        plan_key,
                        'active':      True,
                        'expires':     fecha_expiry.isoformat() if fecha_expiry else None,
                        'creado':      datetime.now().strftime('%Y-%m-%d %H:%M'),
                        'descripcion': '',
                        'renovaciones': 0,
                    }
                    if guardar(lics):
                        st.session_state['lic_creada'] = {
                            'codigo':  nuevo_cod,
                            'email':   email_limpio,
                            'plan':    plan_key,
                            'expires': fecha_expiry.strftime('%d/%m/%Y') if fecha_expiry else None,
                        }
                        st.rerun()

    with col_der:
        st.markdown("#### Planes disponibles")
        st.markdown("""
<div class="card" style="margin-bottom:8px">
  <span class="plan-badge plan-semanal">SEMANAL</span><br><br>
  <div style="color:rgba(180,210,240,.85);font-size:.88rem">
    Vence <b>7 días</b> después de la creación.<br>Ideal para prueba o acceso corto.
  </div>
</div>
<div class="card" style="margin-bottom:8px">
  <span class="plan-badge plan-mensual">MENSUAL</span><br><br>
  <div style="color:rgba(180,210,240,.85);font-size:.88rem">
    Tú eliges el <b>mes exacto</b> de vencimiento.<br>
    Caduca el último día del mes seleccionado.<br>
    Sirve para planes mensuales <i>o</i> anuales.
  </div>
</div>
<div class="card">
  <span class="plan-badge plan-vitalicio">VITALICIO</span><br><br>
  <div style="color:rgba(180,210,240,.85);font-size:.88rem">
    Sin fecha de vencimiento.<br>Acceso permanente hasta que lo desactives.
  </div>
</div>
""", unsafe_allow_html=True)
        st.markdown("---")
        st.info("El cliente ingresa exactamente su **correo de IQ Option** + el **código** generado para acceder al bot.")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — MIS CLIENTES
# ══════════════════════════════════════════════════════════════════════════════
with tab_clientes:
    st.markdown("### Registro de clientes")

    col_bus, col_fil, col_ref = st.columns([3, 2, 1])
    with col_bus:
        buscar_cli = st.text_input("", placeholder="Buscar por correo…", label_visibility="collapsed", key="bus_cli")
    with col_fil:
        filtro_cli = st.selectbox("", ["Todos", "Con licencia activa", "Expiradas", "Sin licencia activa"],
                                  label_visibility="collapsed", key="fil_cli")
    with col_ref:
        if st.button("↻", use_container_width=True, key="ref_cli"):
            st.rerun()

    if not emails:
        st.info("Aún no hay clientes registrados. Crea la primera licencia en la pestaña ➕.")
    else:
        filtrados = []
        for em in emails:
            if buscar_cli and buscar_cli.lower() not in em:
                continue
            lic_act = licencia_activa_de(em, lics)
            hist = licencias_de_email(em, lics)
            if filtro_cli == "Con licencia activa" and not lic_act:
                continue
            if filtro_cli == "Sin licencia activa" and lic_act:
                continue
            if filtro_cli == "Expiradas" and not any(estado_lic(l) == 'expired' for l in hist):
                continue
            filtrados.append(em)

        st.caption(f"Mostrando {len(filtrados)} de {len(emails)} clientes")
        st.markdown("")

        for _idx_em, em in enumerate(filtrados):
            lic_act = licencia_activa_de(em, lics)
            hist = sorted(licencias_de_email(em, lics), key=lambda x: x.get('creado',''), reverse=True)

            if lic_act:
                est = 'active'
                dias = dias_restantes(lic_act.get('expires'))
                if dias is None:
                    venc_txt = "♾️ Vitalicio"
                elif dias > 1:
                    venc_txt = f"Vence en {dias} días"
                elif dias == 1:
                    venc_txt = "⚠️ Vence mañana"
                elif dias == 0:
                    venc_txt = "⚠️ Vence hoy"
                else:
                    venc_txt = f"Expiró hace {abs(dias)} días"
                titulo = f"📧 {em}  —  {badge_plan(lic_act.get('plan',''))}  {venc_txt}"
            else:
                est = 'inactive'
                titulo = f"📧 {em}  —  Sin licencia activa"

            with st.expander(titulo, expanded=False):
                col_a, col_b = st.columns([3, 1])
                with col_a:
                    if lic_act:
                        st.markdown(
                            f'<div style="margin-bottom:6px">{badge_plan(lic_act.get("plan",""))}'
                            f' <span class="badge-act">✅ ACTIVA</span></div>'
                            f'<div class="code-sm">{lic_act["codigo"]}</div>'
                            f'<div style="font-size:.75rem;color:rgba(120,160,200,.6);margin-top:4px">'
                            f'Creado: {lic_act.get("creado","")[:10]}'
                            f'{" | Vence: " + lic_act["expires"][:10] if lic_act.get("expires") else " | Sin vencimiento"}'
                            f'</div>',
                            unsafe_allow_html=True
                        )
                    else:
                        st.markdown('<div style="color:#888">Sin licencia activa</div>', unsafe_allow_html=True)

                with col_b:
                    if st.button("🔄 Renovar", key=f"ren_{em}", use_container_width=True, type="primary"):
                        st.session_state['renovar_email'] = em
                        st.rerun()

                # Historial
                if len(hist) > 1:
                    st.markdown("**Historial de licencias:**")
                    for h in hist:
                        hest = estado_lic(h)
                        color_e = {'active':'#00ff88','expired':'#ff4b4b','inactive':'#888'}[hest]
                        st.markdown(
                            f'<div style="display:flex;gap:10px;align-items:center;padding:4px 0;'
                            f'border-bottom:1px solid rgba(255,255,255,.04);font-size:.78rem;'
                            f'color:rgba(180,200,240,.65)">'
                            f'<span class="code-sm" style="font-size:.72rem">{h["codigo"]}</span>'
                            f'{badge_plan(h.get("plan",""))}'
                            f'<span style="color:{color_e}">{hest.upper()}</span>'
                            f'<span style="margin-left:auto">{h.get("creado","")[:10]}</span>'
                            f'</div>',
                            unsafe_allow_html=True
                        )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — RENOVAR
# ══════════════════════════════════════════════════════════════════════════════
with tab_renovar:
    st.markdown("### Renovar licencia de cliente")

    if st.session_state.get('ren_creada'):
        datos_r = st.session_state.ren_creada
        st.success("✅ Renovación generada correctamente — licencia anterior desactivada")
        st.markdown(
            f'<div style="background:#071520;border:2px solid rgba(0,255,200,.4);'
            f'border-radius:12px;padding:20px 24px;margin:10px 0;">'
            f'<div style="font-size:.7rem;color:rgba(0,255,200,.6);letter-spacing:3px;margin-bottom:8px">NUEVO CÓDIGO — ENTREGAR AL CLIENTE</div>'
            f'<div class="code-big">{datos_r["codigo"]}</div>'
            f'<div style="font-size:.85rem;color:rgba(180,220,255,.8);margin-top:12px">'
            f'📧 {datos_r["email"]}<br>'
            f'{badge_plan(datos_r["plan"])} &nbsp; '
            f'{"⏳ Vence: <b>" + datos_r["expires"] + "</b>" if datos_r["expires"] else "♾️ <b>Vitalicio</b>"}'
            f'</div></div>',
            unsafe_allow_html=True
        )
        if st.button("↩ Volver a renovar otro cliente", use_container_width=True):
            del st.session_state['ren_creada']
            st.session_state.pop('renovar_email', None)
            st.rerun()
        st.stop()

    if not emails:
        st.info("Aún no hay clientes. Crea la primera licencia en la pestaña ➕.")
        st.stop()

    email_pre = st.session_state.get('renovar_email', emails[0] if emails else '')
    idx_pre   = emails.index(email_pre) if email_pre in emails else 0

    email_ren = st.selectbox("📧 Cliente a renovar", emails, index=idx_pre, key="sel_ren")

    lic_actual = licencia_activa_de(email_ren, lics)
    st.markdown("---")

    col_act, col_new = st.columns(2)

    with col_act:
        st.markdown("**Licencia actual:**")
        if lic_actual:
            est_c = estado_lic(lic_actual)
            badge_e = f'<span class="badge-act">✅ ACTIVA</span>' if est_c == 'active' else f'<span class="badge-exp">❌ EXPIRADA</span>'
            st.markdown(
                f'<div class="card {est_c}">'
                f'<div style="margin-bottom:6px">{badge_plan(lic_actual.get("plan",""))} {badge_e}</div>'
                f'<div class="code-sm">{lic_actual["codigo"]}</div>'
                f'<div style="font-size:.75rem;color:rgba(120,160,200,.6);margin-top:6px">'
                f'Creado: {lic_actual.get("creado","")[:10]}<br>'
                f'{"Vence: " + lic_actual["expires"][:10] if lic_actual.get("expires") else "Sin vencimiento"}'
                f'</div></div>',
                unsafe_allow_html=True
            )
        else:
            st.info("Sin licencia activa.")

    with col_new:
        st.markdown("**Nuevo plan:**")
        plan_ren = st.radio(
            "Plan renovación",
            ["Semanal (7 días)", "Mensual", "Vitalicio"],
            key="plan_ren_radio",
            label_visibility="collapsed",
        )

        hoy = date.today()
        fecha_ren = None

        if plan_ren == "Semanal (7 días)":
            fecha_ren = hoy + timedelta(days=7)
            st.caption(f"Vence: {fecha_ren.strftime('%d/%m/%Y')}")

        elif plan_ren == "Mensual":
            col_rm, col_ry = st.columns(2)
            with col_rm:
                mes_ren = st.selectbox("Mes", range(1, 13),
                                       format_func=lambda m: MESES_ES[m - 1],
                                       index=hoy.month - 1, key="mes_ren")
            with col_ry:
                anio_ren = st.selectbox("Año", [hoy.year, hoy.year + 1],
                                        index=0, key="anio_ren")
            fecha_ren = ultimo_dia_mes(anio_ren, mes_ren)
            st.caption(f"Vence: {fecha_ren.strftime('%d/%m/%Y')} — fin de {MESES_ES[mes_ren-1]}")
        else:
            st.caption("♾️ Sin vencimiento")

    st.markdown("")

    if st.button("🔄 GENERAR RENOVACIÓN", use_container_width=True, type="primary"):
        plan_key_ren = {
            "Semanal (7 días)": "semanal",
            "Mensual":          "mensual",
            "Vitalicio":        "vitalicio",
        }[plan_ren]

        # Desactivar todas las licencias activas de este cliente
        for cod in list(lics.keys()):
            if lics[cod].get('email', '').strip().lower() == email_ren.strip().lower():
                lics[cod]['active'] = False

        # Crear nueva licencia
        nuevo_cod = gen_codigo()
        while nuevo_cod in lics:
            nuevo_cod = gen_codigo()

        hist_cnt = len(licencias_de_email(email_ren, lics))
        lics[nuevo_cod] = {
            'email':       email_ren.strip().lower(),
            'plan':        plan_key_ren,
            'active':      True,
            'expires':     fecha_ren.isoformat() if fecha_ren else None,
            'creado':      datetime.now().strftime('%Y-%m-%d %H:%M'),
            'descripcion': '',
            'renovaciones': hist_cnt,
        }

        if guardar(lics):
            st.session_state['ren_creada'] = {
                'codigo':  nuevo_cod,
                'email':   email_ren,
                'plan':    plan_key_ren,
                'expires': fecha_ren.strftime('%d/%m/%Y') if fecha_ren else None,
            }
            st.session_state.pop('renovar_email', None)
            st.rerun()

    st.markdown("---")
    if lics:
        st.download_button(
            "⬇️ Exportar todas las licencias (JSON)",
            data=json.dumps(lics, indent=2, ensure_ascii=False),
            file_name="licencias_backup.json",
            mime="application/json",
        )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — ELIMINAR
# ══════════════════════════════════════════════════════════════════════════════
with tab_eliminar:
    st.markdown("### Eliminar licencia")
    if not lics:
        st.info("No hay licencias registradas.")
        st.stop()

    opciones_cod = sorted(lics.keys())
    cod_del = st.selectbox(
        "Selecciona la licencia",
        opciones_cod,
        format_func=lambda c: f"{c} — {lics[c].get('email', 'sin correo')} — {lics[c].get('plan', '')}",
        key="cod_eliminar",
    )
    lic_del = lics[cod_del]
    st.warning("Esta acción elimina la licencia del archivo y no se puede deshacer desde el panel.")
    st.markdown(
        f"**Código:** `{cod_del}`  \n"
        f"**Correo:** `{lic_del.get('email', 'sin correo')}`  \n"
        f"**Plan:** `{lic_del.get('plan', '')}`  \n"
        f"**Estado:** `{estado_lic(lic_del)}`"
    )
    confirmar = st.text_input("Escribe ELIMINAR para confirmar", key="confirmar_eliminar")
    if st.button("🗑️ ELIMINAR LICENCIA", use_container_width=True, type="primary"):
        if confirmar.strip().upper() != "ELIMINAR":
            st.error("Confirmación incorrecta. Escribe ELIMINAR.")
        else:
            del lics[cod_del]
            if guardar(lics):
                st.success(f"Licencia {cod_del} eliminada correctamente.")
                st.rerun()
