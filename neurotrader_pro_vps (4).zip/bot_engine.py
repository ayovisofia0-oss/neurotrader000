"""
NEUROTRADER PRO - Motor de Análisis Avanzado
Motor IA con scoring multinivel, detección de régimen de mercado,
aprendizaje adaptativo por activo y estrategia, y validación doble.
"""
import time
import logging
import threading
import inspect
import json as _json
import os as _os
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import pytz
from collections import defaultdict, deque

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

ecuador = pytz.timezone("America/Guayaquil")

MAX_OPS_POR_HORA_POR_ACTIVO  = 3
MIN_SCORE_PARA_OPERAR       = 62   # Umbral de calidad — elevado para señales más robustas con 1 estrategia
MIN_SCORE_UNICA_ESTRATEGIA  = 62   # 1 estrategia pasa si supera este score + todos los filtros
MIN_SCORE_UNICA_CON_FLUJO   = 62   # compatibilidad — mismo umbral unificado
VENTANA_ENTRADA_INICIO_SEG  = 55   # Antes solo s59-s01; evita perder señales tomadas manualmente
VENTANA_ENTRADA_FIN_SEG     = 7
UMBRAL_CONFIANZA_ACTIVO     = 0.42  # Confianza histórica mínima del activo/estrategia
FUERZA_MINIMA               = 12   # Momentum mínimo
UMBRAL_PRESENAL             = 38   # Score para lista caliente
LOTE_ESCANEO                = 10   # Activos por lote
MAX_CONCURRENT_TRADES       =  2   # Operaciones simultáneas permitidas
PAUSA_ENTRE_LOTES           =  5   # Segundos de descanso entre lotes regulares
PAUSA_CALIENTES             =  1   # Segundos entre re-checks de activos calientes
PAUSA_TRAS_PERDIDAS         =  2   # Minutos de pausa después de N pérdidas
MAX_PERDIDAS_CONSECUTIVAS   =  2   # Número de pérdidas que activa la pausa
MAX_SCAN_WORKERS            =  6   # Hilos paralelos — 6 es suficiente y gentil con API
MFM_MINIMO_OTC              = 0.65
MFM_MINIMO_NORMAL           = 0.55
SR_TOLERANCIA_ATR           = 2.4   # Zona S/R amplia para calidad sin ser demasiado estricta
MARTINGALA_MAX_NIVEL        = 1     # Solo una recuperación; no escalar a nivel 2
VENCIMIENTO_MINUTOS         = 5
ACTIVOS_OTC_PERMITIDOS = {'EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'NZDUSD', 'USDCAD', 'EURJPY', 'GBPJPY', 'XAUUSD', 'USDCHF'}
ACTIVOS_NORMALES_PERMITIDOS = {'EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'NZDUSD', 'USDCAD', 'EURJPY', 'GBPJPY', 'XAUUSD', 'USDCHF'}
ESTRATEGIAS_PERMITIDAS = (
    'sop_res',
    'pinbar',
    'rechazo',
    'macd_cross',
    'rsi_rebote',
    'stoch_cross',
    'adx_fuerza',
    'vwap_pullback',
    'tendencia_5m',
)

# ─────────────────────────────────────────────
# PARES DE ALTA VOLATILIDAD — requieren filtro extra
# Estos pares se mueven bruscamente y generan falsos picos frecuentes.
# Se les aplica penalización de score y se exige mayor consenso.
# ─────────────────────────────────────────────
PARES_VOLATILES = {
    'AUDCAD', 'AUDNZD', 'NZDCAD', 'GBPAUD', 'GBPNZD', 'GBPCAD',
    'EURNZD', 'EURCAD', 'EURAUD', 'CADCHF', 'NZDCHF', 'NZDUSD',
    'AUDUSD', 'AUDJPY', 'NZDJPY', 'CADJPY',
}
# Penalización de score para pares volátiles (pts)
PENALIZACION_PAR_VOLATIL = 8
# En par volátil se exige mínimo 2 estrategias (no se permite 1 sola)
MIN_ESTRATEGIAS_PAR_VOLATIL = 2


def _asset_base(asset: str) -> str:
    a = str(asset or '').upper()
    a = a.replace('OTC ', '').replace('-OTC', '').replace('_OTC', '')
    a = a.replace('-OP', '').replace('_OP', '')
    return ''.join(ch for ch in a if ch.isalnum())[:6]


def _asset_api_symbol(asset: str) -> str:
    a = str(asset or '').upper().strip()
    a = a.replace('-OP', '').replace('_OP', '')
    return a


def _asset_es_otc(asset: str) -> bool:
    a = str(asset or '').upper()
    return 'OTC' in a


def _asset_permitido(asset: str) -> bool:
    base = _asset_base(asset)
    if _asset_es_otc(asset):
        return base in ACTIVOS_OTC_PERMITIDOS
    return base in ACTIVOS_NORMALES_PERMITIDOS


def _mfm_minimo_para_asset(asset: str) -> float:
    return MFM_MINIMO_OTC if _asset_es_otc(asset) else MFM_MINIMO_NORMAL

# ─────────────────────────────────────────────
# SISTEMA DE LICENCIAS
# ─────────────────────────────────────────────

LICENCIAS_FILE = "licencias.json"


def _cargar_licencias() -> dict:
    """Carga el archivo de licencias. Crea uno vacío si no existe."""
    if _os.path.exists(LICENCIAS_FILE):
        try:
            with open(LICENCIAS_FILE, 'r', encoding='utf-8') as f:
                return _json.load(f)
        except Exception:
            pass
    return {}


def validar_licencia(codigo: str, email: str = None) -> tuple:
    """
    Valida un código de licencia.
    Si se proporciona email, verifica que la licencia esté vinculada a ese correo.
    Retorna (valido: bool, mensaje: str).
    """
    codigo = codigo.strip().upper() if codigo else ""
    if not codigo:
        return False, "Código de licencia requerido"

    licencias = _cargar_licencias()
    if not licencias:
        return False, "No hay licencias registradas. Contacte al administrador."

    if codigo not in licencias:
        return False, f"Código '{codigo}' no válido"

    lic = licencias[codigo]
    if not lic.get('active', True):
        return False, "Licencia desactivada. Contacte al administrador."

    expires = lic.get('expires')
    if expires:
        try:
            exp_date = datetime.fromisoformat(expires)
            # Si el string es solo fecha (sin hora), expira al FINAL del día (23:59:59)
            # Evita que una licencia "2026-03-31" expire a las 00:00:01 del mismo día
            if 'T' not in expires and ':' not in expires:
                exp_date = exp_date.replace(hour=23, minute=59, second=59)
            if datetime.now() > exp_date:
                return False, f"Licencia expirada el {expires[:10]}"
        except Exception:
            pass

    # Verificar email si la licencia tiene uno vinculado
    lic_email = lic.get('email', '').strip().lower()
    if lic_email and email:
        if email.strip().lower() != lic_email:
            return False, "Este código no corresponde al correo ingresado"

    plan = lic.get('plan', '')
    plan_txt = {'semanal': 'Plan Semanal', 'mensual': 'Plan Mensual', 'vitalicio': 'Plan Vitalicio'}.get(plan, 'acceso completo')
    return True, f"Licencia válida — {plan_txt}"


def crear_licencia(codigo: str, descripcion: str = '', expires: str = None) -> bool:
    """
    Crea o actualiza una licencia en el archivo.
    expires: fecha ISO 'YYYY-MM-DD' o None (sin expiración).
    Retorna True si se guardó correctamente.
    """
    licencias = _cargar_licencias()
    licencias[codigo.strip().upper()] = {
        'active':      True,
        'descripcion': descripcion,
        'expires':     expires,
        'creado':      datetime.now().isoformat()[:19],
    }
    try:
        with open(LICENCIAS_FILE, 'w', encoding='utf-8') as f:
            _json.dump(licencias, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


class AdaptiveMemory:
    """
    Motor de aprendizaje adaptativo — aprende de cada operación y mejora con el tiempo.

    Dimensiones de aprendizaje:
      - win_rate por activo         (últimas 25 operaciones)
      - win_rate por estrategia
      - win_rate por combo activo+estrategia
      - win_rate por régimen de mercado (BULL/BEAR/SIDEWAYS)
      - win_rate por dirección (CALL/PUT) por activo
      - Ajuste dinámico por racha de victorias/pérdidas recientes
    """
    def __init__(self, ventana=25):
        self.ventana = ventana
        self.historial_asset        = defaultdict(lambda: deque(maxlen=ventana))
        self.historial_estrategia   = defaultdict(lambda: deque(maxlen=ventana))
        self.historial_combo        = defaultdict(lambda: deque(maxlen=ventana))
        self.historial_regimen      = defaultdict(lambda: deque(maxlen=ventana))
        self.historial_dir_asset    = defaultdict(lambda: deque(maxlen=ventana))
        self.racha_asset            = defaultdict(int)

    def registrar(self, asset, estrategia, gano, regimen='SIDEWAYS', direccion='CALL'):
        val = 1 if gano else 0
        self.historial_asset[asset].append(val)
        self.historial_estrategia[estrategia].append(val)
        self.historial_combo[f"{asset}::{estrategia}"].append(val)
        self.historial_regimen[f"{estrategia}::{regimen}"].append(val)
        self.historial_dir_asset[f"{asset}::{direccion}"].append(val)
        if gano:
            self.racha_asset[asset] = max(0, self.racha_asset[asset]) + 1
        else:
            self.racha_asset[asset] = min(0, self.racha_asset[asset]) - 1

    def win_rate_asset(self, asset):
        h = self.historial_asset[asset]
        if len(h) < 3:
            return 0.65
        return sum(h) / len(h)

    def win_rate_estrategia(self, estrategia):
        h = self.historial_estrategia[estrategia]
        if len(h) < 3:
            return 0.65
        return sum(h) / len(h)

    def win_rate_combo(self, asset, estrategia):
        h = self.historial_combo[f"{asset}::{estrategia}"]
        if len(h) < 2:
            return 0.65
        return sum(h) / len(h)

    def win_rate_regimen(self, estrategia, regimen):
        h = self.historial_regimen[f"{estrategia}::{regimen}"]
        if len(h) < 2:
            return 0.65
        return sum(h) / len(h)

    def win_rate_direccion(self, asset, direccion):
        h = self.historial_dir_asset[f"{asset}::{direccion}"]
        if len(h) < 2:
            return 0.65
        return sum(h) / len(h)

    def factor_confianza(self, asset, estrategia, regimen='SIDEWAYS', direccion='CALL'):
        """
        Factor de confianza IA — combina 5 dimensiones de aprendizaje.
        Rango: ~0.0 (evitar) → ~1.5 (máxima confianza).
        Mejora automáticamente con cada operación registrada.
        """
        wr_a = self.win_rate_asset(asset)
        wr_e = self.win_rate_estrategia(estrategia)
        wr_c = self.win_rate_combo(asset, estrategia)
        wr_r = self.win_rate_regimen(estrategia, regimen)
        wr_d = self.win_rate_direccion(asset, direccion)
        factor = (wr_a * 0.25 + wr_e * 0.20 + wr_c * 0.30 + wr_r * 0.15 + wr_d * 0.10)
        if wr_a < UMBRAL_CONFIANZA_ACTIVO:
            factor *= 0.5
        racha = self.racha_asset.get(asset, 0)
        if racha >= 3:    factor = min(1.5, factor * 1.15)
        elif racha <= -3: factor = max(0.1, factor * 0.70)
        return factor

    def resumen_aprendizaje(self):
        resumen = {}
        for asset, h in self.historial_asset.items():
            if len(h) >= 3:
                wr    = sum(h) / len(h)
                racha = self.racha_asset.get(asset, 0)
                resumen[asset] = {'win_rate': round(wr, 3), 'ops': len(h), 'racha': racha}
        return dict(sorted(resumen.items(), key=lambda x: -x[1]['win_rate']))


class BotState:
    def __init__(self):
        self.running = False
        self.logs = []
        self.trades = []
        self.active_trades: list = []   # hasta MAX_CONCURRENT_TRADES ops simultáneas
        self.saldo = 0.0
        self.saldo_inicial = 0.0
        self.api = None
        self.tipo_cuenta = "PRACTICE"
        self.monto = 1.0
        self.asset_ops_hist = defaultdict(list)
        self.stats = {
            'total': 0, 'ganadas': 0, 'perdidas': 0, 'devueltas': 0,
            'profit': 0.0,
            'por_estrategia': {
                'sop_res':     {'total': 0, 'ganadas': 0},
                'pinbar':      {'total': 0, 'ganadas': 0},
                'rechazo':     {'total': 0, 'ganadas': 0},
                'macd_cross':  {'total': 0, 'ganadas': 0},
                'rsi_rebote':  {'total': 0, 'ganadas': 0},
                'stoch_cross': {'total': 0, 'ganadas': 0},
                'adx_fuerza':  {'total': 0, 'ganadas': 0},
                'vwap_pullback': {'total': 0, 'ganadas': 0},
                'tendencia_5m': {'total': 0, 'ganadas': 0},
            }
        }
        self.estrategias_activas = {
            'sop_res': True,
            'pinbar':  True,
            'rechazo': True,
            'macd_cross': True,
            'rsi_rebote': True,
            'stoch_cross': True,
            'adx_fuerza': True,
            'vwap_pullback': True,
            'tendencia_5m': True,
        }
        # Límite diario de operaciones
        self.ops_dia = 0
        self.max_ops_dia = None
        self.ops_dia_fecha = None   # fecha en que se contaron las ops
        # Bloqueo por 2 pérdidas consecutivas por activo+estrategia
        # clave: (asset, estrategia) → {'racha': int, 'bloqueado_hasta': datetime|None}
        self.bloqueo_asset_est: dict = {}
        # Martingala (nivel 1 máximo)
        self.martingala_activa     = False
        self.martingala_nivel      = 0
        self.martingala_monto_base = 0.0
        # Martingala pendiente: disparo inmediato en el mismo activo/dirección
        # { 'asset', 'direccion', 'estrategia', 'duracion', 'monto_base' } | None
        self.martingala_pendiente: dict | None = None
        self.activos_disponibles = []
        self.señal_actual = None
        self.scan_progreso = 0
        self.scan_total = 0
        self.ia = AdaptiveMemory(ventana=25)
        self.regimenes = {}
        self._email = ""
        self._password = ""
        self.perdidas_consecutivas = 0
        self.pausa_hasta = None           # datetime: no operar hasta esta hora
        self._ultimo_refresh_activos = 0  # timestamp del último refresh de activos
        self._candidatos_cache = []       # señales acumuladas en el ciclo actual
        self._cursor_activos   = 0        # posición del cursor en el ciclo rotativo
        self._ultimo_ciclo_min = -1       # minuto en que se limpió el cache
        self._lista_caliente   = {}       # {asset: score_previo} activos casi en umbral
        self._sin_datos_count  = defaultdict(int)
        self.diagnostico = {
            'estado': 'Esperando conexión',
            'ultimo_lote': 'Sin escaneo todavía',
            'mejor_candidato': None,
            'ultimo_bloqueo': 'Ninguno',
            'ultima_ejecucion': 'Ninguna',
            'eventos': [],
        }
        self.tipo_operacion    = 'binaria'  # 'binaria' | 'digital'

    @property
    def current_trade(self):
        """Compat: primera operación activa, o None."""
        return self.active_trades[0] if self.active_trades else None

    def add_log(self, msg, nivel="INFO"):
        ts = datetime.now(ecuador).strftime('%H:%M:%S')
        self.logs.append({"time": ts, "msg": msg, "nivel": nivel})
        if len(self.logs) > 400:
            self.logs = self.logs[-400:]
        try:
            with open("neurotrader_runtime.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now(ecuador).isoformat()} [{nivel}] {msg}\n")
        except Exception:
            pass

    def add_debug(self, msg, tipo="INFO", **extra):
        ts = datetime.now(ecuador).strftime('%H:%M:%S')
        if not hasattr(self, 'diagnostico'):
            self.diagnostico = {
                'estado': 'Inicializando diagnóstico',
                'ultimo_lote': 'Sin escaneo todavía',
                'mejor_candidato': None,
                'ultimo_bloqueo': 'Ninguno',
                'ultima_ejecucion': 'Ninguna',
                'eventos': [],
            }
        evento = {'time': ts, 'tipo': tipo, 'msg': msg}
        evento.update(extra)
        self.diagnostico.setdefault('eventos', []).append(evento)
        self.diagnostico['eventos'] = self.diagnostico['eventos'][-120:]
        if tipo in ('WARN', 'ERROR', 'BLOCK'):
            self.diagnostico['ultimo_bloqueo'] = msg
        elif tipo == 'TRADE':
            self.diagnostico['ultima_ejecucion'] = msg
        else:
            self.diagnostico['estado'] = msg
        try:
            datos = " ".join(f"{k}={v}" for k, v in extra.items() if k not in ("email", "password"))
            with open("neurotrader_runtime.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now(ecuador).isoformat()} [DEBUG:{tipo}] {msg} {datos}\n")
        except Exception:
            pass

    def add_trade(self, trade):
        self.trades.append(trade)
        self.stats['total'] += 1
        est      = trade.get('estrategia', 'sop_res')
        gano     = trade['estado'] == 'GANADA'
        regimen  = trade.get('regimen', 'SIDEWAYS')
        dir_op   = trade.get('direccion', 'CALL')
        self.ia.registrar(trade['asset'], est, gano, regimen=regimen, direccion=dir_op)
        if est in self.stats['por_estrategia']:
            self.stats['por_estrategia'][est]['total'] += 1
            if gano:
                self.stats['por_estrategia'][est]['ganadas'] += 1
        if gano:
            self.stats['ganadas'] += 1
            self.stats['profit'] += trade.get('ganancia', 0)
            self.perdidas_consecutivas = 0  # resetear racha de pérdidas
        elif trade['estado'] == 'PERDIDA':
            self.stats['perdidas'] += 1
            self.stats['profit'] -= trade['monto']
            self.perdidas_consecutivas += 1
            # Si supera el límite → activar pausa protectora
            if self.perdidas_consecutivas >= MAX_PERDIDAS_CONSECUTIVAS:
                self.pausa_hasta = datetime.now(ecuador) + timedelta(minutes=PAUSA_TRAS_PERDIDAS)
                self.add_log(
                    f"Pausa activada: {self.perdidas_consecutivas} perdidas consecutivas. "
                    f"Reanudando a las {self.pausa_hasta.strftime('%H:%M')}",
                    "WARN"
                )
        else:
            self.stats['devueltas'] += 1
        if len(self.trades) > 300:
            self.trades = self.trades[-300:]

    def puede_operar_asset(self, asset):
        ahora = datetime.now(ecuador)
        hace_una_hora = ahora - timedelta(hours=1)
        ops = [t for t in self.asset_ops_hist[asset] if t > hace_una_hora]
        self.asset_ops_hist[asset] = ops
        return len(ops) < MAX_OPS_POR_HORA_POR_ACTIVO

    def registrar_op(self, asset):
        self.asset_ops_hist[asset].append(datetime.now(ecuador))

    @property
    def win_rate(self):
        cerradas = self.stats['ganadas'] + self.stats['perdidas']
        return (self.stats['ganadas'] / cerradas * 100) if cerradas > 0 else 0.0


# ─────────────────────────────────────────────
# OBTENCIÓN DE DATOS
# ─────────────────────────────────────────────

def obtener_activos_disponibles(api):
    try:
        open_time = api.get_all_open_time()
        activos = set()
        if 'binary' in open_time:
            for asset, data in open_time['binary'].items():
                if data.get('open', False):
                    normalizado = _asset_api_symbol(asset)
                    if _asset_permitido(normalizado):
                        activos.add(normalizado)
        return sorted(activos)
    except Exception as e:
        logger.error(f"Error activos: {e}")
        return []


def is_asset_open(api, asset):
    try:
        asset = _asset_api_symbol(asset)
        open_time = api.get_all_open_time()
        if 'binary' in open_time:
            binary = open_time['binary']
            return (
                binary.get(asset, {}).get('open', False) or
                binary.get(f"{asset}-op", {}).get('open', False)
            )
        return False
    except:
        return False


_velas_cache     = {}          # {asset: (timestamp, df)}
_VELAS_CACHE_TTL = 25          # segundos de validez del caché por activo

def obtener_velas(api, asset, n=80, forzar_fresco=False):
    """
    Obtiene velas con caché de 25 segundos para reducir llamadas a la API.
    forzar_fresco=True omite el caché (usado en la re-verificación pre-trade).
    """
    asset = _asset_api_symbol(asset)
    ahora_ts = time.time()
    if not forzar_fresco:
        cached = _velas_cache.get(asset)
        if cached and (ahora_ts - cached[0]) < _VELAS_CACHE_TTL:
            return cached[1]
    try:
        candles = api.get_candles(asset, 60, n, ahora_ts)
        if not candles or len(candles) < 25:
            return None
        df = pd.DataFrame(candles)
        for col in ['open', 'max', 'min', 'close', 'volume']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        df.dropna(subset=['open', 'close', 'max', 'min'], inplace=True)
        if len(df) < 25:
            return None
        df.rename(columns={'max': 'high', 'min': 'low'}, inplace=True)
        df = df.reset_index(drop=True)
        _velas_cache[asset] = (ahora_ts, df)
        return df
    except Exception:
        return None


# ─────────────────────────────────────────────
# INDICADORES TÉCNICOS AVANZADOS
# ─────────────────────────────────────────────

def calcular_indicadores(df):
    df = df.copy()
    c = df['close']
    h = df['high']
    l = df['low']
    o = df['open']
    v = df['volume']

    # EMAs múltiples (incluye EMA50/200 para estrategia de tendencia 5min)
    for span in [3, 5, 9, 10, 13, 20, 21, 34, 50, 200]:
        df[f'ema{span}'] = c.ewm(span=span, adjust=False).mean()

    # SMAs
    df['sma5']  = c.rolling(5).mean()
    df['sma10'] = c.rolling(10).mean()
    df['sma20'] = c.rolling(20).mean()

    # Bollinger Bands (20, 2)
    df['bb_mid']   = df['sma20']
    df['bb_std']   = c.rolling(20).std()
    df['bb_upper'] = df['bb_mid'] + 2.0 * df['bb_std']
    df['bb_lower'] = df['bb_mid'] - 2.0 * df['bb_std']
    df['bb_pct']   = (c - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'] + 1e-10)
    df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / (df['bb_mid'] + 1e-10)

    lo14_base = l.rolling(14).min()
    hi14_base = h.rolling(14).max()
    stoch_raw_base = 100 * (c - lo14_base) / (hi14_base - lo14_base + 1e-10)
    df['stoch_k_raw'] = stoch_raw_base
    df['stoch_k'] = stoch_raw_base.rolling(3).mean()
    df['stoch_d'] = df['stoch_k'].rolling(3).mean()

    # MACD rápido (5, 13, 1) — para Bollinger/S&R
    df['macd']        = c.ewm(span=5, adjust=False).mean() - c.ewm(span=13, adjust=False).mean()
    df['macd_signal'] = df['macd'].ewm(span=1, adjust=False).mean()
    df['macd_hist']   = df['macd'] - df['macd_signal']

    # MACD estándar (12, 26, 9) — para estrategia de divergencia
    df['macd12']        = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    df['macd12_signal'] = df['macd12'].ewm(span=9, adjust=False).mean()
    df['macd12_hist']   = df['macd12'] - df['macd12_signal']
    # Cruce de MACD12: macd12 cruza signal hacia arriba/abajo
    df['macd12_cruce_bull'] = ((df['macd12'] > df['macd12_signal']) &
                               (df['macd12'].shift(1) <= df['macd12_signal'].shift(1))).astype(int)
    df['macd12_cruce_bear'] = ((df['macd12'] < df['macd12_signal']) &
                               (df['macd12'].shift(1) >= df['macd12_signal'].shift(1))).astype(int)

    # EMA 10 y EMA 20 (spec del documento — distintas de SMA10/SMA20)
    df['ema10'] = c.ewm(span=10, adjust=False).mean()
    df['ema20'] = c.ewm(span=20, adjust=False).mean()
    df['ema10_sobre_ema20'] = (df['ema10'] > df['ema20']).astype(int)

    # Donchian (5 y 10)
    df['don5_high'] = h.rolling(5).max()
    df['don5_low']  = l.rolling(5).min()
    df['don10_high']= h.rolling(10).max()
    df['don10_low'] = l.rolling(10).min()

    # ATR 14 (medida de volatilidad)
    tr = pd.concat([
        h - l,
        (h - c.shift(1)).abs(),
        (l - c.shift(1)).abs()
    ], axis=1).max(axis=1)
    df['atr'] = tr.ewm(com=13, adjust=False).mean()
    df['atr_pct'] = df['atr'] / (c + 1e-10)

    # ADX 14 (fuerza de tendencia)
    h_diff = h.diff()
    l_diff = (-l).diff()
    plus_dm  = h_diff.where((h_diff > l_diff) & (h_diff > 0), 0.0)
    minus_dm = l_diff.where((l_diff > h_diff) & (l_diff > 0), 0.0)
    plus_di14  = 100 * plus_dm.ewm(com=13, adjust=False).mean()  / (df['atr'] + 1e-10)
    minus_di14 = 100 * minus_dm.ewm(com=13, adjust=False).mean() / (df['atr'] + 1e-10)
    dx = 100 * (plus_di14 - minus_di14).abs() / (plus_di14 + minus_di14 + 1e-10)
    df['adx']      = dx.ewm(com=13, adjust=False).mean()
    df['plus_di']  = plus_di14
    df['minus_di'] = minus_di14

    # Volume indicators
    df['vol_sma5']  = v.rolling(5).mean()
    df['vol_sma10'] = v.rolling(10).mean()
    df['vol_sma20'] = v.rolling(20).mean()
    df['vol_ratio'] = v / (df['vol_sma20'] + 1e-10)
    df['vol_ratio5']= v / (df['vol_sma5'] + 1e-10)   # vs últimas 5 velas
    df['vol_spike'] = df['vol_ratio'] > 1.5

    # MFM/ADL (Money Flow Multiplier + Accumulation/Distribution Line)
    df['mfm'] = (((c - l) - (h - c)) / (h - l + 1e-10)).clip(-1, 1)
    df['mfv'] = df['mfm'] * v
    df['adl'] = df['mfv'].cumsum()
    df['adl_ema'] = df['adl'].ewm(span=5, adjust=False).mean()
    df['adl_slope'] = df['adl'] - df['adl'].shift(3)

    # OBV (On Balance Volume)
    obv = [0.0]
    for i in range(1, len(df)):
        if df['close'].iloc[i] > df['close'].iloc[i-1]:
            obv.append(obv[-1] + df['volume'].iloc[i])
        elif df['close'].iloc[i] < df['close'].iloc[i-1]:
            obv.append(obv[-1] - df['volume'].iloc[i])
        else:
            obv.append(obv[-1])
    df['obv'] = obv
    df['obv_sma'] = pd.Series(obv).rolling(10).mean().values

    # Candle properties
    df['body']       = (c - o).abs()
    df['rango']      = h - l
    df['body_ratio'] = df['body'] / (df['rango'] + 1e-10)
    df['is_bull']    = c > o
    df['upper_wick'] = h - c.clip(lower=o)
    df['lower_wick'] = o.clip(upper=c) - l
    df['wick_ratio'] = (df['upper_wick'] + df['lower_wick']) / (df['rango'] + 1e-10)

    # CCI (Commodity Channel Index)
    tp = (h + l + c) / 3
    df['cci'] = (tp - tp.rolling(14).mean()) / (0.015 * tp.rolling(14).std() + 1e-10)

    # Williams %R
    df['willr'] = -100 * (h.rolling(14).max() - c) / (h.rolling(14).max() - l.rolling(14).min() + 1e-10)

    # ── CMF (Chaikin Money Flow 10) ────────────────────────────────────────
    mfv = df['mfv']
    df['cmf'] = mfv.rolling(10).sum() / (v.rolling(10).sum() + 1e-10)

    # ── Rate of Change (ROC 5) — momentum bruto ───────────────────────────
    df['roc5'] = (c - c.shift(5)) / (c.shift(5) + 1e-10) * 100

    # ── EMA spread ratio (alineación de tendencia) ────────────────────────
    df['ema_spread'] = (df['ema5'] - df['ema21']) / (df['ema21'] + 1e-10) * 100

    # ── MA 10 / MA 20 — estado y cruce ────────────────────────────────────
    df['ma10_sobre_ma20'] = (df['sma10'] > df['sma20']).astype(int)
    prev = df['ma10_sobre_ma20'].shift(1).fillna(df['ma10_sobre_ma20'])
    df['ma_cruce_bull'] = ((df['ma10_sobre_ma20'] == 1) & (prev == 0))  # dorado
    df['ma_cruce_bear'] = ((df['ma10_sobre_ma20'] == 0) & (prev == 1))  # muerto

    # ── Patrones de vela ──────────────────────────────────────────────────
    # Hammer alcista: mecha inferior larga, cuerpo pequeño arriba
    hammer = (df['lower_wick'] > df['body'] * 2.0) & (df['body_ratio'] > 0.1) & (c >= o)
    # Shooting star bajista: mecha superior larga, cuerpo pequeño abajo
    shoot  = (df['upper_wick'] > df['body'] * 2.0) & (df['body_ratio'] > 0.1) & (c <= o)
    # Engulfing alcista: vela alcista con cuerpo mayor al anterior bajista
    bull_eng = (c > o) & (c.shift(1) < o.shift(1)) & (c > o.shift(1)) & (o < c.shift(1))
    # Engulfing bajista
    bear_eng = (c < o) & (c.shift(1) > o.shift(1)) & (c < o.shift(1)) & (o > c.shift(1))
    # Doji: cuerpo muy pequeño vs rango (indecisión)
    doji     = df['body_ratio'] < 0.08
    # Pin bar (rechazo fuerte): wick > 3× cuerpo
    pin_bull = (df['lower_wick'] > df['body'] * 3.0) & (c >= o)
    pin_bear = (df['upper_wick'] > df['body'] * 3.0) & (c <= o)

    df['pat_hammer']   = hammer.astype(int)
    df['pat_shoot']    = shoot.astype(int)
    df['pat_bull_eng'] = bull_eng.astype(int)
    df['pat_bear_eng'] = bear_eng.astype(int)
    df['pat_doji']     = doji.astype(int)
    df['pat_pin_bull'] = pin_bull.astype(int)
    df['pat_pin_bear'] = pin_bear.astype(int)

    # ── Volumen — confirmación de fuerza del movimiento ───────────────────
    # NOTA: activos OTC no tienen volumen real (IQ Option usa precios sintéticos).
    # Si la media de volumen es 0 → no hay datos → saltar análisis de volumen.
    vol_tiene_datos = False
    if 'volume' in df.columns:
        v = df['volume'].fillna(0).astype(float)
        vol_mean = float(v.mean())
        if vol_mean > 0:
            vol_tiene_datos = True
            vol_ma = v.rolling(14, min_periods=3).mean().fillna(vol_mean)
            df['vol_ma']       = vol_ma
            df['vol_ratio']    = (v / vol_ma.replace(0, 1)).round(3)
            df['vol_spike']    = (df['vol_ratio'] > 1.5).astype(int)
            df['vol_decaying'] = ((v < v.shift(1)) & (v.shift(1) < v.shift(2))).astype(int)
            df['vol_colapso']  = (df['vol_ratio'] < 0.5).astype(int)
    if not vol_tiene_datos:
        # Sin datos de volumen (activo OTC / sintético) → neutro, no penalizar
        df['vol_ma']       = 1.0
        df['vol_ratio']    = 1.0
        df['vol_spike']    = 0
        df['vol_decaying'] = 0
        df['vol_colapso']  = 0

    # ── Consecutive candle direction (momentum) ───────────────────────────
    df['bull_streak'] = (c > o).astype(int)
    streak_c = []
    streak_b = []
    c_s = b_s = 0
    for i in range(len(df)):
        if df['bull_streak'].iloc[i]:
            c_s += 1; b_s = 0
        else:
            b_s += 1; c_s = 0
        streak_c.append(c_s)
        streak_b.append(b_s)
    df['streak_bull'] = streak_c
    df['streak_bear'] = streak_b

    return df


# ─────────────────────────────────────────────
# EVALUADOR DE FUERZA DE MOVIMIENTO
# ─────────────────────────────────────────────

def evaluar_fuerza(df, direction):
    """
    Evaluador de fuerza profesional — 10 factores de momentum.
    Determina si el impulso actual puede sostener la dirección durante 1 minuto.
    Score 0-100. FUERZA_MINIMA requerida para habilitar la operación.
    """
    if len(df) < 6:
        return 0
    score = 0
    u  = df.iloc[-1]
    p  = df.iloc[-2]
    p2 = df.iloc[-3]
    p3 = df.iloc[-4]

    is_call = (direction == 'CALL')
    c  = float(u['close'])
    c1 = float(p['close'])
    c2 = float(p2['close'])
    c3 = float(p3['close'])

    # ── 1. Consistencia de cierres (momentum direccional claro) ───────────
    if is_call:
        if c > c1 > c2 > c3:
            score += 28     # 4 cierres ascendentes: momentum fuertísimo
        elif c > c1 > c2:
            score += 20     # 3 cierres ascendentes
        elif c > c1:
            score += 10
    else:
        if c < c1 < c2 < c3:
            score += 28
        elif c < c1 < c2:
            score += 20
        elif c < c1:
            score += 10

    # ── 2. Aceleración de volumen (empuje institucional) ──────────────────
    vr = float(u['vol_ratio'])
    if vr > 2.0:
        score += 22
    elif vr > 1.6:
        score += 15
    elif vr > 1.25:
        score += 8
    # volumen por debajo del promedio: sin bonus (puede hacer el movimiento)

    # ── 3. MACD hist acelerando en 3 velas ────────────────────────────────
    mh  = float(u['macd_hist'])
    mhp = float(p['macd_hist'])
    mhp2= float(p2['macd_hist'])
    if is_call:
        if mh > mhp > mhp2 and mh > 0:
            score += 20     # momentum alcista acelerando
        elif mh > mhp and mh > 0:
            score += 10
    else:
        if mh < mhp < mhp2 and mh < 0:
            score += 20
        elif mh < mhp and mh < 0:
            score += 10

    # ── 4. ATR en rango óptimo ─────────────────────────────────────────────
    atr_pct = float(u['atr_pct'])
    if 0.0003 < atr_pct < 0.008:
        score += 14
    elif atr_pct >= 0.008:
        score += 4          # alta volatilidad: más riesgo pero posible

    # ── 5. Cuerpo de vela creciente (convicción aumentando) ────────────────
    body  = float(u['body'])
    bodyp = float(p['body'])
    bodyp2= float(p2['body'])
    if body > bodyp * 1.20 and body > bodyp2:
        score += 14

    # ── 6. Sin rechazo (mecha opuesta pequeña en dirección) ───────────────
    if is_call:
        uw = float(u['upper_wick'])
        if uw < body * 0.30:
            score += 12     # sin vendedores encima
    else:
        lw = float(u['lower_wick'])
        if lw < body * 0.30:
            score += 12     # sin compradores abajo

    # ── 7. OBV alineado (volumen neto confirma dirección) ─────────────────
    if is_call and float(u['obv']) > float(u['obv_sma']):
        score += 10
    elif not is_call and float(u['obv']) < float(u['obv_sma']):
        score += 10

    # ── 8. EMA stack completo ─────────────────────────────────────────────
    if is_call and float(u['ema3']) > float(u['ema9']) > float(u['ema21']):
        score += 10
    elif not is_call and float(u['ema3']) < float(u['ema9']) < float(u['ema21']):
        score += 10

    # ── 9. CMF confirma flujo de dinero ───────────────────────────────────
    cmf = float(u['cmf'])
    if is_call and cmf > 0.08:
        score += 10
    elif not is_call and cmf < -0.08:
        score += 10

    # ── 10. Stochastic en zona correcta ───────────────────────────────────
    sk = float(u['stoch_k'])
    if is_call and sk < 40:     # comprando en zona baja
        score += 8
    elif not is_call and sk > 60:   # vendiendo en zona alta
        score += 8

    # Penalización: doji en la última vela → impulso dudoso
    if int(u.get('pat_doji', 0)):
        score = int(score * 0.80)

    return min(score, 100)


# ─────────────────────────────────────────────
# IA DE SOSTENIBILIDAD DE PRECIO (1 minuto)
# ─────────────────────────────────────────────

def evaluar_sostenibilidad(df, direction, asset=''):
    """
    Evalúa la probabilidad de que el precio MANTENGA la dirección
    durante todo el vencimiento de 1 minuto.

    Analiza 8 factores críticos que determinan si el movimiento es
    un impulso real o un falso pico (spike) que revertirá:

    1. Estructura de cierres (¿cuántas velas consecutivas en dirección?)
    2. Pendiente de EMA rápida (¿el tren de momentum ya arrancó?)
    3. Volumen sostenido (¿hay participación institucional sostenida?)
    4. ATR vs movimiento actual (¿el spike ya quemó todo el ATR?)
    5. RSI no en zona de agotamiento final (¿queda espacio de recorrido?)
    6. MACD acelerando o al menos no decelerando
    7. Vela actual sin mecha larga opuesta (¿no hay rechazo activo?)
    8. Spread EMA corto-largo (¿la estructura de fondo apoya?)

    Retorna score 0-100. Se exige >= 35 para operar.
    """
    if len(df) < 8:
        return 0

    u  = df.iloc[-1]
    p  = df.iloc[-2]
    p2 = df.iloc[-3]
    p3 = df.iloc[-4] if len(df) > 4 else p2

    score    = 0
    is_call  = (direction == 'CALL')
    c   = float(u['close'])
    c1  = float(p['close'])
    c2  = float(p2['close'])
    c3  = float(p3['close'])
    atr = max(float(u.get('atr', abs(c - c1))), 1e-10)

    # ── 1. Consistencia de cierres (tren de momentum activo) ──────────────
    if is_call:
        if c > c1 and c1 > c2 and c2 > c3:
            score += 22   # 4 velas subiendo: momentum claro
        elif c > c1 and c1 > c2:
            score += 14   # 3 velas subiendo
        elif c > c1:
            score += 6    # solo 1 vela: prematuro
        else:
            score -= 10   # precio ya cediendo: no operar
    else:
        if c < c1 and c1 < c2 and c2 < c3:
            score += 22
        elif c < c1 and c1 < c2:
            score += 14
        elif c < c1:
            score += 6
        else:
            score -= 10

    # ── 2. Pendiente EMA rápida (EMA5) — ¿el tren ya arrancó? ─────────────
    e5_now  = float(u.get('ema5', c))
    e5_prev = float(p.get('ema5', c1)) if 'ema5' in df.columns else c1
    e5_prev2 = float(p2.get('ema5', c2)) if 'ema5' in df.columns else c2
    if is_call:
        if e5_now > e5_prev > e5_prev2:
            score += 15   # EMA5 sube sostenidamente
        elif e5_now > e5_prev:
            score += 8
        else:
            score -= 5    # EMA5 bajando: impulso débil
    else:
        if e5_now < e5_prev < e5_prev2:
            score += 15
        elif e5_now < e5_prev:
            score += 8
        else:
            score -= 5

    # ── 3. Volumen sostenido (no debe ser un spike aislado) ────────────────
    vr  = float(u.get('vol_ratio',  1.0))
    vr1 = float(p.get('vol_ratio',  1.0)) if 'vol_ratio' in df.columns else 1.0
    if vr >= 1.2 and vr1 >= 0.9:
        score += 14   # volumen sostenido 2 velas
    elif vr >= 1.0:
        score += 7
    elif vr < 0.7:
        score -= 6    # volumen muy bajo: movimiento dudoso

    # ── 4. ATR vs movimiento actual (¿ya se consumió todo el recorrido?) ───
    mov_actual = abs(c - c1)
    if mov_actual > atr * 0.90:
        score -= 12   # el movimiento ya consumió casi todo el ATR → falso pico
    elif mov_actual > atr * 0.70:
        score -= 6
    elif mov_actual < atr * 0.50:
        score += 10   # aún queda recorrido disponible

    # ── 5. RSI — ¿queda espacio de recorrido sin agotamiento? ─────────────
    rsi = float(u.get('rsi', 50))
    if is_call:
        if rsi < 55:    score += 12   # lejos de sobrecompra: recorrido libre
        elif rsi < 65:  score += 5
        elif rsi > 75:  score -= 14   # ya en sobrecompra: reversión inminente
        elif rsi > 70:  score -= 7
    else:
        if rsi > 45:    score += 12   # lejos de sobreventa: recorrido libre
        elif rsi > 35:  score += 5
        elif rsi < 25:  score -= 14
        elif rsi < 30:  score -= 7

    # ── 6. MACD sostenido (no decelerando) ────────────────────────────────
    mh  = float(u.get('macd_hist',  0))
    mhp = float(p.get('macd_hist',  0)) if 'macd_hist' in df.columns else 0
    if is_call:
        if mh > 0 and mh >= mhp:   score += 10  # acelerando o sostenido
        elif mh > 0:                score += 4   # en zona correcta pero decel.
        else:                       score -= 5   # MACD negativo: debilidad
    else:
        if mh < 0 and mh <= mhp:   score += 10
        elif mh < 0:                score += 4
        else:                       score -= 5

    # ── 7. Sin mecha larga opuesta (no hay rechazo activo) ─────────────────
    body = max(float(u.get('body', atr * 0.1)), 1e-10)
    if is_call:
        uw = float(u.get('upper_wick', 0))
        if uw > body * 1.5:
            score -= 10   # mecha superior larga: vendedores resistiendo activamente
        elif uw < body * 0.4:
            score += 8
    else:
        lw = float(u.get('lower_wick', 0))
        if lw > body * 1.5:
            score -= 10   # mecha inferior larga: compradores resistiendo
        elif lw < body * 0.4:
            score += 8

    # ── 8. Estructura EMA (EMA5 vs EMA50) — ¿el fondo apoya? ──────────────
    e50 = float(u.get('ema50', c))
    if e50 > 0:
        if is_call and c > e50 * 1.0002:
            score += 8    # precio por encima de EMA lenta: tendencia de fondo alcista
        elif not is_call and c < e50 * 0.9998:
            score += 8
        elif is_call and c < e50:
            score -= 5    # contra la tendencia de fondo
        elif not is_call and c > e50:
            score -= 5

    # ── Penalización especial por activo volátil ───────────────────────────
    asset_base = asset.replace('/', '').replace('-', '').upper()[:6]
    if asset_base in PARES_VOLATILES:
        score -= 10  # exigir más evidencia en pares de alta volatilidad

    return max(0, min(score, 100))


# ─────────────────────────────────────────────
# DETECCIÓN DE RÉGIMEN DE MERCADO
# ─────────────────────────────────────────────

def detectar_regimen(df):
    """
    Detecta si el mercado está en tendencia alcista, bajista o lateral.
    Retorna: 'BULL', 'BEAR', 'SIDEWAYS'
    """
    if len(df) < 21:
        return 'SIDEWAYS'
    u = df.iloc[-1]
    ema5  = u['ema5']
    ema13 = u['ema13']
    ema21 = u['ema21']
    bb_width = u['bb_width']
    atr_pct  = u['atr_pct']

    # Tendencia fuerte = precio arriba de EMAs alineadas
    if ema5 > ema13 > ema21 and atr_pct > 0.0003:
        return 'BULL'
    if ema5 < ema13 < ema21 and atr_pct > 0.0003:
        return 'BEAR'
    # Mercado lateral = bandas estrechas y EMAs planas
    if bb_width < 0.003:
        return 'SIDEWAYS'
    if ema5 > ema13 > ema21:
        return 'BULL'
    if ema5 < ema13 < ema21:
        return 'BEAR'
    return 'SIDEWAYS'


# ─────────────────────────────────────────────
# MOTOR DE SCORING IA
# ─────────────────────────────────────────────

class ScoringIA:
    """
    Motor de scoring profesional v2 — 25 factores técnicos ponderados.
    Evalúa 6 capas de confirmación para maximizar la tasa de acierto.

    Novedad v2:
      · Cruce MA10/MA20 como factor de alta ponderación (20 pts)
      · Alineación MA10/MA20 como confirmador adicional (10 pts)
      · Peso de 'triple_confirmacion' elevado a 20 pts
      · Nuevo bono 'quint_confirmacion': BB + RSI + MACD + MA + patrón (25 pts)
    """
    PESOS = {
        # ── Capa 1: Osciladores de sobreventa/sobrecompra ────────────────
        'bb_extremo':          22,  # Precio en extremo de Bollinger
        'rsi_extremo':         16,  # RSI < 30 / > 70
        'stoch_rsi_extremo':   10,  # StochRSI < 0.15 / > 0.85
        'stoch_kd_cruce':      12,  # Cruce %K/%D en zona extrema
        'cci_extremo':         10,  # CCI < -100 / > 100
        'willr_extremo':        8,  # Williams %R en zona extrema
        # ── Capa 2: Momentum y flujo ─────────────────────────────────────
        'macd_confirma':       14,  # MACD hist acelerando en dirección
        'cmf_confirma':        12,  # CMF > 0.05 (dinero entrando/saliendo)
        'obv_confirma':         8,  # OBV vs su SMA
        'roc_momentum':         8,  # Rate of Change positivo/negativo
        # ── Capa 3: Estructura de precio y MAs ───────────────────────────
        'ma_cruce_bull_bear':  20,  # Cruce dorado/muerto MA10/MA20 (mayor peso)
        'ma_alineada':         10,  # MA10 sobre/bajo MA20 apoya dirección
        'tendencia_ema':       10,  # EMAs 3-9-21 alineadas en dirección
        'ema_spread_fuerte':    8,  # Spread EMA5-EMA21 significativo
        'donchian_ruptura':     8,  # Precio supera máximo/mínimo Donchian
        'atr_adecuado':         4,  # ATR en rango óptimo de volatilidad
        # ── Capa 4: Patrones de vela ──────────────────────────────────────
        'patron_engulfing':    14,  # Vela envolvente (señal de inversión)
        'patron_pin_bar':      12,  # Pin bar / hammer / shooting star
        'cuerpo_fuerte':        8,  # Vela con cuerpo > 60% del rango
        'racha_velas':          8,  # 3+ velas consecutivas en dirección
        # ── Capa 5: Contexto y confirmación multi-factor ─────────────────
        'regimen_alineado':    12,  # Régimen de mercado apoya la dirección
        'volumen_alto':         8,  # Volumen > 1.3× promedio
        'triple_confirmacion': 20,  # BB + RSI + MACD alineados (bono extra)
        'quad_confirmacion':   22,  # BB + RSI + MACD + patrón vela
        'quint_confirmacion':  25,  # + MA10/MA20 alineados (bono máximo)
    }

    @classmethod
    def evaluar(cls, df, regimen):
        if len(df) < 22:
            return None, 0

        u  = df.iloc[-1]
        p  = df.iloc[-2]
        p2 = df.iloc[-3]
        p3 = df.iloc[-4] if len(df) > 4 else p2
        close = float(u['close'])

        fc = {}   # factores CALL
        fp = {}   # factores PUT

        # ── 1. Bollinger extremo ───────────────────────────────────────────
        bb_lo = float(u['bb_lower'])
        bb_up = float(u['bb_upper'])
        if close <= bb_lo * 1.002:
            fc['bb_extremo'] = True
        if close >= bb_up * 0.998:
            fp['bb_extremo'] = True

        # ── 2. RSI extremo (más estricto: 30/70) ──────────────────────────
        rsi = float(u['rsi'])
        if rsi < 30:
            fc['rsi_extremo'] = True
        if rsi > 70:
            fp['rsi_extremo'] = True

        # ── 3. StochRSI extremo ───────────────────────────────────────────
        srsi = float(u['stoch_rsi'])
        if srsi < 0.15:
            fc['stoch_rsi_extremo'] = True
        if srsi > 0.85:
            fp['stoch_rsi_extremo'] = True

        # ── 4. Stochastic %K/%D cruce en zona extrema ─────────────────────
        sk = float(u['stoch_k'])
        sd = float(u['stoch_d'])
        sk_p = float(p['stoch_k'])
        sd_p = float(p['stoch_d'])
        if sk < 25 and sk > sd and sk_p <= sd_p:   # cruce alcista en sobreventa
            fc['stoch_kd_cruce'] = True
        if sk > 75 and sk < sd and sk_p >= sd_p:   # cruce bajista en sobrecompra
            fp['stoch_kd_cruce'] = True

        # ── 5. CCI extremo (más estricto: ±100) ───────────────────────────
        cci = float(u['cci'])
        if cci < -100:
            fc['cci_extremo'] = True
        if cci > 100:
            fp['cci_extremo'] = True

        # ── 6. Williams %R ────────────────────────────────────────────────
        willr = float(u['willr'])
        if willr < -80:
            fc['willr_extremo'] = True
        if willr > -20:
            fp['willr_extremo'] = True

        # ── 7. MACD hist acelerando ────────────────────────────────────────
        mh  = float(u['macd_hist'])
        mhp = float(p['macd_hist'])
        mhp2= float(p2['macd_hist'])
        if mh > 0 and mh > mhp and mhp > mhp2:    # aceleración alcista
            fc['macd_confirma'] = True
        if mh < 0 and mh < mhp and mhp < mhp2:    # aceleración bajista
            fp['macd_confirma'] = True

        # ── 8. CMF (dinero entrando/saliendo) ─────────────────────────────
        cmf = float(u['cmf'])
        if cmf > 0.05:
            fc['cmf_confirma'] = True
        if cmf < -0.05:
            fp['cmf_confirma'] = True

        # ── 9. OBV vs SMA ─────────────────────────────────────────────────
        if float(u['obv']) > float(u['obv_sma']):
            fc['obv_confirma'] = True
        if float(u['obv']) < float(u['obv_sma']):
            fp['obv_confirma'] = True

        # ── 10. Rate of Change (ROC5) ─────────────────────────────────────
        roc = float(u['roc5'])
        if roc > 0.02:    # precio subió > 0.02% en últimas 5 velas
            fc['roc_momentum'] = True
        if roc < -0.02:
            fp['roc_momentum'] = True

        # ── 11. Tendencia EMAs alineadas ──────────────────────────────────
        e3  = float(u['ema3'])
        e9  = float(u['ema9'])
        e21 = float(u['ema21'])
        if e3 > e9 > e21:
            fc['tendencia_ema'] = True
        if e3 < e9 < e21:
            fp['tendencia_ema'] = True

        # ── 12. EMA spread significativo ──────────────────────────────────
        spread = float(u['ema_spread'])
        if spread > 0.025:    # EMA5 supera EMA21 en +0.025%
            fc['ema_spread_fuerte'] = True
        if spread < -0.025:
            fp['ema_spread_fuerte'] = True

        # ── 13. Donchian ruptura confirmada ───────────────────────────────
        if close > float(p['don10_high']) and float(u['macd']) > 0:
            fc['donchian_ruptura'] = True
        if close < float(p['don10_low']) and float(u['macd']) < 0:
            fp['donchian_ruptura'] = True

        # ── 14. ATR adecuado ──────────────────────────────────────────────
        atr_pct = float(u['atr_pct'])
        if 0.0002 < atr_pct < 0.010:
            fc['atr_adecuado'] = True
            fp['atr_adecuado'] = True

        # ── 15. Patrón engulfing ──────────────────────────────────────────
        if int(u['pat_bull_eng']):
            fc['patron_engulfing'] = True
        if int(u['pat_bear_eng']):
            fp['patron_engulfing'] = True

        # ── 16. Pin bar / hammer / shooting star ──────────────────────────
        if int(u['pat_hammer']) or int(u['pat_pin_bull']):
            fc['patron_pin_bar'] = True
        if int(u['pat_shoot']) or int(u['pat_pin_bear']):
            fp['patron_pin_bar'] = True

        # ── 17. Cuerpo fuerte en dirección ────────────────────────────────
        if float(u['body_ratio']) > 0.60 and bool(u['is_bull']):
            fc['cuerpo_fuerte'] = True
        if float(u['body_ratio']) > 0.60 and not bool(u['is_bull']):
            fp['cuerpo_fuerte'] = True

        # ── 18. Racha de velas en misma dirección ─────────────────────────
        sb = int(u['streak_bull'])
        sr = int(u['streak_bear'])
        if sb >= 3:
            fc['racha_velas'] = True
        if sr >= 3:
            fp['racha_velas'] = True

        # ── 19. Volumen alto ───────────────────────────────────────────────
        if float(u['vol_ratio']) > 1.30:
            fc['volumen_alto'] = True
            fp['volumen_alto'] = True

        # ── 20. Régimen alineado ───────────────────────────────────────────
        if regimen == 'BULL':
            fc['regimen_alineado'] = True
        elif regimen == 'BEAR':
            fp['regimen_alineado'] = True
        elif regimen == 'SIDEWAYS':
            if 'bb_extremo' in fc:
                fc['regimen_alineado'] = True
            if 'bb_extremo' in fp:
                fp['regimen_alineado'] = True

        # ── 21. Triple confirmación (BB + RSI + MACD) ─────────────────────
        if all(k in fc for k in ('bb_extremo', 'rsi_extremo', 'macd_confirma')):
            fc['triple_confirmacion'] = True
        if all(k in fp for k in ('bb_extremo', 'rsi_extremo', 'macd_confirma')):
            fp['triple_confirmacion'] = True

        # ── 22. Quad confirmación (BB + RSI + MACD + patrón vela) ─────────
        call_patron = 'patron_engulfing' in fc or 'patron_pin_bar' in fc
        put_patron  = 'patron_engulfing' in fp or 'patron_pin_bar' in fp
        if 'triple_confirmacion' in fc and call_patron:
            fc['quad_confirmacion'] = True
        if 'triple_confirmacion' in fp and put_patron:
            fp['quad_confirmacion'] = True

        # ── 23. Cruce MA10/MA20 (señal de tendencia poderosa) ─────────────
        ma10_gt = bool(u.get('ma10_sobre_ma20', 0))
        cruce_b = bool(u.get('ma_cruce_bull', False))
        cruce_e = bool(u.get('ma_cruce_bear', False))
        if cruce_b:
            fc['ma_cruce_bull_bear'] = True   # cruce dorado reciente
        if cruce_e:
            fp['ma_cruce_bull_bear'] = True   # cruce muerto reciente

        # ── 24. MA10/MA20 alineadas con la dirección ──────────────────────
        if ma10_gt:
            fc['ma_alineada'] = True   # MA10 sobre MA20 → tendencia alcista
        else:
            fp['ma_alineada'] = True   # MA10 bajo MA20 → tendencia bajista

        # ── 25. Quint confirmación (Quad + MA10/MA20 alineada) ────────────
        if 'quad_confirmacion' in fc and 'ma_alineada' in fc:
            fc['quint_confirmacion'] = True
        if 'quad_confirmacion' in fp and 'ma_alineada' in fp:
            fp['quint_confirmacion'] = True

        # ── Calcular scores finales ────────────────────────────────────────
        sc = sum(cls.PESOS.get(k, 0) for k in fc)
        sp = sum(cls.PESOS.get(k, 0) for k in fp)

        # ── Filtros post-score: patrones de reversión y volumen ───────────
        # Doji: impulso dudoso → −10%
        if int(u.get('pat_doji', 0)):
            sc = int(sc * 0.90)
            sp = int(sp * 0.90)

        # Estrella fugaz / pin bear en la última vela → CALL peligroso (−55%)
        if int(u.get('pat_shoot', 0)) or int(u.get('pat_pin_bear', 0)):
            sc = int(sc * 0.45)

        # Martillo / pin bull en la última vela → PUT peligroso (−55%)
        if int(u.get('pat_hammer', 0)) or int(u.get('pat_pin_bull', 0)):
            sp = int(sp * 0.45)

        # Volumen colapsando → mercado sin fuerza, reducir ambos (−15%)
        if int(u.get('vol_colapso', 0)):
            sc = int(sc * 0.85)
            sp = int(sp * 0.85)

        # Volumen decayendo → impulso agotándose (−8%)
        if int(u.get('vol_decaying', 0)):
            sc = int(sc * 0.92)
            sp = int(sp * 0.92)

        # Volumen en spike → movimiento con convicción, bonus (+8%)
        if int(u.get('vol_spike', 0)):
            sc = int(sc * 1.08)
            sp = int(sp * 1.08)

        if sc >= sp and sc >= MIN_SCORE_PARA_OPERAR:
            return 'CALL', min(sc, 100)
        if sp > sc and sp >= MIN_SCORE_PARA_OPERAR:
            return 'PUT', min(sp, 100)
        return None, 0


# ─────────────────────────────────────────────
# CLASIFICACIÓN DE ACTIVO Y FILTRO DE MERCADO
# ─────────────────────────────────────────────

_CRYPTOS = {'BTC','ETH','LTC','XRP','BCH','DASH','ETC','ATOM','DOGE','BNB',
            'SOL','ADA','AVAX','MATIC','DOT','LINK','UNI','AAVE','COMP','TRX','EOS'}
_INDICES = {'SPX','SP500','NDX','DJ30','FTSE','DAX','CAC40','NIKKEI','DJI',
            'AUS200','GER30','JPN225','NASDAQ','USTEC','US30','US500','DE30',
            'UK100','FR40','ES35','IT40','SG30','HK50'}

def clasificar_activo(asset: str) -> str:
    """Retorna 'crypto', 'index' o 'forex'."""
    a = asset.upper().replace('-OTC','').replace('/','')
    for k in _CRYPTOS:
        if k in a:
            return 'crypto'
    for k in _INDICES:
        if k in a:
            return 'index'
    return 'forex'


def filtro_mercado_tranquilo(df, asset: str = '') -> bool:
    """
    Verifica que el mercado no esté en volatilidad extrema antes de evaluar señales.
    Filtros relajados para permitir suficientes señales en activos OTC y forex normales.
    Retorna True si apto para operar, False solo si hay volatilidad EXTREMA.
    """
    if len(df) < 20:
        return True  # sin datos suficientes, no bloqueamos

    tipo = clasificar_activo(asset)
    u = df.iloc[-1]

    # ── Filtro ATR — solo bloquea volatilidad EXTREMA ──────────────────────
    # Límites generosos: forex 0.006 (60 pips), índices 30 pts, crypto $200
    atr = float(u.get('atr', 0))
    if atr > 0:
        limites_atr = {'forex': 0.006, 'index': 30.0, 'crypto': 200.0}
        if atr > limites_atr.get(tipo, 0.006):
            return False

    # ── Filtro de velas monstruo (spike extremo único) ─────────────────────
    # Solo bloquea si una vela individual es > 4× el promedio de cuerpos
    if len(df) >= 20:
        cuerpos_20 = df['body'].iloc[-20:].mean()
        if cuerpos_20 > 0 and df['body'].iloc[-5:].max() > 4.5 * cuerpos_20:
            return False

    return True


def _agrupar_sr_local(niveles, tolerancia):
    if not niveles:
        return []
    niveles = sorted(float(n) for n in niveles)
    grupos = []
    actual = [niveles[0]]
    for n in niveles[1:]:
        if abs(n - actual[-1]) <= tolerancia:
            actual.append(n)
        else:
            grupos.append(sum(actual) / len(actual))
            actual = [n]
    grupos.append(sum(actual) / len(actual))
    return grupos


def _precio_en_zona_sr(df, direccion):
    if len(df) < 20:
        return False, None
    u = df.iloc[-1]
    atr = max(float(u.get('atr', float(u['high']) - float(u['low']))), 1e-9)
    tol_zona = atr * SR_TOLERANCIA_ATR
    tol_agrupar = max(atr * 0.55, abs(float(u['close'])) * 0.00008, 1e-8)
    seg = df.iloc[-70:-1] if len(df) >= 70 else df.iloc[:-1]
    if len(seg) < 12:
        return False, None

    if direccion == 'CALL':
        vals = seg['low'].astype(float).tolist()
        swings = [
            vals[i] for i in range(1, len(vals) - 1)
            if vals[i] <= vals[i - 1] and vals[i] <= vals[i + 1]
        ]
        niveles = _agrupar_sr_local(swings, tol_agrupar * 1.7)
        precio_ref = min(float(u['low']), float(u['close']))
    else:
        vals = seg['high'].astype(float).tolist()
        swings = [
            vals[i] for i in range(1, len(vals) - 1)
            if vals[i] >= vals[i - 1] and vals[i] >= vals[i + 1]
        ]
        niveles = _agrupar_sr_local(swings, tol_agrupar * 1.7)
        precio_ref = max(float(u['high']), float(u['close']))

    for nivel in niveles:
        toques = sum(1 for v in vals if abs(v - nivel) <= tol_agrupar * 1.5)
        if toques >= 2 and abs(precio_ref - nivel) <= tol_zona:
            return True, nivel
    return False, None


def validar_filtro_calidad_direccional(df, direccion, asset=''):
    """
    Filtro maestro para todas las estrategias — v3, adaptado por tipo de mercado.

    MERCADO NORMAL (volumen real):
      · MFM >= umbral       presión de precio por vela
      · CMF > 0 / < 0       flujo de dinero neto 10 velas
      · Stochastic           evita entrar en zona extrema contraria
      · EMA9 vs EMA21        tendencia corto plazo alineada
      · OBV > SMA10 + ↑      volumen acumulado confirmando (filtro duro)

    MERCADO OTC (volumen sintético — IQ Option lo genera artificialmente):
      Los mismos 4 filtros base (MFM, CMF, Stoch, EMA) aplican igual.
      OBV se reemplaza por dos medidas de flujo de PRECIO puro:
      · ADL slope > 0 / < 0  MFM acumulado últimas 3 velas (momentum de flujo)
      · MFM promedio 3 velas  consistencia de presión en la dirección
      Ambos son más permisivos que el OBV porque el volumen OTC
      no aporta información adicional — solo el precio importa.
    """
    if len(df) < 20:
        return False, "datos insuficientes", {}
    u     = df.iloc[-1]
    prev  = df.iloc[-2] if len(df) >= 2 else u
    prev2 = df.iloc[-3] if len(df) >= 3 else prev

    mfm_actual = float(u.get('mfm', 0))
    cmf        = float(u.get('cmf', 0))
    stoch      = float(u.get('stoch_k', 50))
    ema9       = float(u.get('ema9',  u.get('close', 0)))
    ema21      = float(u.get('ema21', u.get('close', 0)))
    mfm_min    = _mfm_minimo_para_asset(asset)

    # ── Detectar si hay volumen real o sintético (OTC) ────────────────────
    vol_std = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    tiene_volumen_real = vol_std >= 0.005   # OTC: variación casi nula

    # ── OBV (mercado normal) ──────────────────────────────────────────────
    obv_actual   = float(u.get('obv', 0))
    obv_sma      = float(u.get('obv_sma', obv_actual))
    obv_prev     = float(prev.get('obv', obv_actual))
    obv_prev2    = float(prev2.get('obv', obv_prev))
    obv_subiendo = (obv_actual > obv_prev) and (obv_actual > obv_prev2)
    obv_bajando  = (obv_actual < obv_prev) and (obv_actual < obv_prev2)

    # ── ADL slope y MFM promedio (OTC) ───────────────────────────────────
    # adl_slope = adl[-1] - adl[-4] = suma de MFV últimas 3 velas
    # Para OTC (volumen constante) esto equivale a suma de MFM de 3 velas
    adl_slope   = float(u.get('adl_slope', 0))
    mfm_prev    = float(prev.get('mfm', 0))
    mfm_prev2   = float(prev2.get('mfm', 0))
    mfm_avg3    = (mfm_actual + mfm_prev + mfm_prev2) / 3.0   # promedio MFM 3 velas
    adl_actual  = float(u.get('adl', 0))
    adl_ema_val = float(u.get('adl_ema', adl_actual))          # EMA5 del ADL

    datos_base = {
        'mfm': mfm_actual, 'cmf': cmf,
        'adl_slope': round(adl_slope, 4),
        'obv': round(obv_actual, 0),
    }

    # ══════════════════════════════════════════════════════════════════════
    # FILTROS COMUNES (aplican SIEMPRE — normal y OTC)
    # ══════════════════════════════════════════════════════════════════════
    if direccion == 'CALL':
        if mfm_actual < mfm_min:
            return False, f"MFM={mfm_actual:.2f} bajo umbral {mfm_min:.2f}", datos_base
        if cmf <= 0:
            return False, f"CMF(10)={cmf:.3f} sin flujo comprador", datos_base
        if stoch >= 80:
            return False, f"Stoch={stoch:.1f} en sobrecompra", datos_base
        if ema9 <= ema21:
            return False, "EMA9 bajo EMA21 — tendencia bajista", datos_base

        # ── Confirmación de flujo según tipo de mercado ───────────────────
        if tiene_volumen_real:
            # NORMAL: OBV debe estar subiendo (pendiente alcista)
            if not obv_subiendo:
                return False, "OBV sin tendencia alcista — momentum débil", datos_base
            flujo_tag = f"OBV↑ OK"
        else:
            # OTC: ADL slope positivo = MFM acumulado positivo en 3 velas
            if adl_slope <= 0:
                return False, f"ADL slope={adl_slope:.4f} sin momentum comprador", datos_base
            # MFM promedio debe ser positivo (señal consistente, no 1 vela aislada)
            if mfm_avg3 <= 0:
                return False, f"MFM avg3={mfm_avg3:.3f} sin presión compradora sostenida", datos_base
            flujo_tag = f"ADL↑ MFM_avg={mfm_avg3:.2f}"

        return True, (
            f"MFM={mfm_actual:.2f}, CMF={cmf:.3f}, Stoch={stoch:.1f}, "
            f"EMA9>EMA21, {flujo_tag}"
        ), datos_base

    # ══════════════════════════════════════════════════════════════════════
    # PUT
    # ══════════════════════════════════════════════════════════════════════
    if mfm_actual > -mfm_min:
        return False, f"MFM={mfm_actual:.2f} sin presión vendedora", datos_base
    if cmf >= 0:
        return False, f"CMF(10)={cmf:.3f} sin flujo vendedor", datos_base
    if stoch <= 20:
        return False, f"Stoch={stoch:.1f} en sobreventa", datos_base
    if ema9 >= ema21:
        return False, "EMA9 sobre EMA21 — tendencia alcista", datos_base

    if tiene_volumen_real:
        # NORMAL: OBV debe estar bajando (pendiente bajista)
        if not obv_bajando:
            return False, "OBV sin tendencia bajista — momentum débil", datos_base
        flujo_tag = f"OBV↓ OK"
    else:
        if adl_slope >= 0:
            return False, f"ADL slope={adl_slope:.4f} sin momentum vendedor", datos_base
        if mfm_avg3 >= 0:
            return False, f"MFM avg3={mfm_avg3:.3f} sin presión vendedora sostenida", datos_base
        flujo_tag = f"ADL↓ MFM_avg={mfm_avg3:.2f}"

    return True, (
        f"MFM={mfm_actual:.2f}, CMF={cmf:.3f}, Stoch={stoch:.1f}, "
        f"EMA9<EMA21, {flujo_tag}"
    ), datos_base


# ─────────────────────────────────────────────
# ESTRATEGIAS ESPECIALIZADAS
# ─────────────────────────────────────────────

def estrategia_bollinger(df, regimen, asset=''):
    """
    Bollinger Bands v4 — Reversión a la media (spec actualizado 24-Mar-2026).

    FILTROS DUROS (todos deben cumplirse):
      · Precio toca banda SIN romperla (cierre vela dentro de la banda)
      · Sombra > 3× cuerpo de vela (señal de fatiga/rechazo real)
      · Volumen vela actual ≤ promedio últimas 5 velas (mercado tranquilo)
      · CALL: EMA10 > EMA20 | PUT: EMA10 < EMA20

    PARÁMETROS POR TIPO DE ACTIVO:
      · Forex: período 20 + desviación 2.0 (default bb_upper/bb_lower)
      · Índices: período 20 + desviación 1.8 (bandas recalculadas)
      · Crypto: período 25 + desviación 2.0 (bandas recalculadas)
    """
    if len(df) < 30:
        return None, 0

    tipo = clasificar_activo(asset)

    # ── Bandas de Bollinger dinámicas por tipo de activo ─────────────────
    c_series = df['close']
    if tipo == 'crypto':
        periodo, desv = 25, 2.0
    elif tipo == 'index':
        periodo, desv = 20, 1.8
    else:  # forex
        periodo, desv = 20, 2.0

    if tipo != 'forex' and len(df) >= periodo:
        bb_mid_s = c_series.rolling(periodo).mean()
        bb_std_s = c_series.rolling(periodo).std()
        bb_up_s  = bb_mid_s + desv * bb_std_s
        bb_lo_s  = bb_mid_s - desv * bb_std_s
        bb_up  = float(bb_up_s.iloc[-1])
        bb_lo  = float(bb_lo_s.iloc[-1])
        bb_mid = float(bb_mid_s.iloc[-1])
    else:
        bb_up  = float(df.iloc[-1].get('bb_upper', 0))
        bb_lo  = float(df.iloc[-1].get('bb_lower', 0))
        bb_mid = float(df.iloc[-1].get('bb_mid', 0))

    if bb_up == 0 or bb_lo == 0:
        return None, 0

    u   = df.iloc[-1]
    p   = df.iloc[-2]
    c   = float(u['close'])
    atr = max(float(u.get('atr', (float(u['high']) - float(u['low'])))), 1e-9)

    # ── Filtro de ancho de banda excesivo ────────────────────────────────
    bw_now = bb_up - bb_lo
    bw_avg = (df.iloc[-20:]['bb_upper'] - df.iloc[-20:]['bb_lower']).mean()
    squeeze = bw_now < bw_avg * 0.80
    if bw_now > atr * 6:
        return None, 0

    # ── EMA10 vs EMA20 (spec: EMA, no SMA) ───────────────────────────────
    ema10_bull = bool(u.get('ema10_sobre_ema20', 0))  # True si EMA10 > EMA20

    # Cruce EMA10/20 reciente (bonus de puntuación)
    cruce_bull = bool(u.get('ma_cruce_bull', False))
    cruce_bear = bool(u.get('ma_cruce_bear', False))

    # ── Confirmación de Cruce EMA Rápido (EMA5 × EMA10) ─────────────────
    ema5_val   = float(u.get('ema5',  c))
    ema10_val  = float(u.get('ema10', c))
    ema20_val  = float(u.get('ema20', c))
    ema50_val  = float(u.get('ema50', c))

    # Cruce fresco EMA5/EMA10 en las últimas 2 velas (señal muy temprana)
    cruce_ema5_bull = False
    cruce_ema5_bear = False
    if len(df) >= 3 and 'ema5' in df.columns and 'ema10' in df.columns:
        prev2_e5  = float(df['ema5'].iloc[-2])
        prev2_e10 = float(df['ema10'].iloc[-2])
        cruce_ema5_bull = (prev2_e5 <= prev2_e10) and (ema5_val > ema10_val)
        cruce_ema5_bear = (prev2_e5 >= prev2_e10) and (ema5_val < ema10_val)
    else:
        cruce_ema5_bull = ema5_val > ema10_val
        cruce_ema5_bear = ema5_val < ema10_val

    # Alineación multi-EMA (EMA5 > EMA10 > EMA20 > EMA50 = alcista perfecto)
    alin_bull_full = (ema5_val > ema10_val and ema10_val > ema20_val and
                      (ema50_val == 0 or ema20_val > ema50_val))
    alin_bear_full = (ema5_val < ema10_val and ema10_val < ema20_val and
                      (ema50_val == 0 or ema20_val < ema50_val))

    rsi      = float(u['rsi'])
    macd_h   = float(u['macd_hist'])
    macd_h_p = float(p['macd_hist'])

    # ── Cálculo de sombra y cuerpo ────────────────────────────────────────
    body  = max(float(u['body']), 1e-9)
    lwick = float(u['lower_wick'])
    uwick = float(u['upper_wick'])

    # ── Volumen relativo ──────────────────────────────────────────────────
    vol_ratio5 = float(u.get('vol_ratio5', 1.0))
    vol_r      = float(u.get('vol_ratio',  1.0))   # vol actual / avg_20
    vol_ok     = vol_ratio5 <= 4.0   # bloquear solo spikes extremos

    # ── Detección S/R cercano al punto de toque (dentro de 1.8×ATR) ──────
    def _sr_bollinger_check(precio_ref, tipo='support'):
        """True si hay nivel S/R fuerte (mín. 2 toques) dentro de 1.8×ATR."""
        tol_zona = atr * 1.8
        tol_agr  = max(atr * 0.40, 0.0001)
        seg = df.iloc[-60:-1]
        if tipo == 'support':
            vals = seg['low'].astype(float).tolist()
        else:
            vals = seg['high'].astype(float).tolist()
        swings = [vals[i] for i in range(1, len(vals)-1)
                  if (tipo == 'support' and vals[i] <= vals[i-1] and vals[i] <= vals[i+1]) or
                     (tipo != 'support' and vals[i] >= vals[i-1] and vals[i] >= vals[i+1])]
        niveles = _agrupar_niveles(swings, tol_agr * 1.5)
        # Contar toques de cada nivel y exigir mínimo 2
        for niv in niveles:
            toques = sum(1 for v in vals if abs(v - niv) <= tol_agr * 1.2)
            if toques >= 2 and abs(niv - precio_ref) <= tol_zona:
                return True
        return False

    factores = 0
    dir_     = None

    # ══════════════════════════════════════════════════════════════════════
    # CALL — precio en/cerca banda inferior, EMA10 > EMA20
    # ══════════════════════════════════════════════════════════════════════
    call_permitido = regimen in ('BULL', 'SIDEWAYS')

    toca_inferior = (
        c <= bb_lo * 1.002 and
        c >= bb_lo * 0.995
    ) or (
        float(u['low']) <= bb_lo * 1.001 and c > bb_lo * 1.001
    )

    # Detectar volumen sintético (OTC)
    _boll_vol_std = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    _boll_otc     = _boll_vol_std < 0.005

    # Filtros duros CALL: vol > 1.35 (skip en OTC), RSI < 52, soporte cercano
    hay_soporte = _sr_bollinger_check(float(u['low']), tipo='support')

    _vol_ok_call = _boll_otc or vol_r >= 1.35
    if toca_inferior and ema10_bull and vol_ok and call_permitido and _vol_ok_call and rsi < 52 and hay_soporte:
        # ── Filtro de sombra de rechazo ───────────────────────────────────────
        if lwick >= body * 1.0 or regimen == 'SIDEWAYS':
            factores += 10  # bono por sombra de rechazo

        dir_ = 'CALL'
        factores += 22

        # RSI (sobreventa — ya sabemos RSI < 52)
        if rsi < 25:   factores += 25
        elif rsi < 32: factores += 18
        elif rsi < 40: factores += 10
        elif rsi < 48: factores += 5

        # EMA alineación EMA10/20
        if cruce_bull:   factores += 18  # cruce dorado EMA10/20 reciente
        else:            factores += 10

        # Confirmación cruce EMA rápido (EMA5 × EMA10)
        if cruce_ema5_bull:        factores += 14
        elif ema5_val > ema10_val: factores += 6
        if alin_bull_full:         factores += 12

        if c > bb_lo:           factores += 10
        if bool(u['is_bull']):  factores += 10

        if lwick > body * 3.0:   factores += 18
        elif lwick > body * 1.5: factores += 11
        elif lwick > body * 0.8: factores += 5

        sr = float(u['stoch_rsi'])
        if sr < 0.20:   factores += 14
        elif sr < 0.30: factores += 8

        if macd_h > macd_h_p:  factores += 10

        cci = float(u['cci'])
        if cci < -120: factores += 14
        elif cci < -100: factores += 9
        elif cci < -70:  factores += 5

        if float(u.get('cmf', 0)) > 0:           factores += 6
        if float(u['obv']) > float(u['obv_sma']): factores += 6
        if squeeze:                                factores += 8

        # Volumen confirma
        if vol_r >= 1.6: factores += 8
        elif vol_r >= 1.32: factores += 4

        if regimen == 'SIDEWAYS': factores += 14
        elif regimen == 'BULL':   factores += 10

    # ══════════════════════════════════════════════════════════════════════
    # PUT — precio en/cerca banda superior, EMA10 < EMA20
    # ══════════════════════════════════════════════════════════════════════
    put_permitido = regimen in ('BEAR', 'SIDEWAYS')

    toca_superior = (
        c >= bb_up * 0.998 and
        c <= bb_up * 1.005
    ) or (
        float(u['high']) >= bb_up * 0.999 and c < bb_up * 0.999
    )

    # Filtros duros PUT: vol > 1.35 (skip en OTC), RSI > 48, resistencia cercana
    hay_resist = _sr_bollinger_check(float(u['high']), tipo='resistance')

    _vol_ok_put = _boll_otc or vol_r >= 1.35
    if toca_superior and (not ema10_bull) and vol_ok and put_permitido and dir_ is None and _vol_ok_put and rsi > 48 and hay_resist:
        if uwick >= body * 1.0 or regimen == 'SIDEWAYS':
            factores += 10

        dir_ = 'PUT'
        factores += 22

        # RSI (sobrecompra — ya sabemos RSI > 48)
        if rsi > 75:   factores += 25
        elif rsi > 68: factores += 18
        elif rsi > 60: factores += 10
        elif rsi > 52: factores += 5

        if cruce_bear:  factores += 18
        else:           factores += 10

        if cruce_ema5_bear:        factores += 14
        elif ema5_val < ema10_val: factores += 6
        if alin_bear_full:         factores += 12

        if c < bb_up:              factores += 10
        if not bool(u['is_bull']): factores += 10

        if uwick > body * 3.0:   factores += 18
        elif uwick > body * 1.5: factores += 11
        elif uwick > body * 0.8: factores += 5

        sr = float(u['stoch_rsi'])
        if sr > 0.80:   factores += 14
        elif sr > 0.70: factores += 8

        if macd_h < macd_h_p:  factores += 10

        cci = float(u['cci'])
        if cci > 120:  factores += 14
        elif cci > 100: factores += 9
        elif cci > 70:  factores += 5

        if float(u.get('cmf', 0)) < 0:            factores += 6
        if float(u['obv']) < float(u['obv_sma']):  factores += 6
        if squeeze:                                 factores += 8

        if vol_r >= 1.6: factores += 8
        elif vol_r >= 1.32: factores += 4

        if regimen == 'SIDEWAYS': factores += 14
        elif regimen == 'BEAR':   factores += 10

    return (dir_, min(factores, 100)) if dir_ and factores >= MIN_SCORE_PARA_OPERAR else (None, 0)


def estrategia_donchian(df, regimen):
    """
    Donchian Breakout — estrategia de seguimiento de tendencia.
    Mercado óptimo: BULL y BEAR (breakouts reales).
    RECHAZA SIDEWAYS: en lateralización los breakouts son falsos el 70%+ del tiempo.
    """
    if len(df) < 12:
        return None, 0

    # Donchian NO opera en mercado lateral (genera demasiados falsos breakouts)
    if regimen == 'SIDEWAYS':
        return None, 0

    u  = df.iloc[-1]
    p  = df.iloc[-2]
    c  = float(u['close'])
    factores = 0
    dir_ = None

    if c > float(p['don5_high']) and float(u['macd']) > 0:
        dir_ = 'CALL'
        factores += 22
        rsi = float(u['rsi'])
        if 50 < rsi < 72:
            factores += 14
        if float(u['vol_ratio']) > 1.3:
            factores += 16  # volumen confirma el breakout
        elif float(u['vol_ratio']) > 1.1:
            factores += 8
        if float(u['obv']) > float(u['obv_sma']):
            factores += 10
        if float(u['body_ratio']) > 0.6:
            factores += 10
        if float(u['ema5']) > float(u['ema13']):
            factores += 10
        if regimen == 'BULL':
            factores += 18  # tendencia confirma dirección

    elif c < float(p['don5_low']) and float(u['macd']) < 0:
        dir_ = 'PUT'
        factores += 22
        rsi = float(u['rsi'])
        if 28 < rsi < 50:
            factores += 14
        if float(u['vol_ratio']) > 1.3:
            factores += 16
        elif float(u['vol_ratio']) > 1.1:
            factores += 8
        if float(u['obv']) < float(u['obv_sma']):
            factores += 10
        if float(u['body_ratio']) > 0.6:
            factores += 10
        if float(u['ema5']) < float(u['ema13']):
            factores += 10
        if regimen == 'BEAR':
            factores += 18

    return (dir_, min(factores, 100)) if dir_ and factores >= MIN_SCORE_PARA_OPERAR else (None, 0)


def estrategia_niveles(df, regimen):
    if len(df) < 12:
        return None, 0
    u  = df.iloc[-1]
    c  = u['close']
    s5 = u['sma5']
    ultimas4 = df.iloc[-5:-1]
    bodies = ultimas4['body_ratio'].tolist()
    velas_pequenas = all(b < 0.45 for b in bodies)
    if not velas_pequenas:
        return None, 0
    gap = abs(c - s5) / (s5 + 1e-10)
    if gap < 0.0005:
        return None, 0

    dir_ = 'CALL' if c > s5 else 'PUT'
    factores = 20
    if u['body_ratio'] > 0.55:
        factores += 15
    if u['vol_ratio'] > 1.2:
        factores += 12
    if u['cci'] > 60 and dir_ == 'CALL':
        factores += 10
    if u['cci'] < -60 and dir_ == 'PUT':
        factores += 10
    if u['rsi'] > 55 and dir_ == 'CALL':
        factores += 10
    if u['rsi'] < 45 and dir_ == 'PUT':
        factores += 10
    if u['ema5'] > u['ema9'] and dir_ == 'CALL':
        factores += 8
    if u['ema5'] < u['ema9'] and dir_ == 'PUT':
        factores += 8
    if (regimen == 'BULL' and dir_ == 'CALL') or (regimen == 'BEAR' and dir_ == 'PUT'):
        factores += 15

    return (dir_, min(factores, 100)) if factores >= MIN_SCORE_PARA_OPERAR else (None, 0)


def estrategia_fvg(df, regimen):
    """
    Fair Value Gap (Smart Money) — opera el relleno de gaps institucionales.
    Mercado óptimo: BULL y BEAR (necesita impulso direccional).
    En SIDEWAYS los gaps se llenan rápido y en ambas direcciones → menor fiabilidad.
    """
    if len(df) < 6:
        return None, 0

    u = df.iloc[-1]
    c = float(u['close'])

    # FVG en mercado lateral: penalizar score (gaps se cierran rápidamente sin dirección)
    multiplicador = 0.80 if regimen == 'SIDEWAYS' else 1.0

    for i in range(max(0, len(df) - 5), len(df) - 1):
        if i < 1 or i + 1 >= len(df):
            continue
        v1 = df.iloc[i - 1]
        v2 = df.iloc[i]
        v3 = df.iloc[i + 1]

        # FVG alcista: v1.low > v3.high (hueco alcista entre v1 y v3)
        if float(v1['low']) > float(v3['high']):
            fvg_hi = float(v1['low'])
            fvg_lo = float(v3['high'])
            if fvg_lo <= c <= fvg_hi:
                factores = 30
                if float(u['rsi']) < 60:
                    factores += 12
                if float(u['macd']) > 0:
                    factores += 12
                if float(u['vol_ratio']) > 1.2:
                    factores += 10
                if float(u['body_ratio']) > 0.5:
                    factores += 8
                if regimen == 'BULL':
                    factores += 18  # FVG en tendencia alcista = señal premium
                elif regimen == 'SIDEWAYS':
                    factores += 5   # menos confiable
                factores = int(factores * multiplicador)
                if factores >= MIN_SCORE_PARA_OPERAR:
                    return 'CALL', min(factores, 100)

        # FVG bajista
        if float(v1['high']) < float(v3['low']):
            fvg_lo = float(v1['high'])
            fvg_hi = float(v3['low'])
            if fvg_lo <= c <= fvg_hi:
                factores = 30
                if float(u['rsi']) > 40:
                    factores += 12
                if float(u['macd']) < 0:
                    factores += 12
                if float(u['vol_ratio']) > 1.2:
                    factores += 10
                if float(u['body_ratio']) > 0.5:
                    factores += 8
                if regimen == 'BEAR':
                    factores += 18
                elif regimen == 'SIDEWAYS':
                    factores += 5
                factores = int(factores * multiplicador)
                if factores >= MIN_SCORE_PARA_OPERAR:
                    return 'PUT', min(factores, 100)

    return None, 0


def estrategia_flujo(df, regimen):
    if len(df) < 15:
        return None, 0
    u = df.iloc[-1]
    if u['vol_ratio'] < 1.35:
        return None, 0

    # Flujo de volumen últimas 7 velas
    ultima7 = df.iloc[-8:-1]
    buy_v  = ultima7[ultima7['is_bull'] == True]['volume'].sum()
    sell_v = ultima7[ultima7['is_bull'] == False]['volume'].sum()
    total  = buy_v + sell_v + 1e-10
    pfi    = (buy_v - sell_v) / total * 100

    dir_ = None
    factores = 0

    if buy_v >= sell_v * 1.3 and pfi > 30 and u['is_bull']:
        dir_ = 'CALL'
        factores = 25
        if pfi > 50:
            factores += 15
        if u['obv'] > u['obv_sma']:
            factores += 12
        if u['macd'] > 0:
            factores += 10
        if u['body_ratio'] > 0.5:
            factores += 8
        if u['ema5'] > u['ema9']:
            factores += 8
        if regimen == 'BULL':
            factores += 12

    elif sell_v >= buy_v * 1.3 and pfi < -30 and not u['is_bull']:
        dir_ = 'PUT'
        factores = 25
        if pfi < -50:
            factores += 15
        if u['obv'] < u['obv_sma']:
            factores += 12
        if u['macd'] < 0:
            factores += 10
        if u['body_ratio'] > 0.5:
            factores += 8
        if u['ema5'] < u['ema9']:
            factores += 8
        if regimen == 'BEAR':
            factores += 12

    return (dir_, min(factores, 100)) if dir_ and factores >= MIN_SCORE_PARA_OPERAR else (None, 0)


# ─────────────────────────────────────────────────────────────────────────────
# ESTRATEGIA 6 — SOPORTE Y RESISTENCIA (Rebote en nivel fuerte)
# ─────────────────────────────────────────────────────────────────────────────

def _agrupar_niveles(niveles, tolerancia):
    """Agrupa niveles horizontales cercanos en uno solo (promedio)."""
    if not niveles:
        return []
    agrupados = []
    for n in sorted(niveles):
        if agrupados and abs(n - agrupados[-1]) <= tolerancia:
            agrupados[-1] = (agrupados[-1] + n) / 2  # promedio móvil
        else:
            agrupados.append(float(n))
    return agrupados


def estrategia_soporte_resistencia(df, regimen):
    """
    S/R v4 — Zonas horizontales fuertes + EMA10/20 + vela de reversión (spec 24-Mar-2026).

    CALL en soporte: martillo o pin alcista + EMA10 > EMA20 + EMA20 cerca de BB_mid
                     + volumen estable (sin picos > 20%)
    PUT en resistencia: estrella invertida o pin bajista + EMA10 < EMA20
                        + EMA20 cerca de BB_mid + volumen estable

    Cruce EMA reciente: +18 pts | EMA alineada: +10 pts | EMA contraria: −12 pts
    """
    if len(df) < 30:
        return None, 0

    ventana = df.iloc[-80:] if len(df) >= 80 else df
    u = df.iloc[-1]
    p = df.iloc[-2]
    c = float(u['close'])
    atr = max(float(u.get('atr', (float(u['high']) - float(u['low'])) * 2)), 0.0001)
    tol = max(atr * 0.40, 0.0001)

    # ── EMA10/20 estado (spec actualizado usa EMA, no SMA) ───────────────
    ema10_bull = bool(u.get('ema10_sobre_ema20', 0))  # EMA10 > EMA20
    cruce_bull = bool(u.get('ma_cruce_bull', False))
    cruce_bear = bool(u.get('ma_cruce_bear', False))

    # Para compatibilidad también leer SMA10/20
    ma10_bull  = bool(u.get('ma10_sobre_ma20', 0))

    # ── Confirmación de Cruce EMA Rápido (EMA5 × EMA10 × EMA50) ─────────
    ema5_val_sr  = float(u.get('ema5',  c))
    ema10_val_sr = float(u.get('ema10', c))
    ema20_val_sr = float(u.get('ema20', c))
    ema50_val_sr = float(u.get('ema50', c))

    cruce_ema5_bull_sr = False
    cruce_ema5_bear_sr = False
    if len(df) >= 3 and 'ema5' in df.columns and 'ema10' in df.columns:
        _pe5  = float(df['ema5'].iloc[-2])
        _pe10 = float(df['ema10'].iloc[-2])
        cruce_ema5_bull_sr = (_pe5 <= _pe10) and (ema5_val_sr > ema10_val_sr)
        cruce_ema5_bear_sr = (_pe5 >= _pe10) and (ema5_val_sr < ema10_val_sr)
    else:
        cruce_ema5_bull_sr = ema5_val_sr > ema10_val_sr
        cruce_ema5_bear_sr = ema5_val_sr < ema10_val_sr

    alin_bull_sr = (ema5_val_sr > ema10_val_sr and ema10_val_sr > ema20_val_sr and
                    (ema50_val_sr == 0 or ema20_val_sr > ema50_val_sr))
    alin_bear_sr = (ema5_val_sr < ema10_val_sr and ema10_val_sr < ema20_val_sr and
                    (ema50_val_sr == 0 or ema20_val_sr < ema50_val_sr))

    # ── Filtro: EMA20 cerca de BB midline (±5% del ATR) ──────────────────
    ema20_val = float(u.get('ema20', c))
    bb_mid    = float(u.get('bb_mid', c))
    ema20_cerca_bbmid = abs(ema20_val - bb_mid) <= atr * 1.5

    # ── Filtro de volumen (sin spikes extremos) ───────────────────────────
    vol_mean = float(u.get('vol_sma20', 0))
    vol_ok = True
    if vol_mean > 0:
        vol_ratio_max10 = float(df['vol_ratio'].iloc[-10:].max()) if 'vol_ratio' in df.columns else 1.0
        vol_ok = vol_ratio_max10 <= 4.0  # solo bloquear spikes extremos

    # Detectar volumen sintético (activos OTC: vol_ratio siempre ~1.0)
    _sr_vol_std   = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    _sr_es_otc    = _sr_vol_std < 0.005   # OTC: variación nula → no aplicar filtro duro

    # ── Vela de reversión alcista: martillo o pin bull ────────────────────
    lw = float(u.get('lower_wick', 0))
    uw = float(u.get('upper_wick', 0))
    b  = max(float(u.get('body', 0.0001)), 1e-9)
    es_martillo      = lw >= b * 2.0 and uw <= b * 0.5 and bool(u.get('is_bull', False))
    es_pin_bull      = lw >= b * 1.5 and c > float(u['open'])
    es_estrella_inv  = uw >= b * 2.0 and lw <= b * 0.5 and not bool(u.get('is_bull', False))
    es_pin_bear      = uw >= b * 1.5 and c < float(u['open'])

    # ── Fractales de 3 velas ─────────────────────────────────────────────
    lows_all  = [float(ventana.iloc[i]['low'])  for i in range(len(ventana))]
    highs_all = [float(ventana.iloc[i]['high']) for i in range(len(ventana))]

    soportes_raw     = []
    resistencias_raw = []
    for i in range(1, len(ventana) - 1):
        if lows_all[i]  <= lows_all[i-1]  and lows_all[i]  <= lows_all[i+1]:
            soportes_raw.append(lows_all[i])
        if highs_all[i] >= highs_all[i-1] and highs_all[i] >= highs_all[i+1]:
            resistencias_raw.append(highs_all[i])

    soportes     = _agrupar_niveles(soportes_raw,     tol * 1.5)
    resistencias = _agrupar_niveles(resistencias_raw, tol * 1.5)

    def contar_toques(nivel, serie, tol_):
        return sum(1 for v in serie if abs(v - nivel) <= tol_)

    rsi     = float(u.get('rsi',      50))
    vol_r   = float(u.get('vol_ratio', 1.0))
    macd_h  = float(u.get('macd_hist', 0))
    cmf_val = float(u.get('cmf',      0))

    # ── SOPORTE → CALL ────────────────────────────────────────────────────
    for s in soportes:
        toco_low  = abs(float(u['low']) - s) <= tol * 1.5
        toco_prev = abs(float(p['low']) - s) <= tol * 1.8
        near_zone = abs(c - s) <= tol * 2.5
        if not (toco_low or toco_prev or near_zone):
            continue
        toques = contar_toques(s, lows_all, tol * 1.2)
        if toques < 2:
            continue

        # ── FILTRO DURO: requiere vela de reversión alcista (spec) ────────
        if not (es_martillo or es_pin_bull):
            continue

        # ── FILTRO DURO: EMA10 > EMA20 para CALL ─────────────────────────
        if not ema10_bull:
            continue

        # ── FILTRO DURO: volumen > 1.35 (confirmación de fuerza) [skip OTC] ─
        if not _sr_es_otc and vol_r < 1.35:
            continue

        # ── FILTRO DURO: RSI < 52 para CALL (zona neutra-bajista) ────────
        if rsi >= 52:
            continue

        # ── FILTRO: volumen estable ───────────────────────────────────────
        if not vol_ok:
            continue

        last3 = df.iloc[-3:]
        bulls3 = int(sum(1 for _, r in last3.iterrows() if r['is_bull']))

        score = 32
        score += min(toques * 8, 24)

        # ── EMA10/20 (ya verificado que es alcista) ─────────────────────
        if cruce_bull:  score += 18  # cruce dorado EMA10/20 reciente
        else:           score += 10  # EMA10 > EMA20

        # ── Cruce EMA rápido (EMA5 × EMA10) ────────────────────────────
        if cruce_ema5_bull_sr:          score += 14  # cruce fresco EMA5/10
        elif ema5_val_sr > ema10_val_sr: score += 6   # EMA5 sobre EMA10
        # Alineación multi-EMA completa (EMA5>EMA10>EMA20>EMA50)
        if alin_bull_sr: score += 12

        # ── EMA20 cerca de BB midline ───────────────────────────────────
        if ema20_cerca_bbmid: score += 8

        # ── Vela de reversión ─────────────────────────────────────────
        if es_martillo:  score += 16  # martillo perfecto
        elif es_pin_bull: score += 10  # pin alcista

        if toco_low:          score += 14
        elif toco_prev:       score += 8
        if bulls3 >= 2:       score += 10
        if rsi < 50:          score += 8
        if rsi < 38:          score += 6
        if macd_h > 0:        score += 6
        if cmf_val > 0:       score += 5
        if regimen in ('BULL', 'SIDEWAYS'): score += 8

        if score >= MIN_SCORE_PARA_OPERAR:
            return 'CALL', min(score, 100)

    # ── RESISTENCIA → PUT ─────────────────────────────────────────────────
    for r in resistencias:
        toco_high = abs(float(u['high']) - r) <= tol * 1.5
        toco_prev = abs(float(p['high']) - r) <= tol * 1.8
        near_zone = abs(c - r) <= tol * 2.5
        if not (toco_high or toco_prev or near_zone):
            continue
        toques = contar_toques(r, highs_all, tol * 1.2)
        if toques < 2:
            continue

        # ── FILTRO DURO: requiere vela de reversión bajista (spec) ───────
        if not (es_estrella_inv or es_pin_bear):
            continue

        # ── FILTRO DURO: EMA10 < EMA20 para PUT ──────────────────────────
        if ema10_bull:
            continue

        # ── FILTRO DURO: volumen > 1.35 (confirmación de fuerza) [skip OTC] ─
        if not _sr_es_otc and vol_r < 1.35:
            continue

        # ── FILTRO DURO: RSI > 48 para PUT (zona neutra-alcista) ─────────
        if rsi <= 48:
            continue

        # ── FILTRO: volumen estable ───────────────────────────────────────
        if not vol_ok:
            continue

        last3 = df.iloc[-3:]
        bears3 = int(sum(1 for _, row in last3.iterrows() if not row['is_bull']))

        score = 32
        score += min(toques * 8, 24)

        # ── EMA10/20 (ya verificado que es bajista) ─────────────────────
        if cruce_bear:  score += 18  # cruce muerte EMA10/20 reciente
        else:           score += 10  # EMA10 < EMA20

        # ── Cruce EMA rápido (EMA5 × EMA10) ────────────────────────────
        if cruce_ema5_bear_sr:          score += 14  # cruce fresco EMA5/10
        elif ema5_val_sr < ema10_val_sr: score += 6   # EMA5 bajo EMA10
        # Alineación multi-EMA completa (EMA5<EMA10<EMA20<EMA50)
        if alin_bear_sr: score += 12

        # ── EMA20 cerca de BB midline ───────────────────────────────────
        if ema20_cerca_bbmid: score += 8

        # ── Vela de reversión ─────────────────────────────────────────
        if es_estrella_inv: score += 16  # estrella invertida perfecta
        elif es_pin_bear:   score += 10  # pin bajista

        if toco_high:         score += 14
        elif toco_prev:       score += 8
        if bears3 >= 2:       score += 10
        if rsi > 50:          score += 8
        if rsi > 62:          score += 6
        if macd_h < 0:        score += 6
        if cmf_val < 0:       score += 5
        if regimen in ('BEAR', 'SIDEWAYS'): score += 8

        if score >= MIN_SCORE_PARA_OPERAR:
            return 'PUT', min(score, 100)



def estrategia_ia_avanzada(df, regimen):
    """
    IA Avanzada v1 — Motor de predicción de 7 capas con ponderación dinámica.

    Analiza la confluencia de múltiples señales técnicas para maximizar la
    probabilidad de acierto. A diferencia de ia_pro (presión de velas), este
    motor evalúa la estructura global del mercado.

    7 Capas de análisis:
      1. Alineación multi-EMA  (EMA9 > EMA20 > EMA50 = alcista)
      2. Momentum cruzado      (RSI + StochRSI + MACD)
      3. Presión de volumen    (OBV + CMF + Vol ratio)
      4. Estructura de velas   (patrones de cuerpo/mechas últimas 5 velas)
      5. Fuerza direccional    (ADX + DI+/DI-)
      6. Aceleración de precio (ROC + pendiente EMA rápida)
      7. Confluencia régimen   (bonus si el régimen macro confirma)

    Umbral mínimo: 62 puntos — más exigente que las estrategias de 1 minuto.
    Vencimiento: 1 minuto.
    """
    import numpy as np
    if len(df) < 30:
        return None, 0

    u     = df.iloc[-1]
    close = float(u['close'])
    open_ = float(u['open'])

    # Indicadores base
    ema9   = float(u.get('ema9',  0) or df['close'].ewm(span=9,  adjust=False).mean().iloc[-1])
    ema20  = float(u.get('ema20', 0) or df['close'].ewm(span=20, adjust=False).mean().iloc[-1])
    ema50  = float(u.get('ema50', 0) or df['close'].ewm(span=50, adjust=False).mean().iloc[-1])
    rsi    = float(u.get('rsi',   50))
    stoch  = float(u.get('stoch_rsi', 0.5))
    macd_h = float(u.get('macd_hist', 0))
    adx    = float(u.get('adx',   0))
    pdi    = float(u.get('plus_di', 0))
    mdi    = float(u.get('minus_di', 0))
    cmf    = float(u.get('cmf',   0))
    vol_r  = float(u.get('vol_ratio', 1.0))
    is_bull = bool(u.get('is_bull', False))

    # ── Filtro 1: no operar lateral sin fuerza ───────────────────────────
    if regimen == 'SIDEWAYS' and adx < 22:
        return None, 0

    # ── Filtro 2: EMA9 debe estar entre EMA20 y los límites (no cruzado) ─
    if ema9 == 0 or ema20 == 0 or ema50 == 0:
        return None, 0

    # OBV slope (ultimas 8 velas)
    obv_bull = obv_bear = False
    if 'obv' in df.columns and len(df) >= 8:
        obv_slice = df['obv'].iloc[-8:]
        ref = abs(float(obv_slice.iloc[0])) + 1e-9
        slope = (float(obv_slice.iloc[-1]) - float(obv_slice.iloc[0])) / ref
        obv_bull = slope >  0.003
        obv_bear = slope < -0.003

    # ROC 5 barras
    roc5 = 0.0
    if len(df) >= 6:
        prev5 = float(df['close'].iloc[-6])
        roc5 = (close - prev5) / (prev5 + 1e-10)

    # EMA9 slope (aceleración de corto plazo)
    ema9_slope = 0.0
    if 'ema9' in df.columns and len(df) >= 4:
        ema9_slope = (float(df['ema9'].iloc[-1]) - float(df['ema9'].iloc[-4])) / (float(df['ema9'].iloc[-4]) + 1e-10)

    # Estructura de velas últimas 5
    win5 = df.iloc[-5:]
    n_bull_5 = sum(1 for _, r in win5.iterrows() if r.get('is_bull', False))
    n_bear_5 = len(win5) - n_bull_5
    body_ratio = float(u.get('body_ratio', 0.5))
    upper_wick = float(u.get('upper_wick', 0))
    lower_wick = float(u.get('lower_wick', 0))
    body_size  = max(float(u.get('body', 0)), 1e-10)

    # ═══════════════ EVALUACIÓN ALCISTA (CALL) ════════════════════════════
    bull_ok = (ema9 > ema20) and (pdi > mdi) and (rsi < 72) and (stoch < 0.85)
    bear_ok = (ema9 < ema20) and (mdi > pdi) and (rsi > 28) and (stoch > 0.15)

    if not bull_ok and not bear_ok:
        return None, 0

    if bull_ok and not bear_ok:
        # ── Filtros duros CALL ──────────────────────────────────────────
        if rsi > 75:           return None, 0   # sobrecompra severa
        if adx < 18:           return None, 0   # mercado sin dirección
        if not is_bull:        return None, 0   # vela actual debe ser alcista

        sc = 0

        # Capa 1: Alineación EMA
        if ema9 > ema20 > ema50:    sc += 20
        elif ema9 > ema20:           sc += 10

        # Capa 2: Momentum
        if 42 <= rsi <= 62:          sc += 15
        elif 30 <= rsi < 42:         sc += 8
        if stoch < 0.25:             sc += 10
        elif stoch < 0.45:           sc += 5
        if macd_h > 0:               sc += 10

        # Capa 3: Volumen
        if obv_bull:                 sc += 12
        elif obv_bear:               sc -= 8
        if cmf > 0.04:               sc += 8
        elif cmf > 0.01:             sc += 4
        if vol_r > 1.4:              sc += 8
        elif vol_r > 1.15:           sc += 4

        # Capa 4: Estructura de velas
        if n_bull_5 >= 3:            sc += 8
        if body_ratio > 0.60:        sc += 8   # vela de cuerpo fuerte
        if lower_wick > body_size * 0.5: sc += 8  # mecha inferior = soporte
        if upper_wick > body_size * 1.5: sc -= 6  # mecha superior = rechazo

        # Capa 5: Fuerza direccional
        if adx >= 28:                sc += 10
        elif adx >= 22:              sc += 5
        if pdi > mdi * 1.3:          sc += 10
        elif pdi > mdi:              sc += 5

        # Capa 6: Aceleración
        if roc5 > 0.004:             sc += 8
        elif roc5 > 0.001:           sc += 4
        if ema9_slope > 0.002:       sc += 6
        elif ema9_slope > 0:         sc += 3

        # Capa 7: Confluencia régimen
        if regimen == 'BULL':        sc += 10
        elif regimen == 'SIDEWAYS':  sc += 3
        elif regimen == 'BEAR':      sc -= 8

        if sc < 62:
            return None, 0
        return 'CALL', min(sc, 100)

    if bear_ok and not bull_ok:
        # ── Filtros duros PUT ───────────────────────────────────────────
        if rsi < 25:           return None, 0   # sobrecompra severa (inverso)
        if adx < 18:           return None, 0
        if is_bull:            return None, 0   # vela actual debe ser bajista

        sc = 0

        # Capa 1: Alineación EMA
        if ema9 < ema20 < ema50:    sc += 20
        elif ema9 < ema20:           sc += 10

        # Capa 2: Momentum
        if 38 <= rsi <= 58:          sc += 15
        elif 58 < rsi <= 70:         sc += 8
        if stoch > 0.75:             sc += 10
        elif stoch > 0.55:           sc += 5
        if macd_h < 0:               sc += 10

        # Capa 3: Volumen
        if obv_bear:                 sc += 12
        elif obv_bull:               sc -= 8
        if cmf < -0.04:              sc += 8
        elif cmf < -0.01:            sc += 4
        if vol_r > 1.4:              sc += 8
        elif vol_r > 1.15:           sc += 4

        # Capa 4: Estructura de velas
        if n_bear_5 >= 3:            sc += 8
        if body_ratio > 0.60:        sc += 8
        if upper_wick > body_size * 0.5: sc += 8  # mecha superior = resistencia
        if lower_wick > body_size * 1.5: sc -= 6  # mecha inferior = soporte

        # Capa 5: Fuerza direccional
        if adx >= 28:                sc += 10
        elif adx >= 22:              sc += 5
        if mdi > pdi * 1.3:          sc += 10
        elif mdi > pdi:              sc += 5

        # Capa 6: Aceleración
        if roc5 < -0.004:            sc += 8
        elif roc5 < -0.001:          sc += 4
        if ema9_slope < -0.002:      sc += 6
        elif ema9_slope < 0:         sc += 3

        # Capa 7: Confluencia régimen
        if regimen == 'BEAR':        sc += 10
        elif regimen == 'SIDEWAYS':  sc += 3
        elif regimen == 'BULL':      sc -= 8

        if sc < 62:
            return None, 0
        return 'PUT', min(sc, 100)

    return None, 0




def estrategia_lineas_tendencia(df, regimen):
    """
    Trendline Touch + EMA8/EMA21 Crossover v3 — 3 Toques Confirmados.

    Criterios de efectividad (redefinidos para reducir pérdidas):
      1. Mínimo 3 toques confirmados: 2 swing previos + toque actual en la línea
      2. Ángulo fuerte: pendiente entre 0.15×ATR y 3.5×ATR por barra (ni plana ni vertical)
      3. EMA8 cruza EMA21 en dirección correcta, con máximo 3 velas de antigüedad
      4. Línea conectada a nivel de S/R clave dentro de 1.5×ATR
      5. Filtros DUROS (todos obligatorios): RSI 38–62, ADX 20–40, Vol Ratio > 1.3
      6. Vela de confirmación: hammer/pin bull para CALL, shooting star/pin bear para PUT

    CALL: Línea de soporte alcista (higher lows) → 3er toque + cruce EMA8 > EMA21
    PUT:  Línea de resistencia bajista (lower highs) → 3er toque + cruce EMA8 < EMA21
    """
    if len(df) < 45:
        return None, 0

    u      = df.iloc[-1]
    close  = float(u['close'])
    low_c  = float(u['low'])
    high_c = float(u['high'])
    atr    = max(float(u.get('atr', abs(high_c - low_c))), 1e-9)
    n      = len(df)

    # ── Lectura de indicadores ─────────────────────────────────────────────
    rsi     = float(u.get('rsi',       50))
    vol_r   = float(u.get('vol_ratio',  1.0))
    adx     = float(u.get('adx',        0))
    macd_h  = float(u.get('macd_hist',  0))
    is_bull = bool(u.get('is_bull', False))
    lw      = float(u.get('lower_wick', 0))
    uw      = float(u.get('upper_wick', 0))
    body    = max(float(u.get('body',  0.0001)), 1e-10)

    # Detectar si el activo es OTC/sintético (vol_ratio siempre ~1.0)
    _vol_std = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_vol_sintetico = _vol_std < 0.005   # OTC: sin variación real de volumen

    # ── FILTROS DUROS — todos deben cumplirse, si falla uno → no operar ─────
    if not (38.0 <= rsi  <= 62.0): return None, 0   # RSI en zona neutra
    if not (20.0 <= adx  <= 40.0): return None, 0   # ADX: tendencia presente pero no extrema
    # Volumen > 1.35× promedio (omitir en OTC donde el volumen es sintético = 1.0)
    if not es_vol_sintetico and vol_r < 1.35:
        return None, 0

    # ── EMA8 calculada localmente | EMA21 ya disponible en df ─────────────
    c_series   = df['close']
    ema8_vals  = c_series.ewm(span=8,  adjust=False).mean().values
    ema21_vals = c_series.ewm(span=21, adjust=False).mean().values

    # Cruce EMA8/EMA21 en las últimas 6 velas (hasta 6 barras atrás)
    cruce_bull = False
    cruce_bear = False
    max_lookback = min(7, len(ema8_vals) - 1)
    for k in range(1, max_lookback + 1):
        i_c = -(k)
        i_p = -(k + 1)
        if abs(i_p) <= len(ema8_vals):
            e8_c, e8_p = ema8_vals[i_c], ema8_vals[i_p]
            e21_c, e21_p = ema21_vals[i_c], ema21_vals[i_p]
            if e8_p <= e21_p and e8_c > e21_c:
                cruce_bull = True
            if e8_p >= e21_p and e8_c < e21_c:
                cruce_bear = True

    # Sin cruce reciente → no hay señal (la estrategia lo requiere siempre)
    if not cruce_bull and not cruce_bear:
        return None, 0

    # ── Patrones de vela de confirmación ──────────────────────────────────
    # Hammer alcista: mecha inferior ≥ 2× cuerpo, mecha superior pequeña
    es_hammer     = (lw >= body * 2.0 and uw <= body * 0.5 and is_bull)
    # Shooting star: mecha superior ≥ 2× cuerpo, mecha inferior pequeña
    es_shoot      = (uw >= body * 2.0 and lw <= body * 0.5 and not is_bull)
    # Pin bull (relajado): mecha inferior ≥ 1.5× cuerpo
    es_pin_bull   = (lw >= body * 1.5)
    # Pin bear (relajado): mecha superior ≥ 1.5× cuerpo
    es_pin_bear   = (uw >= body * 1.5)

    # ── Detección de swings en ventana de 60 velas ───────────────────────
    window_size = min(60, n - 2)
    seg     = df.iloc[-(window_size + 2):-1]   # excluir vela actual
    lows_a  = seg['low'].astype(float).values
    highs_a = seg['high'].astype(float).values
    n_seg   = len(seg)

    swing_lows  = []   # (idx_en_seg, precio)
    swing_highs = []

    # Swing confirmado con 3 barras de margen a cada lado (más robusto que 2)
    for i in range(3, n_seg - 2):
        if (lows_a[i] <= min(lows_a[i-1], lows_a[i-2], lows_a[i-3]) and
                lows_a[i] <= min(lows_a[i+1], lows_a[i+2])):
            swing_lows.append((i, lows_a[i]))
        if (highs_a[i] >= max(highs_a[i-1], highs_a[i-2], highs_a[i-3]) and
                highs_a[i] >= max(highs_a[i+1], highs_a[i+2])):
            swing_highs.append((i, highs_a[i]))

    def _hay_sr_cercano(precio_ref, swings):
        """True si hay al menos 1 swing dentro de 1.8×ATR del precio de referencia."""
        tol = atr * 1.8
        return any(abs(p - precio_ref) <= tol for _, p in swings)

    def _sin_ruptura(df_base, slope, base_p, n_bars):
        """True si ninguna vela entre el swing y ahora cerró por fuera de la línea."""
        seg_check = df_base.iloc[-n_bars:-1] if n_bars > 1 else df_base.iloc[0:0]
        proj = [base_p + slope * k for k in range(1, n_bars)]
        for k, (_, row) in enumerate(seg_check.iterrows()):
            if k >= len(proj):
                break
            c_row = float(row['close'])
            if slope > 0 and c_row < proj[k] * 0.990:   # soporte roto
                return False
            if slope < 0 and c_row > proj[k] * 1.010:   # resistencia rota
                return False
        return True

    score = 0
    dir_  = None

    # ═══ CALL: Soporte alcista (higher lows) + cruce EMA8 > EMA21 ══════════
    if cruce_bull and regimen != 'BEAR' and len(swing_lows) >= 2:
        # Evaluar los últimos 4 swing lows para encontrar la mejor línea
        sl_cands = swing_lows[-min(5, len(swing_lows)):]

        for ia in range(len(sl_cands) - 1):
            sl1_i, sl1_p = sl_cands[ia]
            for ib in range(ia + 1, len(sl_cands)):
                sl2_i, sl2_p = sl_cands[ib]

                # Higher lows, separados al menos 4 barras
                if sl2_p <= sl1_p or (sl2_i - sl1_i) < 4:
                    continue

                slope = (sl2_p - sl1_p) / max(sl2_i - sl1_i, 1)
                bars_to_now = n_seg - sl2_i
                proj_now    = sl2_p + slope * bars_to_now

                # ── Ángulo fuerte: 0.15–3.5 ATR por barra ────────────────
                spar = slope / atr   # slope_per_atr_ratio
                if not (0.15 <= spar <= 3.5):
                    continue

                # ── Toque actual en la línea proyectada (±1.2 ATR) ────────
                if not (low_c <= proj_now + atr * 1.2 and close >= proj_now - atr * 0.8):
                    continue

                # ── S/R clave cercano al punto de toque ───────────────────
                if not _hay_sr_cercano(proj_now, swing_lows):
                    continue

                # ── Sin ruptura desde sl2 hasta ahora ─────────────────────
                if not _sin_ruptura(df, slope, sl2_p, bars_to_now):
                    continue

                # ── Score de esta línea ────────────────────────────────────
                s = 38   # base: 3 toques + cruce EMA8/21 + ángulo OK + S/R cercano

                # Calidad del cruce EMA8/21
                s += 14   # cruce confirmado (ya verificado arriba)

                # Régimen alineado
                if regimen == 'BULL':      s += 10
                elif regimen == 'SIDEWAYS': s += 5

                # EMA8 está sobre EMA21 ahora (alineación post-cruce)
                if ema8_vals[-1] > ema21_vals[-1]:
                    s += 8

                # Calidad del ángulo (ideal entre 0.3 y 2.0 ATR/barra)
                if 0.30 <= spar <= 2.0:
                    s += 8
                elif 0.15 <= spar <= 3.5:
                    s += 3

                # Vela de confirmación (obligatoria para máxima puntuación)
                if es_hammer:    s += 18   # confirmación perfecta
                elif es_pin_bull: s += 10   # confirmación aceptable
                elif is_bull:    s += 4    # vela alcista mínima

                # Momentum confirma
                if macd_h > 0:   s += 8

                # ADX en zona óptima
                if 25 <= adx <= 35:   s += 6

                # RSI en zona de rebote (38-50 = mejor para CALL)
                if 38 <= rsi <= 50:   s += 8
                elif 50 < rsi <= 62:  s += 3

                # Más swing lows = línea más robusta
                if len(swing_lows) >= 4:   s += 6

                if s > score:
                    score = s
                    if s >= MIN_SCORE_PARA_OPERAR:
                        dir_ = 'CALL'

    # ═══ PUT: Resistencia bajista (lower highs) + cruce EMA8 < EMA21 ═══════
    if dir_ is None and cruce_bear and regimen != 'BULL' and len(swing_highs) >= 2:
        sh_cands = swing_highs[-min(5, len(swing_highs)):]

        for ia in range(len(sh_cands) - 1):
            sh1_i, sh1_p = sh_cands[ia]
            for ib in range(ia + 1, len(sh_cands)):
                sh2_i, sh2_p = sh_cands[ib]

                # Lower highs, separados al menos 4 barras
                if sh2_p >= sh1_p or (sh2_i - sh1_i) < 4:
                    continue

                slope = (sh2_p - sh1_p) / max(sh2_i - sh1_i, 1)
                bars_to_now = n_seg - sh2_i
                proj_now    = sh2_p + slope * bars_to_now

                # Ángulo fuerte bajista: -3.5 a -0.15 ATR por barra
                spar = slope / atr
                if not (-3.5 <= spar <= -0.15):
                    continue

                # Toque actual en resistencia proyectada (±1.2 ATR)
                if not (high_c >= proj_now - atr * 1.2 and close <= proj_now + atr * 0.8):
                    continue

                # S/R clave cercano
                if not _hay_sr_cercano(proj_now, swing_highs):
                    continue

                # Sin ruptura desde sh2 hasta ahora
                if not _sin_ruptura(df, slope, sh2_p, bars_to_now):
                    continue

                # Score
                s = 38
                s += 14   # cruce EMA8/21 bajista confirmado

                if regimen == 'BEAR':      s += 10
                elif regimen == 'SIDEWAYS': s += 5

                if ema8_vals[-1] < ema21_vals[-1]:
                    s += 8

                if -2.0 <= spar <= -0.30:
                    s += 8
                elif -3.5 <= spar <= -0.15:
                    s += 3

                # Vela de confirmación bajista
                if es_shoot:     s += 18
                elif es_pin_bear: s += 10
                elif not is_bull: s += 4

                if macd_h < 0:   s += 8
                if 25 <= adx <= 35:   s += 6

                # RSI en zona de agotamiento para PUT (50-62 = mejor)
                if 50 <= rsi <= 62:   s += 8
                elif 38 <= rsi < 50:  s += 3

                if len(swing_highs) >= 4:   s += 6

                if s > score:
                    score = s
                    if s >= MIN_SCORE_PARA_OPERAR:
                        dir_ = 'PUT'

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0

    return dir_, min(score, 100)



def estrategia_macd_divergencia(df, regimen, asset=''):
    """
    MACD Divergencia + ADX v1 (spec 24-Mar-2026).

    CALL: precio hace mínimo más bajo (LL) + MACD hace mínimo más alto (HL)
          → divergencia alcista, confirma con cruce MACD hacia arriba + ADX ≥ 25
          → bonus si precio cerca de banda de Bollinger inferior
    PUT : precio hace máximo más alto (HH) + MACD hace máximo más bajo (LH)
          → divergencia bajista, confirma con cruce MACD hacia abajo + ADX ≥ 25
          → bonus si precio cerca de banda de Bollinger superior
    """
    if len(df) < 40:
        return None, 0

    u  = df.iloc[-1]
    p  = df.iloc[-2]
    p2 = df.iloc[-3]
    c  = float(u['close'])

    adx = float(u.get('adx', 0))
    if adx < 25:
        return None, 0

    # ── Precios recientes para detectar divergencia ───────────────────────
    lo1 = float(u['low']);  lo2 = float(p['low']);  lo3 = float(p2['low'])
    hi1 = float(u['high']); hi2 = float(p['high']); hi3 = float(p2['high'])

    macd1 = float(u.get('macd12', 0))
    macd2 = float(p.get('macd12', 0))
    macd3 = float(p2.get('macd12', 0))

    cruce_bull = bool(u.get('macd12_cruce_bull', 0))
    cruce_bear = bool(u.get('macd12_cruce_bear', 0))

    ema10_bull = bool(u.get('ema10_sobre_ema20', 0))
    rsi        = float(u.get('rsi', 50))
    bb_lo      = float(u.get('bb_lower', 0))
    bb_up      = float(u.get('bb_upper', 999999))
    bb_mid     = float(u.get('bb_mid', c))

    vol_ratio5 = float(u.get('vol_ratio5', 1.0))
    vol_r_macd = float(u.get('vol_ratio', 1.0))

    # ── Filtro de volumen (soft): volumen debe estar presente
    # En OTC (vol_ratio siempre ~1.0), omitir el filtro
    _macd_vol_std  = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    _macd_es_otc   = _macd_vol_std < 0.005
    if not _macd_es_otc and vol_r_macd < 1.0:
        return None, 0   # mercado sin participación

    factores = 0
    dir_     = None

    # ══════════════════════════════════════════════════════════════════════
    # CALL — divergencia alcista: precio LL pero MACD HL + cruce up
    # ══════════════════════════════════════════════════════════════════════
    div_bull = (
        lo1 < lo3 and        # precio hace mínimo más bajo
        macd1 > macd3 and    # MACD hace mínimo más alto (divergencia)
        cruce_bull           # cruce de MACD hacia arriba (confirmación)
    )
    if div_bull and ema10_bull:
        dir_ = 'CALL'
        factores += 30  # divergencia alcista confirmada

        # ADX bonus por fuerza de tendencia
        if adx >= 40:   factores += 14
        elif adx >= 30: factores += 8

        # Cruce hacia zona positiva del MACD
        if macd1 > 0:  factores += 10

        # RSI apoyo
        if rsi < 45:   factores += 12
        elif rsi < 55: factores += 6

        # Cerca de Bollinger inferior (bonus per spec)
        if bb_lo > 0 and c <= bb_lo * 1.015:
            factores += 14

        # Soporte de nivel de precio
        plus_di  = float(u.get('plus_di',  0))
        minus_di = float(u.get('minus_di', 0))
        if plus_di > minus_di:  factores += 10  # +DI domina

        if regimen in ('BULL', 'SIDEWAYS'): factores += 10
        elif regimen == 'BEAR':             factores += 4

    # ══════════════════════════════════════════════════════════════════════
    # PUT — divergencia bajista: precio HH pero MACD LH + cruce down
    # ══════════════════════════════════════════════════════════════════════
    div_bear = (
        hi1 > hi3 and        # precio hace máximo más alto
        macd1 < macd3 and    # MACD hace máximo más bajo (divergencia)
        cruce_bear           # cruce de MACD hacia abajo (confirmación)
    )
    if div_bear and (not ema10_bull) and dir_ is None:
        dir_ = 'PUT'
        factores += 30  # divergencia bajista confirmada

        if adx >= 40:   factores += 14
        elif adx >= 30: factores += 8

        if macd1 < 0:  factores += 10

        if rsi > 55:   factores += 12
        elif rsi > 45: factores += 6

        # Cerca de Bollinger superior (bonus per spec)
        if bb_up < 999999 and c >= bb_up * 0.985:
            factores += 14

        plus_di  = float(u.get('plus_di',  0))
        minus_di = float(u.get('minus_di', 0))
        if minus_di > plus_di:  factores += 10  # -DI domina

        if regimen in ('BEAR', 'SIDEWAYS'): factores += 10
        elif regimen == 'BULL':             factores += 4

    return (dir_, min(factores, 100)) if dir_ and factores >= MIN_SCORE_PARA_OPERAR else (None, 0)


def estrategia_tendencia_5min(df, regimen, asset=''):
    """
    Estrategia de Continuidad de Tendencia — Vencimiento 5 minutos.

    SIEMPRE opera en la dirección de la tendencia macro (EMA50 vs EMA200).
    Requiere que la tendencia esté ACTIVA Y CONTINUANDO:
      · EMA20 debe tener pendiente en dirección de la tendencia
      · ADX no puede estar en colapso (> 60% de su valor 5 barras antes)
      · Precio no debe estar sobreextendido vs EMA50
      · Pullback a EMA20 + vela de confirmación en dirección de la tendencia
      · Estructura HH/HL (CALL) o LH/LL (PUT) presente

    CALL: EMA50 > EMA200 + EMA20 subiendo + DI+ > DI- + MACD > 0 + ADX [25-45]
          + pullback a EMA20 + vela alcista + HH o HL
    PUT:  EMA50 < EMA200 + EMA20 bajando + DI- > DI+ + MACD < 0 + ADX [25-45]
          + rebote a EMA20 + vela bajista + LH o LL
    """
    if len(df) < 60:
        return None, 0

    u        = df.iloc[-1]
    ema50    = float(u.get('ema50', 0))
    ema200   = float(u.get('ema200', 0))
    adx      = float(u.get('adx', 0))
    plus_di  = float(u.get('plus_di', 0))
    minus_di = float(u.get('minus_di', 0))
    macd_hist = float(u.get('macd12_hist', 0))
    close    = float(u['close'])
    open_    = float(u['open'])
    ema20    = float(u.get('ema20', 0)) or float(df['sma20'].iloc[-1])

    if ema50 == 0 or ema200 == 0:
        return None, 0

    # ADX entre 25 y 45: tendencia real pero sin exceso de volatilidad
    if not (25 <= adx <= 45):
        return None, 0

    # Verificar que el ADX no esté colapsando (tendencia se debilita)
    # Si ADX cayó más del 40% en los últimos 5 periodos, la tendencia está muriendo
    if len(df) >= 6 and 'adx' in df.columns:
        adx_prev5 = float(df['adx'].iloc[-6])
        if adx_prev5 > 0 and adx < adx_prev5 * 0.60:
            return None, 0   # ADX colapsando = fin de tendencia

    # Pendiente de EMA20 (continuación de tendencia a corto plazo)
    ema20_prev = None
    if 'ema20' in df.columns and len(df) >= 6:
        ema20_prev = float(df['ema20'].iloc[-6])

    tendencia_bull = ema50 > ema200
    tendencia_bear = ema50 < ema200
    if not (tendencia_bull or tendencia_bear):
        return None, 0

    # EMA20 debe moverse en dirección de la tendencia macro
    if tendencia_bull and ema20_prev is not None:
        if ema20 < ema20_prev * 0.9998:   # EMA20 bajando en uptrend = peligro
            return None, 0
    if tendencia_bear and ema20_prev is not None:
        if ema20 > ema20_prev * 1.0002:   # EMA20 subiendo en downtrend = peligro
            return None, 0

    # Precio no debe estar sobreextendido vs EMA50
    # (si está > 2% alejado de EMA50, estamos en el extremo de la tendencia)
    if ema50 > 0:
        dist_ema50_pct = abs(close - ema50) / ema50 * 100
        if dist_ema50_pct > 2.0:
            return None, 0   # precio sobreextendido, alto riesgo de reversión

    # Detectar Higher Highs / Lower Lows en las últimas 30 velas
    reciente    = df.iloc[-30:]
    highs_arr   = reciente['high'].values
    lows_arr    = reciente['low'].values
    swing_highs, swing_lows = [], []
    for i in range(2, len(highs_arr) - 2):
        if (highs_arr[i] >= highs_arr[i-1] and highs_arr[i] >= highs_arr[i+1] and
                highs_arr[i] >= highs_arr[i-2] and highs_arr[i] >= highs_arr[i+2]):
            swing_highs.append(highs_arr[i])
        if (lows_arr[i] <= lows_arr[i-1] and lows_arr[i] <= lows_arr[i+1] and
                lows_arr[i] <= lows_arr[i-2] and lows_arr[i] <= lows_arr[i+2]):
            swing_lows.append(lows_arr[i])

    # ── Filtro de volumen: mercado debe tener participación
    vol_r_t5    = float(u.get('vol_ratio', 1.0))
    _t5_vol_std = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    _t5_es_otc  = _t5_vol_std < 0.005
    if not _t5_es_otc and vol_r_t5 < 0.9:
        return None, 0   # volumen muy por debajo del promedio, mercado inactivo

    score     = 0
    direccion = None

    if tendencia_bull:
        # ── FILTROS DUROS (todos deben cumplirse) ─────────────────────────
        if plus_di <= minus_di:         return None, 0   # DI+ debe dominar
        if macd_hist <= 0:              return None, 0   # MACD debe ser positivo
        # Spread mínimo EMA50/EMA200 (tendencia establecida, no reciente cruce)
        spread_pct = (ema50 - ema200) / (ema200 + 1e-10) * 100
        if spread_pct < 0.1:           return None, 0   # tendencia demasiado débil
        # OBLIGATORIO: precio en retroceso hacia EMA20 (soporte dinámico)
        # Zona válida: desde 0.3% por debajo hasta 1% por encima de EMA20
        if not (ema20 > 0 and ema20 * 0.997 <= close <= ema20 * 1.010):
            return None, 0
        # OBLIGATORIO: vela de confirmación alcista (cierre > apertura)
        if close <= open_:             return None, 0

        score += 30   # base: EMA50>EMA200 + ADX ok + MACD ok + DI ok + pullback + vela

        # Estructura alcista confirmada (HH y/o HL) — al menos una requerida
        hh = len(swing_highs) >= 2 and swing_highs[-1] > swing_highs[-2]
        hl = len(swing_lows)  >= 2 and swing_lows[-1]  > swing_lows[-2]
        if not (hh or hl):             return None, 0   # sin estructura alcista
        if hh: score += 18
        if hl: score += 12

        # ADX en zona óptima
        if 28 <= adx <= 38: score += 8
        # Spread EMA50/EMA200
        if spread_pct > 0.5: score += 7
        elif spread_pct > 0.3: score += 4
        # Volumen confirma la continuación de tendencia
        if vol_r_t5 >= 1.4:  score += 8
        elif vol_r_t5 >= 1.2: score += 4

        direccion = 'CALL'

    elif tendencia_bear:
        # ── FILTROS DUROS ─────────────────────────────────────────────────
        if minus_di <= plus_di:        return None, 0   # DI- debe dominar
        if macd_hist >= 0:             return None, 0   # MACD debe ser negativo
        spread_pct = (ema200 - ema50) / (ema200 + 1e-10) * 100
        if spread_pct < 0.1:          return None, 0   # tendencia demasiado débil
        # OBLIGATORIO: precio en rebote hacia EMA20 (resistencia dinámica)
        # Zona válida: desde 1% por debajo hasta 0.3% por encima de EMA20
        if not (ema20 > 0 and ema20 * 0.990 <= close <= ema20 * 1.003):
            return None, 0
        # OBLIGATORIO: vela de confirmación bajista (cierre < apertura)
        if close >= open_:            return None, 0

        score += 30

        lh = len(swing_highs) >= 2 and swing_highs[-1] < swing_highs[-2]
        ll = len(swing_lows)  >= 2 and swing_lows[-1]  < swing_lows[-2]
        if not (lh or ll):            return None, 0   # sin estructura bajista
        if lh: score += 18
        if ll: score += 12

        if 28 <= adx <= 38: score += 8
        if spread_pct > 0.5: score += 7
        elif spread_pct > 0.3: score += 4
        # Volumen confirma la continuación de tendencia
        if vol_r_t5 >= 1.4:  score += 8
        elif vol_r_t5 >= 1.2: score += 4

        direccion = 'PUT'

    if score < 55 or not direccion:
        return None, 0

    return direccion, score


# ─────────────────────────────────────────────
# ESTRATEGIA 6: PATRÓN 1×1 REVERSIÓN MICRO-RANGO
# ─────────────────────────────────────────────

def estrategia_micro_rango(df, regimen):
    """
    Patrón 1×1 de Reversión Inmediata en Micro-Rango.

    Tipo de mercado: Ultra-consolidado, sin tendencia (ADX < 15), BB squeeze,
    EMA20/50 horizontales entrelazadas.

    Patrón (1 min):
      V1 — cualquier dirección, volumen BUENO, cuerpo pequeño-mediano, mechas moderadas.
      V2 — dirección contraria a V1, volumen BAJO vs V1, cuerpo contenido en rango V1,
            cierre muy cercano al cierre de V1.

    Dirección: contraria a V2 (si V2 alcista → PUT; si V2 bajista → CALL).
    Vencimiento: 1 minuto. Solo aplica en régimen SIDEWAYS.
    """
    if len(df) < 35:
        return None, 0

    # Solo en mercados sin tendencia clara
    if regimen != 'SIDEWAYS':
        return None, 0

    u  = df.iloc[-1]   # V2 (vela cerrada más reciente)
    p  = df.iloc[-2]   # V1

    # ── Filtros de contexto (5-min aproximado via indicadores 1-min) ──────
    adx      = float(u.get('adx', 99))
    bb_width = float(u.get('bb_width', 1.0))
    ema20    = float(u.get('ema20', 0))
    ema50    = float(u.get('ema50', 0))

    if adx >= 15:           return None, 0   # ADX crítico: debe ser < 15
    if bb_width >= 0.0045:  return None, 0   # Bandas demasiado anchas
    if ema20 == 0 or ema50 == 0: return None, 0

    # EMAs entrelazadas y horizontales (spread < 0.3%)
    spread_ema = abs(ema20 - ema50) / (ema50 + 1e-10)
    if spread_ema > 0.003:  return None, 0

    # Pendiente EMA20 < 0.02% en últimas 6 velas (horizontal)
    if len(df) >= 7 and 'ema20' in df.columns:
        ema20_ant  = float(df['ema20'].iloc[-7])
        if ema20_ant > 0:
            pendiente = abs(ema20 - ema20_ant) / ema20_ant
            if pendiente > 0.0002:
                return None, 0

    # ── Datos de V1 ──────────────────────────────────────────────────────
    v1_open  = float(p['open'])
    v1_close = float(p['close'])
    v1_high  = float(p['high'])
    v1_low   = float(p['low'])
    v1_body  = abs(v1_close - v1_open)
    v1_rango = v1_high - v1_low
    v1_vol   = float(p.get('volume', 1))
    v1_bull  = v1_close > v1_open
    if v1_rango < 1e-10: return None, 0

    v1_body_ratio = v1_body / v1_rango
    # V1: cuerpo entre 15% y 75% del rango (no Doji ni mega-vela)
    if not (0.15 <= v1_body_ratio <= 0.75): return None, 0

    # V1: mechas moderadas (ninguna mecha > 60% del rango)
    v1_uw = v1_high - max(v1_open, v1_close)
    v1_lw = min(v1_open, v1_close) - v1_low
    if v1_uw > v1_rango * 0.60 or v1_lw > v1_rango * 0.60: return None, 0

    # V1: volumen bueno (≥ 80% del promedio de las últimas 10 velas)
    vol_avg10 = float(u.get('vol_sma10', v1_vol))
    if vol_avg10 > 0 and v1_vol < vol_avg10 * 0.80: return None, 0

    # ── Datos de V2 ──────────────────────────────────────────────────────
    v2_open  = float(u['open'])
    v2_close = float(u['close'])
    v2_high  = float(u['high'])
    v2_low   = float(u['low'])
    v2_body  = abs(v2_close - v2_open)
    v2_rango = v2_high - v2_low
    v2_vol   = float(u.get('volume', 1))
    v2_bull  = v2_close > v2_open
    if v2_rango < 1e-10: return None, 0

    # V2: dirección contraria a V1
    if v1_bull == v2_bull: return None, 0

    # V2: volumen significativamente menor que V1
    if v1_vol > 0 and v2_vol >= v1_vol * 0.88: return None, 0

    # V2: cuerpo completamente contenido en el rango de V1
    v2_body_hi = max(v2_open, v2_close)
    v2_body_lo = min(v2_open, v2_close)
    if v2_body_hi > v1_high + 1e-8 or v2_body_lo < v1_low - 1e-8:
        return None, 0

    # V2: cierre muy cercano al cierre de V1 (≤ 30% del rango V1)
    cierre_diff = abs(v2_close - v1_close)
    if cierre_diff > v1_rango * 0.30: return None, 0

    # Rango total V1+V2 muy estrecho (≤ 1.5× ATR)
    total_high = max(v1_high, v2_high)
    total_low  = min(v1_low, v2_low)
    atr = max(float(u.get('atr', 1e-10)), 1e-10)
    if (total_high - total_low) > atr * 1.5: return None, 0

    # V2: sin mechas excesivamente largas (< 60% rango)
    v2_uw = v2_high - max(v2_open, v2_close)
    v2_lw = min(v2_open, v2_close) - v2_low
    if v2_uw > v2_rango * 0.60 or v2_lw > v2_rango * 0.60: return None, 0

    # ── Confirmación de oscilador (espacio para el movimiento en V3) ──────
    rsi  = float(u.get('rsi', 50))
    stk  = float(u.get('stoch_k', 50))
    stod = float(u.get('stoch_d', 50))

    if not v2_bull:   # V2 bajista → esperamos CALL
        if rsi > 70 or stk > 80:  return None, 0   # sobrecompra: sin espacio
        direccion = 'CALL'
    else:             # V2 alcista → esperamos PUT
        if rsi < 30 or stk < 20:  return None, 0   # sobreventa: sin espacio
        direccion = 'PUT'

    # ── Scoring ──────────────────────────────────────────────────────────
    score = 30   # base: patrón 1×1 detectado en micro-rango

    # ADX muy bajo = consolidación profunda (mejor contexto)
    if adx < 8:   score += 15
    elif adx < 12: score += 10
    else:          score += 5

    # BB muy estrecho (squeeze profundo)
    if bb_width < 0.0020:  score += 12
    elif bb_width < 0.0030: score += 7
    elif bb_width < 0.0040: score += 3

    # Spread EMAs casi cero
    if spread_ema < 0.001:  score += 8
    elif spread_ema < 0.002: score += 4

    # V2 con mucho menor volumen que V1 (agotamiento claro)
    if v1_vol > 0:
        v_ratio = v2_vol / (v1_vol + 1e-10)
        if v_ratio < 0.50:   score += 10
        elif v_ratio < 0.70: score += 6
        elif v_ratio < 0.85: score += 3

    # Cierres horizontales (muy cercanos)
    if v1_rango > 0:
        pct_diff = cierre_diff / v1_rango
        if pct_diff < 0.08:   score += 10
        elif pct_diff < 0.15: score += 6
        elif pct_diff < 0.25: score += 3

    # RSI neutral (± alrededor de 50 = máximo espacio)
    if 40 <= rsi <= 60:   score += 6
    elif 35 <= rsi <= 65: score += 3

    # Stoch cruce favorable en zona neutral
    if not v2_bull and stk > stod and stk < 70: score += 4
    if v2_bull and stk < stod and stk > 30:     score += 4

    if score < 46:   # umbral bajo para poder votar en consenso multi-estrategia
        return None, 0

    return direccion, score


# ─────────────────────────────────────────────
# ESTRATEGIA 7: VELA DE RECHAZO (s59-s01)
# ─────────────────────────────────────────────

def estrategia_rechazo_vela(df, regimen):
    """
    Operación de Velas de Rechazo — Entrada en ventana s59-s01.

    Detecta el rechazo violento de un Nivel de Soporte/Resistencia fuerte
    en la vela recién cerrada. La señal se programa para dispararse al
    ventana s59-s01 del minuto siguiente, con vencimiento 1 minuto.

    Condiciones críticas:
      · Precio penetró la zona S/R en la última vela cerrada.
      · La vela dejó una mecha MUY LARGA (≥ 2× cuerpo) en dirección del rechazo.
      · RSI/Stocástico confirmó sobrecompra (rechazo bajista) o sobreventa (alcista).
      · ADX moderado (15-40): hay S/R válidos, no excesiva tendencia rompedora.
      · Volumen activo en la vela de rechazo.

    Dirección: contraria a la penetración (mecha larga bajista → PUT, alcista → CALL).
    Timing especial: se procesa en ventana s59-s01.
    Vencimiento: 1 minuto.
    """
    if len(df) < 40:
        return None, 0

    u  = df.iloc[-1]   # última vela cerrada (la vela de rechazo)
    p  = df.iloc[-2]

    close = float(u['close'])
    open_ = float(u['open'])
    high  = float(u['high'])
    low   = float(u['low'])
    body  = abs(close - open_)
    rango = high - low
    if rango < 1e-10: return None, 0

    atr   = max(float(u.get('atr', rango)), 1e-10)

    # ── EMA contexto de tendencia ─────────────────────────────────────────
    ema20 = float(u.get('ema20', 0))
    ema50 = float(u.get('ema50', 0))

    # ADX: mercado con S/R respetados (no excesivamente fuerte)
    adx = float(u.get('adx', 0))
    if adx > 40: return None, 0   # tendencia demasiado fuerte, S/R se rompen

    # ── Detectar niveles S/R en las últimas 50 velas ─────────────────────
    ventana = df.iloc[-50:]
    highs_v = ventana['high'].values
    lows_v  = ventana['low'].values

    resistencias, soportes = [], []
    for i in range(2, len(highs_v) - 2):
        if (highs_v[i] > highs_v[i-1] and highs_v[i] > highs_v[i+1] and
                highs_v[i] > highs_v[i-2] and highs_v[i] > highs_v[i+2]):
            resistencias.append(highs_v[i])
        if (lows_v[i] < lows_v[i-1] and lows_v[i] < lows_v[i+1] and
                lows_v[i] < lows_v[i-2] and lows_v[i] < lows_v[i+2]):
            soportes.append(lows_v[i])

    if not resistencias and not soportes:
        return None, 0

    tol = atr * 0.60   # tolerancia para "cerca del nivel"

    # ── Mecha superior larga → rechazo bajista en resistencia ─────────────
    upper_wick = high - max(open_, close)
    lower_wick = min(open_, close) - low
    body_min   = max(body, atr * 0.05)   # evitar divisiones por cero

    rsi  = float(u.get('rsi', 50))
    stk  = float(u.get('stoch_k', 50))
    stod = float(u.get('stoch_d', 50))
    vol_ratio = float(u.get('vol_ratio', 1.0))

    direccion = None
    score_base = 0

    # ── RECHAZO BAJISTA: mecha superior ≥ 2× cuerpo en zona de resistencia ─
    if upper_wick >= body_min * 2.0:
        # Buscar resistencia que fue perforada y rechazada
        nivel_ok = any(
            close <= r <= high + tol
            for r in resistencias
        )
        if nivel_ok:
            # RSI confirmó sobrecompra durante la penetración
            if rsi >= 55:   # en la zona de rechazo el RSI ya no debe estar en sobreventa
                direccion  = 'PUT'
                score_base = 30
                # Calidad de la mecha
                wick_ratio = upper_wick / body_min
                if wick_ratio >= 4.0:   score_base += 20
                elif wick_ratio >= 3.0: score_base += 14
                elif wick_ratio >= 2.0: score_base += 8
                # RSI en sobrecompra sólida
                if rsi >= 75:   score_base += 12
                elif rsi >= 65: score_base += 8
                # Stoch en sobrecompra
                if stk >= 80:   score_base += 8
                elif stk >= 70: score_base += 4
                # Cuerpo pequeño (indecisión real)
                if body < atr * 0.30: score_base += 7
                # Volumen activo
                if vol_ratio >= 1.2: score_base += 5
                # Rechazo a favor o en contra de tendencia
                if regimen == 'BEAR' and ema20 > 0 and close < ema20: score_base += 5
                # Cuerpo cierra claramente por debajo del nivel de resistencia
                near_res = min(abs(close - r) for r in resistencias)
                if near_res < tol * 0.5: score_base += 5

    # ── RECHAZO ALCISTA: mecha inferior ≥ 2× cuerpo en zona de soporte ────
    elif lower_wick >= body_min * 2.0 and direccion is None:
        nivel_ok = any(
            low - tol <= s <= close
            for s in soportes
        )
        if nivel_ok:
            # RSI confirmó sobreventa durante la penetración
            if rsi <= 45:   # precio se alejó de sobrecompra
                direccion  = 'CALL'
                score_base = 30
                wick_ratio = lower_wick / body_min
                if wick_ratio >= 4.0:   score_base += 20
                elif wick_ratio >= 3.0: score_base += 14
                elif wick_ratio >= 2.0: score_base += 8
                if rsi <= 25:   score_base += 12
                elif rsi <= 35: score_base += 8
                if stk <= 20:   score_base += 8
                elif stk <= 30: score_base += 4
                if body < atr * 0.30: score_base += 7
                if vol_ratio >= 1.2:  score_base += 5
                if regimen == 'BULL' and ema20 > 0 and close > ema20: score_base += 5
                near_sup = min(abs(close - s) for s in soportes)
                if near_sup < tol * 0.5: score_base += 5

    if direccion is None or score_base < 46:   # umbral bajo para votar en consenso
        return None, 0

    # Rechazo contra la macro tendencia pierde 8 pts (más riesgoso)
    if (direccion == 'PUT'  and regimen == 'BULL') or \
       (direccion == 'CALL' and regimen == 'BEAR'):
        score_base -= 8
        if score_base < 50:
            return None, 0

    return direccion, score_base


# ─────────────────────────────────────────────
# ESTRATEGIA 8: PARIDAD DE VELAS EN S/R (ÚLTIMO ESTIRAMIENTO)
# ─────────────────────────────────────────────

def estrategia_ultimo_estiramiento(df, regimen):
    """
    Patrón de Paridad de Velas en S/R — Último Estiramiento + Negación.

    Detecta el "último impulso" de precio hacia un S/R fuerte (V1) seguido
    de una vela de negación/engulfing en dirección contraria (V2).

    V1 = Último Estiramiento: toca/penetra ligeramente el nivel S/R,
         volumen bueno, pequeña mecha de rechazo ya visible.
    V2 = Negación: engulf el cuerpo de V1, cierra claramente del otro lado
         del S/R, volumen bueno.

    Confirmación: RSI en sobrecompra (venta) o sobreventa (compra) al cierre V1.
    ADX < 30: el mercado no está en tendencia excesivamente fuerte.
    Entrada: segundo 00 de V3. Vencimiento: 1 minuto.
    """
    if len(df) < 40:
        return None, 0

    # ADX < 30: mercado en rango o tendencia moderada
    u = df.iloc[-1]   # V2 (negación)
    p = df.iloc[-2]   # V1 (último estiramiento)

    adx   = float(u.get('adx', 99))
    if adx > 30: return None, 0

    atr   = max(float(u.get('atr', 1e-10)), 1e-10)
    tol   = atr * 0.55

    # ── Detectar niveles S/R en 50 velas ──────────────────────────────────
    ventana = df.iloc[-50:]
    highs_v = ventana['high'].values
    lows_v  = ventana['low'].values

    resistencias, soportes = [], []
    toques_res, toques_sup = {}, {}
    for i in range(2, len(highs_v) - 2):
        if (highs_v[i] > highs_v[i-1] and highs_v[i] > highs_v[i+1] and
                highs_v[i] > highs_v[i-2] and highs_v[i] > highs_v[i+2]):
            nivel = round(highs_v[i], 5)
            toques_res[nivel] = toques_res.get(nivel, 0) + 1
            resistencias.append(highs_v[i])
        if (lows_v[i] < lows_v[i-1] and lows_v[i] < lows_v[i+1] and
                lows_v[i] < lows_v[i-2] and lows_v[i] < lows_v[i+2]):
            nivel = round(lows_v[i], 5)
            toques_sup[nivel] = toques_sup.get(nivel, 0) + 1
            soportes.append(lows_v[i])

    if not resistencias and not soportes:
        return None, 0

    # ── Datos V1 ──────────────────────────────────────────────────────────
    v1_open  = float(p['open'])
    v1_close = float(p['close'])
    v1_high  = float(p['high'])
    v1_low   = float(p['low'])
    v1_body  = abs(v1_close - v1_open)
    v1_vol   = float(p.get('volume', 1))
    v1_bull  = v1_close > v1_open
    if v1_body < atr * 0.05: return None, 0   # V1 no puede ser Doji

    # ── Datos V2 ──────────────────────────────────────────────────────────
    v2_open  = float(u['open'])
    v2_close = float(u['close'])
    v2_high  = float(u['high'])
    v2_low   = float(u['low'])
    v2_body  = abs(v2_close - v2_open)
    v2_vol   = float(u.get('volume', 1))
    v2_bull  = v2_close > v2_open

    # V2 debe ser dirección contraria a V1 (la negación)
    if v1_bull == v2_bull: return None, 0

    # V2 engulfa el cuerpo de V1 (envolvente)
    v1_body_hi = max(v1_open, v1_close)
    v1_body_lo = min(v1_open, v1_close)
    v2_body_hi = max(v2_open, v2_close)
    v2_body_lo = min(v2_open, v2_close)
    if v2_body_hi < v1_body_hi - tol * 0.5: return None, 0   # V2 no engulfó V1
    if v2_body_lo > v1_body_lo + tol * 0.5: return None, 0

    # V2 tiene buen volumen
    vol_avg20 = float(u.get('vol_sma20', v2_vol))
    if vol_avg20 > 0 and v2_vol < vol_avg20 * 0.75:
        return None, 0   # V2 necesita volumen

    # RSI al cierre de V1 (usamos la barra anterior para reconstruir)
    # Usamos stoch_k de la vela anterior como proxy del estado RSI en V1
    rsi_v1 = float(p.get('rsi', 50)) if 'rsi' in df.columns else float(u.get('rsi', 50))
    rsi_v2 = float(u.get('rsi', 50))
    stk    = float(u.get('stoch_k', 50))
    stod   = float(u.get('stoch_d', 50))

    direccion  = None
    score_base = 0

    # ── VENTA: V1 alcista tocó resistencia, V2 bajista lo engulfa ─────────
    if v1_bull and not v2_bull:
        # V1 toca/penetra resistencia
        nivel_ok = any(
            (v1_body_hi >= r - tol and v1_high >= r - tol * 0.5)
            for r in resistencias
        )
        if not nivel_ok: return None, 0

        # V2 cierra CLARAMENTE por debajo de la resistencia
        res_cercana = min(resistencias, key=lambda r: abs(v1_high - r))
        if v2_close >= res_cercana - tol * 0.3:
            return None, 0   # V2 no cerró por debajo del nivel

        # RSI en sobrecompra al cierre de V1
        if rsi_v1 < 60: return None, 0

        direccion  = 'PUT'
        score_base = 30

        # Calidad del engulfing
        if v2_body > v1_body * 1.5: score_base += 15
        elif v2_body > v1_body:     score_base += 8

        # RSI extremo en V1
        if rsi_v1 >= 80:  score_base += 12
        elif rsi_v1 >= 70: score_base += 8
        elif rsi_v1 >= 65: score_base += 4

        # V1 ya tenía mecha superior (rechazo previo)
        v1_uw = v1_high - max(v1_open, v1_close)
        if v1_uw > v1_body * 0.3: score_base += 7

        # Volumen V1 bueno
        if vol_avg20 > 0 and v1_vol >= vol_avg20 * 0.90: score_base += 5

        # Stoch sobrecompra
        if stk >= 75 or rsi_v2 >= 65: score_base += 5

        # ADX muy bajo = S/R muy respetados
        if adx < 15: score_base += 8
        elif adx < 22: score_base += 4

        # A favor de régimen (bajista es mejor para venta)
        if regimen == 'BEAR': score_base += 5
        elif regimen == 'BULL': score_base -= 6

    # ── COMPRA: V1 bajista tocó soporte, V2 alcista lo engulfa ───────────
    elif not v1_bull and v2_bull:
        nivel_ok = any(
            (v1_body_lo <= s + tol and v1_low <= s + tol * 0.5)
            for s in soportes
        )
        if not nivel_ok: return None, 0

        sup_cercana = min(soportes, key=lambda s: abs(v1_low - s))
        if v2_close <= sup_cercana + tol * 0.3:
            return None, 0   # V2 no cerró por encima del nivel

        if rsi_v1 > 40: return None, 0

        direccion  = 'CALL'
        score_base = 30

        if v2_body > v1_body * 1.5: score_base += 15
        elif v2_body > v1_body:     score_base += 8

        if rsi_v1 <= 20:  score_base += 12
        elif rsi_v1 <= 30: score_base += 8
        elif rsi_v1 <= 35: score_base += 4

        v1_lw = min(v1_open, v1_close) - v1_low
        if v1_lw > v1_body * 0.3: score_base += 7

        if vol_avg20 > 0 and v1_vol >= vol_avg20 * 0.90: score_base += 5

        if stk <= 25 or rsi_v2 <= 35: score_base += 5

        if adx < 15: score_base += 8
        elif adx < 22: score_base += 4

        if regimen == 'BULL': score_base += 5
        elif regimen == 'BEAR': score_base -= 6

    if direccion is None or score_base < 46:   # umbral bajo para votar en consenso
        return None, 0

    return direccion, score_base


# ─────────────────────────────────────────────────────────────────────────────
# 10 NUEVAS ESTRATEGIAS
# ─────────────────────────────────────────────────────────────────────────────

def estrategia_macd_crossover_fast(df, regimen, asset=''):
    """
    MACD Fast Crossover: MACD(12,26,9) cruza su línea de señal
    + EMA5 vs EMA13 confirma dirección + Volume > 1.35
    """
    if len(df) < 30:
        return None, 0

    u    = df.iloc[-1]
    prev = df.iloc[-2]

    _vs    = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    macd_c = float(u.get('macd12',        0))
    macd_p = float(prev.get('macd12',     0))
    sig_c  = float(u.get('macd12_signal', 0))
    sig_p  = float(prev.get('macd12_signal', 0))

    c_series   = df['close'].astype(float)
    ema5_vals  = c_series.ewm(span=5,  adjust=False).mean().values
    ema13_vals = c_series.ewm(span=13, adjust=False).mean().values
    ema5_now   = ema5_vals[-1]
    ema13_now  = ema13_vals[-1]

    cruce_bull = (macd_p <= sig_p) and (macd_c > sig_c)
    cruce_bear = (macd_p >= sig_p) and (macd_c < sig_c)

    dir_  = None
    score = 0

    if cruce_bull and ema5_now > ema13_now:
        dir_  = 'CALL'
        score = 55
        if regimen == 'BULL':       score += 12
        elif regimen == 'SIDEWAYS': score += 5
        if macd_c > 0:              score += 8
        if vol_r >= 1.5:            score += 8
        if float(u.get('rsi', 50)) < 55: score += 5

    elif cruce_bear and ema5_now < ema13_now:
        dir_  = 'PUT'
        score = 55
        if regimen == 'BEAR':       score += 12
        elif regimen == 'SIDEWAYS': score += 5
        if macd_c < 0:              score += 8
        if vol_r >= 1.5:            score += 8
        if float(u.get('rsi', 50)) > 45: score += 5

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_rsi_extreme_rebound(df, regimen, asset=''):
    """
    RSI Extreme Rebound: RSI < 30 (sobreventa) o RSI > 70 (sobrecompra)
    + vela de confirmación fuerte + Volume > 1.35
    """
    if len(df) < 20:
        return None, 0

    u      = df.iloc[-1]
    _vs    = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    rsi     = float(u.get('rsi', 50))
    is_bull = bool(u.get('is_bull', False))
    body    = max(float(u.get('body', 0.0001)), 1e-10)
    lw      = float(u.get('lower_wick', 0))
    uw      = float(u.get('upper_wick', 0))
    atr     = max(float(u.get('atr', 0.0001)), 1e-9)

    dir_  = None
    score = 0

    if rsi < 30 and is_bull:
        dir_  = 'CALL'
        score = 52
        if rsi < 20:   score += 15
        elif rsi < 25: score += 8
        if lw >= body * 1.5:    score += 10
        if body >= atr * 0.4:   score += 8
        if regimen in ('BULL', 'SIDEWAYS'): score += 8
        if vol_r >= 1.5:        score += 6

    elif rsi > 70 and not is_bull:
        dir_  = 'PUT'
        score = 52
        if rsi > 80:   score += 15
        elif rsi > 75: score += 8
        if uw >= body * 1.5:    score += 10
        if body >= atr * 0.4:   score += 8
        if regimen in ('BEAR', 'SIDEWAYS'): score += 8
        if vol_r >= 1.5:        score += 6

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_heiken_ashi_reversal(df, regimen, asset=''):
    """
    Heikin Ashi Reversal: HA cambia de color (rojo→verde / verde→rojo)
    + EMA8 vs EMA21 confirma dirección + Volume > 1.35
    """
    if len(df) < 25:
        return None, 0

    u      = df.iloc[-1]
    _vs    = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    o_s = df['open'].astype(float)
    h_s = df['high'].astype(float)
    l_s = df['low'].astype(float)
    c_s = df['close'].astype(float)

    ha_close = (o_s + h_s + l_s + c_s) / 4.0
    ha_open  = ha_close.copy()
    ha_open.iloc[0] = (o_s.iloc[0] + c_s.iloc[0]) / 2.0
    for i in range(1, len(df)):
        ha_open.iloc[i] = (ha_open.iloc[i-1] + ha_close.iloc[i-1]) / 2.0

    ha_bull_now  = ha_close.iloc[-1] > ha_open.iloc[-1]
    ha_bull_prev = ha_close.iloc[-2] > ha_open.iloc[-2]

    cambio_bull = ha_bull_now and not ha_bull_prev
    cambio_bear = not ha_bull_now and ha_bull_prev

    if not cambio_bull and not cambio_bear:
        return None, 0

    ema8_vals  = c_s.ewm(span=8,  adjust=False).mean().values
    ema21_vals = c_s.ewm(span=21, adjust=False).mean().values
    ema8_now   = ema8_vals[-1]
    ema21_now  = ema21_vals[-1]

    dir_  = None
    score = 0

    if cambio_bull and ema8_now > ema21_now:
        dir_  = 'CALL'
        score = 55
        if ema8_now > ema21_now * 1.001: score += 8
        if regimen == 'BULL':            score += 10
        elif regimen == 'SIDEWAYS':      score += 4
        if vol_r >= 1.5:                 score += 8
        if float(u.get('rsi', 50)) < 55: score += 5

    elif cambio_bear and ema8_now < ema21_now:
        dir_  = 'PUT'
        score = 55
        if ema8_now < ema21_now * 0.999: score += 8
        if regimen == 'BEAR':            score += 10
        elif regimen == 'SIDEWAYS':      score += 4
        if vol_r >= 1.5:                 score += 8
        if float(u.get('rsi', 50)) > 45: score += 5

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_volume_spike_breakout(df, regimen, asset=''):
    """
    Volume Spike Breakout: vol > 2× promedio + cierre rompe high/low anterior + Volume > 1.35
    """
    if len(df) < 15:
        return None, 0

    u      = df.iloc[-1]
    _vs    = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))

    if not es_otc and vol_r < 2.0:
        return None, 0

    close_now = float(u['close'])
    high_prev = float(df['high'].iloc[-2])
    low_prev  = float(df['low'].iloc[-2])
    is_bull   = bool(u.get('is_bull', False))
    rsi       = float(u.get('rsi', 50))

    dir_  = None
    score = 0

    if close_now > high_prev and is_bull:
        dir_  = 'CALL'
        score = 58
        if vol_r >= 2.5:      score += 10
        if vol_r >= 3.0:      score += 8
        if regimen == 'BULL': score += 10
        elif regimen == 'SIDEWAYS': score += 4
        if rsi < 60:          score += 5

    elif close_now < low_prev and not is_bull:
        dir_  = 'PUT'
        score = 58
        if vol_r >= 2.5:      score += 10
        if vol_r >= 3.0:      score += 8
        if regimen == 'BEAR': score += 10
        elif regimen == 'SIDEWAYS': score += 4
        if rsi > 40:          score += 5

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_parabolic_sar_reversal(df, regimen, asset=''):
    """
    Parabolic SAR Reversal: SAR cambia de lado + EMA10 confirma + Volume > 1.35
    """
    if len(df) < 20:
        return None, 0

    u      = df.iloc[-1]
    _vs    = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    h_arr = df['high'].astype(float).values
    l_arr = df['low'].astype(float).values
    af0, af_step, af_max = 0.02, 0.02, 0.2
    af   = af0
    ep   = l_arr[0]
    sar  = h_arr[0]
    bull = False
    bull_arr = [bull]
    for i in range(1, len(h_arr)):
        prev_sar = sar
        if bull:
            sar = prev_sar + af * (ep - prev_sar)
            sar = min(sar, l_arr[i-1], l_arr[i-2] if i >= 2 else l_arr[i-1])
            if l_arr[i] < sar:
                bull = False; sar = ep; ep = h_arr[i]; af = af0
            else:
                if h_arr[i] > ep:
                    ep = h_arr[i]; af = min(af + af_step, af_max)
        else:
            sar = prev_sar + af * (ep - prev_sar)
            sar = max(sar, h_arr[i-1], h_arr[i-2] if i >= 2 else h_arr[i-1])
            if h_arr[i] > sar:
                bull = True; sar = ep; ep = l_arr[i]; af = af0
            else:
                if l_arr[i] < ep:
                    ep = l_arr[i]; af = min(af + af_step, af_max)
        bull_arr.append(bull)

    sar_bull_now  = bull_arr[-1]
    sar_bull_prev = bull_arr[-2]
    flip_bull = sar_bull_now and not sar_bull_prev
    flip_bear = not sar_bull_now and sar_bull_prev

    if not flip_bull and not flip_bear:
        return None, 0

    c_s       = df['close'].astype(float)
    ema10_now = float(c_s.ewm(span=10, adjust=False).mean().iloc[-1])
    close_now = float(u['close'])
    rsi       = float(u.get('rsi', 50))

    dir_  = None
    score = 0

    if flip_bull and close_now > ema10_now:
        dir_  = 'CALL'
        score = 57
        if regimen == 'BULL':       score += 12
        elif regimen == 'SIDEWAYS': score += 5
        if vol_r >= 1.5:            score += 8
        if rsi < 55:                score += 7

    elif flip_bear and close_now < ema10_now:
        dir_  = 'PUT'
        score = 57
        if regimen == 'BEAR':       score += 12
        elif regimen == 'SIDEWAYS': score += 5
        if vol_r >= 1.5:            score += 8
        if rsi > 45:                score += 7

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_ichimoku_cloud_bounce(df, regimen, asset=''):
    """
    Ichimoku Cloud Bounce: precio rebota en la nube + Kijun/Tenkan cruzan + Volume > 1.35
    """
    if len(df) < 52:
        return None, 0

    u      = df.iloc[-1]
    _vs    = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    h_s = df['high'].astype(float)
    l_s = df['low'].astype(float)
    c_s = df['close'].astype(float)

    tenkan   = (h_s.rolling(9).max()  + l_s.rolling(9).min())  / 2
    kijun    = (h_s.rolling(26).max() + l_s.rolling(26).min()) / 2
    senkou_a = ((tenkan + kijun) / 2).shift(26)
    senkou_b = ((h_s.rolling(52).max() + l_s.rolling(52).min()) / 2).shift(26)

    close_now   = float(c_s.iloc[-1])
    tenkan_now  = float(tenkan.iloc[-1])
    kijun_now   = float(kijun.iloc[-1])
    tenkan_prev = float(tenkan.iloc[-2])
    kijun_prev  = float(kijun.iloc[-2])
    sa_now = float(senkou_a.iloc[-1]) if not pd.isna(senkou_a.iloc[-1]) else 0.0
    sb_now = float(senkou_b.iloc[-1]) if not pd.isna(senkou_b.iloc[-1]) else 0.0
    cloud_top    = max(sa_now, sb_now)
    cloud_bottom = min(sa_now, sb_now)
    atr          = max(float(u.get('atr', 0.0001)), 1e-9)

    cerca_nube   = (abs(close_now - cloud_top)    < atr * 1.5 or
                    abs(close_now - cloud_bottom) < atr * 1.5)

    tk_cruce_bull = (tenkan_prev <= kijun_prev) and (tenkan_now > kijun_now)
    tk_cruce_bear = (tenkan_prev >= kijun_prev) and (tenkan_now < kijun_now)

    dir_  = None
    score = 0

    if cerca_nube and tk_cruce_bull and close_now > cloud_top:
        dir_  = 'CALL'
        score = 54
        if regimen == 'BULL':       score += 12
        elif regimen == 'SIDEWAYS': score += 5
        if vol_r >= 1.5:            score += 8
        if float(u.get('rsi', 50)) < 55: score += 6

    elif cerca_nube and tk_cruce_bear and close_now < cloud_bottom:
        dir_  = 'PUT'
        score = 54
        if regimen == 'BEAR':       score += 12
        elif regimen == 'SIDEWAYS': score += 5
        if vol_r >= 1.5:            score += 8
        if float(u.get('rsi', 50)) > 45: score += 6

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_stochastic_cross_zone(df, regimen, asset=''):
    """
    Stochastic Cross Zone: %K cruza %D en zona < 25 (CALL) o > 75 (PUT) + Volume > 1.35
    """
    if len(df) < 20:
        return None, 0

    u    = df.iloc[-1]
    prev = df.iloc[-2]
    _vs  = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    k_now  = float(u.get('stoch_k', 50))
    d_now  = float(u.get('stoch_d', 50))
    k_prev = float(prev.get('stoch_k', 50))
    d_prev = float(prev.get('stoch_d', 50))

    cruce_bull = (k_prev <= d_prev) and (k_now > d_now) and k_now < 35
    cruce_bear = (k_prev >= d_prev) and (k_now < d_now) and k_now > 65

    dir_  = None
    score = 0

    if cruce_bull:
        dir_  = 'CALL'
        score = 53
        if k_now < 25:          score += 12
        if k_now < 15:          score += 8
        if regimen in ('BULL', 'SIDEWAYS'): score += 8
        if vol_r >= 1.5:        score += 8
        if float(u.get('rsi', 50)) < 50: score += 5

    elif cruce_bear:
        dir_  = 'PUT'
        score = 53
        if k_now > 75:          score += 12
        if k_now > 85:          score += 8
        if regimen in ('BEAR', 'SIDEWAYS'): score += 8
        if vol_r >= 1.5:        score += 8
        if float(u.get('rsi', 50)) > 50: score += 5

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_pinbar_price_action(df, regimen, asset=''):
    """
    Pin Bar Price Action: pinbar alcista/bajista fuerte (wick > 3× cuerpo) + Volume > 1.35
    """
    if len(df) < 10:
        return None, 0

    u      = df.iloc[-1]
    _vs    = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    pin_bull  = int(u.get('pat_pin_bull', 0))
    pin_bear  = int(u.get('pat_pin_bear', 0))
    lw        = float(u.get('lower_wick', 0))
    uw        = float(u.get('upper_wick', 0))
    body      = max(float(u.get('body', 0.0001)), 1e-10)
    atr       = max(float(u.get('atr', 0.0001)), 1e-9)
    rsi       = float(u.get('rsi', 50))

    dir_  = None
    score = 0

    if pin_bull:
        dir_  = 'CALL'
        score = 52
        wr = lw / body
        if wr >= 4.0:   score += 12
        elif wr >= 3.0: score += 6
        if lw >= atr * 0.5: score += 8
        if rsi < 50:        score += 7
        if regimen in ('BULL', 'SIDEWAYS'): score += 8
        if vol_r >= 1.5:    score += 8

    elif pin_bear:
        dir_  = 'PUT'
        score = 52
        wr = uw / body
        if wr >= 4.0:   score += 12
        elif wr >= 3.0: score += 6
        if uw >= atr * 0.5: score += 8
        if rsi > 50:        score += 7
        if regimen in ('BEAR', 'SIDEWAYS'): score += 8
        if vol_r >= 1.5:    score += 8

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_adx_trend_strength(df, regimen, asset=''):
    """
    ADX Trend Strength: ADX > 25 + cruce DI+ sobre DI- (CALL) o DI- sobre DI+ (PUT)
    + Volume > 1.35
    """
    if len(df) < 20:
        return None, 0

    u    = df.iloc[-1]
    prev = df.iloc[-2]
    _vs  = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    adx       = float(u.get('adx', 0))
    plus_di   = float(u.get('plus_di',  0))
    minus_di  = float(u.get('minus_di', 0))
    plus_di_p = float(prev.get('plus_di',  0))
    minus_di_p= float(prev.get('minus_di', 0))

    if adx < 25:
        return None, 0

    cruce_bull = (plus_di_p <= minus_di_p) and (plus_di > minus_di)
    cruce_bear = (minus_di_p <= plus_di_p) and (minus_di > plus_di)

    dir_  = None
    score = 0

    if cruce_bull:
        dir_  = 'CALL'
        score = 54
        if adx >= 35:         score += 12
        elif adx >= 30:       score += 7
        if (plus_di - minus_di) > 5: score += 8
        if regimen == 'BULL': score += 10
        elif regimen == 'SIDEWAYS': score += 4
        if vol_r >= 1.5:      score += 8
        if float(u.get('rsi', 50)) < 55: score += 5

    elif cruce_bear:
        dir_  = 'PUT'
        score = 54
        if adx >= 35:          score += 12
        elif adx >= 30:        score += 7
        if (minus_di - plus_di) > 5: score += 8
        if regimen == 'BEAR':  score += 10
        elif regimen == 'SIDEWAYS': score += 4
        if vol_r >= 1.5:       score += 8
        if float(u.get('rsi', 50)) > 45: score += 5

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_vwap_pullback(df, regimen, asset=''):
    """
    VWAP Pullback: precio retrocede a VWAP + EMA8 cruza en dirección + Volume > 1.35
    """
    if len(df) < 20:
        return None, 0

    u      = df.iloc[-1]
    _vs    = float(df['vol_ratio'].std()) if 'vol_ratio' in df.columns else 0.0
    es_otc = _vs < 0.005
    vol_r  = float(u.get('vol_ratio', 1.0))
    if not es_otc and vol_r < 1.35:
        return None, 0

    c_s = df['close'].astype(float)
    h_s = df['high'].astype(float)
    l_s = df['low'].astype(float)
    v_s = df['volume'].astype(float) if 'volume' in df.columns else pd.Series(
        [1.0] * len(df), index=df.index)

    tp   = (h_s + l_s + c_s) / 3.0
    vwap = (tp * v_s).cumsum() / (v_s.cumsum() + 1e-10)

    vwap_now  = float(vwap.iloc[-1])
    close_now = float(u['close'])
    atr       = max(float(u.get('atr', 0.0001)), 1e-9)

    if abs(close_now - vwap_now) > atr * 1.0:
        return None, 0

    ema8_vals  = c_s.ewm(span=8, adjust=False).mean().values
    ema8_now   = ema8_vals[-1]
    ema8_prev  = ema8_vals[-2]

    cruce_bull = (ema8_prev <= vwap_now) and (ema8_now > vwap_now)
    cruce_bear = (ema8_prev >= vwap_now) and (ema8_now < vwap_now)

    dir_  = None
    score = 0

    if cruce_bull and close_now >= vwap_now:
        dir_  = 'CALL'
        score = 54
        if regimen == 'BULL':       score += 10
        elif regimen == 'SIDEWAYS': score += 4
        if vol_r >= 1.5:            score += 8
        if float(u.get('rsi', 50)) < 55: score += 7
        if bool(u.get('is_bull', False)): score += 5

    elif cruce_bear and close_now <= vwap_now:
        dir_  = 'PUT'
        score = 54
        if regimen == 'BEAR':       score += 10
        elif regimen == 'SIDEWAYS': score += 4
        if vol_r >= 1.5:            score += 8
        if float(u.get('rsi', 50)) > 45: score += 7
        if not bool(u.get('is_bull', False)): score += 5

    if not dir_ or score < MIN_SCORE_PARA_OPERAR:
        return None, 0
    return dir_, min(score, 100)


def estrategia_soporte_resistencia(df, regimen, asset=''):
    if len(df) < 20:
        return None, 0
    call_ok, _ = _precio_en_zona_sr(df, 'CALL')
    put_ok, _ = _precio_en_zona_sr(df, 'PUT')
    u = df.iloc[-1]
    close_now = float(u.get('close', 0))
    open_now = float(u.get('open', close_now))
    if call_ok and close_now >= open_now:
        return 'CALL', 62
    if put_ok and close_now <= open_now:
        return 'PUT', 62
    if call_ok:
        return 'CALL', 58
    if put_ok:
        return 'PUT', 58
    return None, 0


def estrategia_pinbar_price_action(df, regimen, asset=''):
    if len(df) < 10:
        return None, 0
    u = df.iloc[-1]
    body = max(float(u.get('body', 0)), 1e-10)
    lower_wick = float(u.get('lower_wick', 0))
    upper_wick = float(u.get('upper_wick', 0))
    if int(u.get('pat_pin_bull', 0)) and lower_wick >= body * 3.0:
        return 'CALL', min(60 + int(min(lower_wick / body, 6) * 4), 84)
    if int(u.get('pat_pin_bear', 0)) and upper_wick >= body * 3.0:
        return 'PUT', min(60 + int(min(upper_wick / body, 6) * 4), 84)
    return None, 0


def estrategia_rechazo_vela(df, regimen, asset=''):
    if len(df) < 8:
        return None, 0
    u = df.iloc[-1]
    body = max(float(u.get('body', 0)), 1e-10)
    lower_wick = float(u.get('lower_wick', 0))
    upper_wick = float(u.get('upper_wick', 0))
    close_now = float(u.get('close', 0))
    open_now = float(u.get('open', close_now))
    if lower_wick >= body * 2.0 and close_now >= open_now:
        return 'CALL', min(58 + int(min(lower_wick / body, 5) * 5), 82)
    if upper_wick >= body * 2.0 and close_now <= open_now:
        return 'PUT', min(58 + int(min(upper_wick / body, 5) * 5), 82)
    return None, 0


# ─────────────────────────────────────────────
# REGISTRO DE ESTRATEGIAS ACTIVAS
# ─────────────────────────────────────────────

ESTRATEGIAS = {
    'sop_res':      estrategia_soporte_resistencia,
    'rechazo':      estrategia_rechazo_vela,
    'pinbar':       estrategia_pinbar_price_action,
    'macd_cross':   estrategia_macd_crossover_fast,
    'rsi_rebote':   estrategia_rsi_extreme_rebound,
    'stoch_cross':  estrategia_stochastic_cross_zone,
    'adx_fuerza':   estrategia_adx_trend_strength,
    'vwap_pullback': estrategia_vwap_pullback,
    'tendencia_5m': estrategia_tendencia_5min,
}

ESTRATEGIA_NOMBRES = {
    'sop_res':     'Soporte/Resistencia',
    'pinbar':      'Pin Bar Price Action',
    'rechazo':     'Vela de Rechazo',
    'macd_cross':  'MACD Crossover',
    'rsi_rebote':  'RSI Rebote Extremo',
    'stoch_cross': 'Stochastic Cross',
    'adx_fuerza':  'ADX Fuerza Tendencial',
    'vwap_pullback': 'VWAP Pullback',
    'tendencia_5m': 'Tendencia 5M',
}

ESTRATEGIA_DURACION = {
    'sop_res': VENCIMIENTO_MINUTOS,
    'pinbar':  VENCIMIENTO_MINUTOS,
    'rechazo': VENCIMIENTO_MINUTOS,
    'macd_cross': VENCIMIENTO_MINUTOS,
    'rsi_rebote': VENCIMIENTO_MINUTOS,
    'stoch_cross': VENCIMIENTO_MINUTOS,
    'adx_fuerza': VENCIMIENTO_MINUTOS,
    'vwap_pullback': VENCIMIENTO_MINUTOS,
    'tendencia_5m': VENCIMIENTO_MINUTOS,
}


# ─────────────────────────────────────────────
# ANÁLISIS POR ACTIVO (IA INTEGRADA)
# ─────────────────────────────────────────────

def analizar_activo(api, asset, state):
    """
    Pipeline de análisis multinivel.
    Retorna dict con la señal si califica, o None si no.
    Los activos que 'casi califican' se registran en _lista_caliente.
    """
    try:
        df = obtener_velas(api, asset, n=80)
        if df is None:
            state._sin_datos_count[asset] += 1
            intentos = state._sin_datos_count[asset]
            state.add_debug(
                f"{asset}: sin velas recibidas de IQ Option ({intentos}/3)",
                "WARN",
                asset=asset,
                razon="sin_velas",
            )
            if intentos >= 3:
                _activos_exception.add(asset)
                state.add_log(
                    f"⛔ {asset} bloqueado: la API no entrega velas o no reconoce el símbolo",
                    "WARN"
                )
                state.add_debug(
                    f"{asset}: bloqueado por datos inexistentes en la API",
                    "BLOCK",
                    asset=asset,
                    razon="asset_no_reconocido",
                )
            return None
        state._sin_datos_count[asset] = 0

        df = calcular_indicadores(df)
        regimen = detectar_regimen(df)
        state.regimenes[asset] = regimen

        if not _asset_permitido(asset):
            state.add_debug(f"{asset}: descartado, activo fuera de lista permitida", "BLOCK", asset=asset)
            return None

        if not hasattr(state, 'bloqueo_asset_est'):
            state.bloqueo_asset_est = {}
        if not hasattr(state, 'ops_dia'):
            state.ops_dia = 0
        if not hasattr(state, 'max_ops_dia'):
            state.max_ops_dia = None
        if not hasattr(state, 'ops_dia_fecha'):
            state.ops_dia_fecha = None
        for _key in ESTRATEGIAS_PERMITIDAS:
            state.estrategias_activas[_key] = state.estrategias_activas.get(_key, True)
            if _key not in state.stats['por_estrategia']:
                state.stats['por_estrategia'][_key] = {'total': 0, 'ganadas': 0}

        ahora_dt   = datetime.now(ecuador)
        votos_call = []
        votos_put  = []

        for nombre, fn in ESTRATEGIAS.items():
            if not state.estrategias_activas.get(nombre, True):
                continue
            bloqueo = state.bloqueo_asset_est.get((asset, nombre), {})
            bloqueado_hasta = bloqueo.get('bloqueado_hasta')
            if bloqueado_hasta and ahora_dt < bloqueado_hasta:
                continue
            try:
                sig = inspect.signature(fn)
                if 'asset' in sig.parameters:
                    direction, score = fn(df, regimen, asset=asset)
                else:
                    direction, score = fn(df, regimen)
                if direction and score > 0:
                    if direction == 'CALL':
                        votos_call.append((nombre, score))
                    else:
                        votos_put.append((nombre, score))
            except Exception:
                pass

        score_call = sum(s for _, s in votos_call)
        score_put  = sum(s for _, s in votos_put)

        if not votos_call and not votos_put:
            state.add_debug(
                f"{asset}: sin patrón válido en las estrategias activas",
                "INFO",
                asset=asset,
                regimen=regimen,
            )
            return None

        if score_call >= score_put:
            dir_ganadora  = 'CALL'
            votos_ganador = votos_call
        else:
            dir_ganadora  = 'PUT'
            votos_ganador = votos_put

        n_acuerdo   = len(votos_ganador)
        mejor_est   = max(votos_ganador, key=lambda x: x[1])[0]
        mejor_score = max(s for _, s in votos_ganador)

        asset_base   = _asset_base(asset)
        es_volatil   = asset_base in PARES_VOLATILES

        # ── NUEVA LÓGICA: 1 estrategia es suficiente ─────────────────────────
        # Antes se requerían 2 estrategias en consenso. Ahora basta 1 siempre
        # que el score supere el umbral y TODOS los filtros duros pasen
        # (MFM, CMF, Stoch, EMA9/21 y OBV). El bonus por consenso sigue
        # premiando señales con 2 o 3 estrategias de acuerdo.

        if n_acuerdo >= 3:
            bonus_consenso  = 18
            nombres_acuerdo = "+".join(ESTRATEGIA_NOMBRES.get(n, n) for n, _ in votos_ganador[:3])
        elif n_acuerdo == 2:
            bonus_consenso  = 10
            nombres_acuerdo = "+".join(ESTRATEGIA_NOMBRES.get(n, n) for n, _ in votos_ganador[:2])
        else:
            # 1 estrategia: sin bonus de consenso, umbral unificado
            bonus_consenso  = 0
            nombres_acuerdo = f"{ESTRATEGIA_NOMBRES.get(mejor_est, mejor_est)} [+ filtros OBV/MFM/CMF/EMA]"

        umbral_efectivo = MIN_SCORE_PARA_OPERAR

        score_con_bonus = min(mejor_score + bonus_consenso, 100)

        if es_volatil:
            score_con_bonus = max(0, score_con_bonus - PENALIZACION_PAR_VOLATIL)

        if score_con_bonus >= UMBRAL_PRESENAL:
            with _scan_lock:
                state._lista_caliente[asset] = score_con_bonus
            state.diagnostico['mejor_candidato'] = {
                'asset': asset,
                'direccion': dir_ganadora,
                'score': score_con_bonus,
                'estrategias': n_acuerdo,
                'regimen': regimen,
            }

        if score_con_bonus < umbral_efectivo:
            state.add_debug(
                f"{asset}: score={score_con_bonus} menor al umbral {umbral_efectivo}",
                "WARN",
                asset=asset,
                score=score_con_bonus,
                razon="score_menor_umbral",
            )
            return None

        calidad_ok, calidad_msg, calidad_data = validar_filtro_calidad_direccional(df, dir_ganadora, asset)
        if not calidad_ok:
            state.add_debug(
                f"{asset} {dir_ganadora}: filtro de calidad bloqueó — {calidad_msg}",
                "BLOCK",
                asset=asset,
                direccion=dir_ganadora,
                score=score_con_bonus,
                razon="filtro_calidad",
            )
            return None
        score_final = min(score_con_bonus + 7, 100)
        confianza = state.ia.factor_confianza(asset, mejor_est)

        if score_final >= umbral_efectivo:
            state.add_debug(
                f"{asset} {dir_ganadora}: señal válida score={score_final}, consenso={n_acuerdo}, {calidad_msg}",
                "SIGNAL",
                asset=asset,
                direccion=dir_ganadora,
                score=score_final,
                razon="senal_valida",
            )
            return {
                'asset':              asset,
                'direccion':          dir_ganadora,
                'estrategia':         mejor_est,
                'score':              score_final,
                'fuerza':             0,
                'sostenibilidad':     0,
                'nombre_estrategia':  nombres_acuerdo,
                'regimen':            regimen,
                'confianza_ia':       round(confianza * 100, 1),
                'filtro_calidad':     calidad_msg,
                'mfm':                round(float(calidad_data.get('mfm', 0)), 2),
                'cmf':                round(float(calidad_data.get('cmf', 0)), 3),
                'duracion':           VENCIMIENTO_MINUTOS,
                'n_estrategias':      n_acuerdo,
                'es_volatil':         es_volatil,
                'premium_unica':      n_acuerdo == 1,
                'unica_con_flujo':    n_acuerdo == 1,
            }
        return None
    except Exception as e:
        state.add_debug(f"{asset}: error analizando activo — {e}", "ERROR", asset=asset)
        return None


# ─────────────────────────────────────────────
# SELECCIÓN DE LA MEJOR SEÑAL (ESCANEO PARALELO)
# ─────────────────────────────────────────────

from concurrent.futures import ThreadPoolExecutor, as_completed
import threading as _threading

_scan_lock        = _threading.Lock()
_activos_exception = set()   # Activos que fallaron con excepción en la API → no reintentar

def _analizar_wrapper(args):
    api, asset, state, progreso_ref = args
    try:
        resultado = analizar_activo(api, asset, state)
        with _scan_lock:
            progreso_ref[0] += 1
            state.scan_progreso = progreso_ref[0]
        return resultado
    except Exception:
        with _scan_lock:
            progreso_ref[0] += 1
            state.scan_progreso = progreso_ref[0]
        return None


def _refresh_activos_si_necesario(api, state):
    """Refresca la lista de activos disponibles cada 30 min."""
    ahora_ts = time.time()
    if not state.activos_disponibles or (ahora_ts - state._ultimo_refresh_activos) > 1800:
        activos_nuevos = obtener_activos_disponibles(api)
        if activos_nuevos:
            state.activos_disponibles = [a for a in activos_nuevos if _asset_permitido(a)]
            state._ultimo_refresh_activos = ahora_ts
            state.add_log(f"Activos actualizados: {len(state.activos_disponibles)} permitidos", "INFO")


def scan_siguiente_lote(api, state):
    """
    Escanea el siguiente lote de LOTE_ESCANEO activos del ciclo rotativo.

    - 25 activos por lote, ordenados por win-rate histórico
    - Los activos que alcanzan pre-señal (UMBRAL_PRESENAL) se guardan en
      _lista_caliente para ser re-chequeados cada PAUSA_CALIENTES segundos
    - Los calientes son manejados por _rechequear_calientes, no aquí
    """
    _refresh_activos_si_necesario(api, state)

    activos = state.activos_disponibles
    if not activos:
        state.add_debug("No hay activos disponibles cargados desde IQ Option", "WARN")
        return

    # ── Lote rotativo ordenado por win-rate (sin activos bloqueados) ─────
    candidatos = [
        a for a in activos
        if state.puede_operar_asset(a) and a not in _activos_exception
    ]
    candidatos.sort(key=lambda a: state.ia.win_rate_asset(a), reverse=True)
    if not candidatos:
        state.add_debug("No hay candidatos operables: activos bloqueados, en límite horario o sin datos", "WARN")
        return

    total = len(candidatos)
    state.scan_total = total

    inicio = state._cursor_activos % total
    fin    = min(inicio + LOTE_ESCANEO, total)
    lote   = candidatos[inicio:fin]
    state.diagnostico['ultimo_lote'] = f"Escaneando {inicio+1}-{min(inicio + LOTE_ESCANEO, total)}/{total}: {', '.join(lote[:5])}{'...' if len(lote) > 5 else ''}"

    # Avanzar cursor; si llegó al final, reiniciar desde 0
    state._cursor_activos = fin if fin < total else 0

    progreso_ref = [0]
    args_list    = [(api, a, state, progreso_ref) for a in lote]
    MAX_WORKERS  = min(MAX_SCAN_WORKERS, len(lote))

    nuevos = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(_analizar_wrapper, args) for args in args_list]
        for future in as_completed(futures):
            resultado = future.result()
            if resultado:
                nuevos.append(resultado)

    with _scan_lock:
        state._candidatos_cache.extend(nuevos)
        state._candidatos_cache.sort(key=lambda x: x['score'], reverse=True)
        state._candidatos_cache = state._candidatos_cache[:20]

    # Log siempre para visibilidad del operador
    rango_fin = min(inicio + LOTE_ESCANEO, total)
    calientes_encontrados = len(state._lista_caliente)
    if nuevos:
        mejor = max(nuevos, key=lambda x: x['score'])
        state.diagnostico['mejor_candidato'] = {
            'asset': mejor['asset'],
            'direccion': mejor['direccion'],
            'score': mejor['score'],
            'estrategias': mejor.get('n_estrategias', 0),
            'regimen': mejor.get('regimen', '?'),
        }
        state.add_log(
            f"Lote {inicio+1}-{rango_fin}/{total} → {len(nuevos)} señal(es) "
            f"| Mejor: {mejor['asset']} {mejor['direccion']} "
            f"score={mejor['score']} fuerza={mejor.get('fuerza',0)} "
            f"| 🔥 Calientes: {calientes_encontrados}",
            "INFO"
        )
        state.add_debug(
            f"Lote {inicio+1}-{rango_fin}: {len(nuevos)} señal(es) listas; mejor {mejor['asset']} {mejor['direccion']} score={mejor['score']}",
            "SIGNAL",
        )
    else:
        state.add_log(
            f"Lote {inicio+1}-{rango_fin}/{total} → sin señales "
            f"| 🔥 Calientes: {calientes_encontrados}",
            "INFO"
        )
        state.add_debug(
            f"Lote {inicio+1}-{rango_fin}: sin señales finales; calientes={calientes_encontrados}",
            "INFO",
        )


# ─────────────────────────────────────────────
# VALIDACIÓN DE MARTINGALA
# ─────────────────────────────────────────────

def _validar_martingala(api, asset, direccion, state):
    """
    Evalúa si el mercado actual aún justifica la operación de recuperación.

    El martingala NO debe dispararse si la tendencia se revirtió desde
    la operación original. Analiza 30 velas frescas y verifica:
      · MFM confirma flujo a favor de la dirección
      · ADL confirma acumulación/distribución a favor
      · Precio sigue en soporte para CALL o resistencia para PUT

    Retorna (ok: bool, razon: str)
    """
    try:
        df = obtener_velas(api, asset, n=35, forzar_fresco=True)
        if df is None or len(df) < 20:
            return False, "sin datos suficientes para validar"

        df = calcular_indicadores(df)
        regimen = detectar_regimen(df)
        u = df.iloc[-1]

        calidad_ok, calidad_msg, _ = validar_filtro_calidad_direccional(df, direccion, asset)
        if not calidad_ok:
            return False, calidad_msg

        return True, f"OK — {calidad_msg}, regimen={regimen}"

    except Exception as e:
        return False, f"error validación: {e}"


# ─────────────────────────────────────────────
# EJECUCIÓN DE TRADE
# ─────────────────────────────────────────────

def ejecutar_trade(api, asset, direccion, monto, estrategia, state, duracion=VENCIMIENTO_MINUTOS, es_martingala=False):
    # ── Activo en blacklist de excepciones de sesión → no intentar ────────
    if asset in _activos_exception:
        state.add_log(f"⛔ {asset} bloqueado (falló anteriormente) — omitiendo", "WARN")
        state.add_debug(f"{asset}: operación omitida porque el activo está bloqueado", "BLOCK", asset=asset)
        return False

    if not hasattr(state, 'ops_dia'):
        state.ops_dia = 0
    if not hasattr(state, 'max_ops_dia'):
        state.max_ops_dia = None
    if not hasattr(state, 'ops_dia_fecha'):
        state.ops_dia_fecha = None

    # ── Límite de operaciones simultáneas ─────────────────────────────────
    if len(state.active_trades) >= MAX_CONCURRENT_TRADES:
        state.add_log(
            f"⛔ Límite concurrente alcanzado ({MAX_CONCURRENT_TRADES} ops activas) — "
            f"{asset} descartado",
            "WARN"
        )
        state.add_debug(
            f"{asset}: no se opera porque ya hay {len(state.active_trades)}/{MAX_CONCURRENT_TRADES} operaciones activas",
            "BLOCK",
            asset=asset,
        )
        return False

    # ── No duplicar el mismo activo ────────────────────────────────────────
    if any(t['asset'] == asset for t in state.active_trades):
        state.add_debug(f"{asset}: no se duplica operación en el mismo activo", "BLOCK", asset=asset)
        return False

    opcion = "call" if direccion == "CALL" else "put"

    # ── Aplicar martingala si está activa ─────────────────────────────────
    monto_real = monto
    if state.martingala_activa and state.martingala_nivel == 1:
        monto_real = round(state.martingala_monto_base * 2.5, 2)
        state.add_log(
            f"⚡ MARTINGALA Nv1: operando ${monto_real:.2f} "
            f"(base ${state.martingala_monto_base:.2f} × 2.5 — recupera pérdida + ganancia)",
            "WARN"
        )

    try:
        tipo_op = getattr(state, 'tipo_operacion', 'binaria')
        if tipo_op == 'digital':
            state.add_debug(
                f"{asset}: intentando operar DIGITAL; si IQ Option no entrega digital, puede fallar",
                "WARN",
                asset=asset,
            )
            success, order_id = api.buy_digital_spot(asset, monto_real, opcion, duracion)
        else:
            success, order_id = api.buy(monto_real, asset, opcion, duracion)
        if success:
            entrada     = datetime.now(ecuador)
            entrada_str = entrada.strftime("%H:%M:%S")
            venc_str    = (entrada + timedelta(minutes=duracion)).strftime("%H:%M:%S")
            trade = {
                'asset':             asset,
                'direccion':         direccion,
                'monto':             monto_real,
                'entrada':           entrada_str,
                'vencimiento':       venc_str,
                'order_id':          order_id,
                'estado':            'PENDIENTE',
                'estrategia':        estrategia,
                'nombre_estrategia': ESTRATEGIA_NOMBRES.get(estrategia, estrategia),
                'ganancia':          0.0,
                'fecha':             entrada.strftime("%d/%m %H:%M"),
                'regimen':           state.regimenes.get(asset, '?'),
                '_ts_creado':        time.time(),
                '_es_martingala':    state.martingala_activa,
                '_duracion':         duracion,
            }
            state.active_trades.append(trade)
            state.registrar_op(asset)
            state.ops_dia += 1
            tag = " [MARTINGALA]" if state.martingala_activa else ""
            dur_tag = f" [5MIN]" if duracion == 5 else ""
            state.add_log(
                f"OPERACION{tag}{dur_tag}: {asset} {direccion} ${monto_real:.2f} | "
                f"{ESTRATEGIA_NOMBRES.get(estrategia)} | Exp:{duracion}min | ID:{order_id}",
                "TRADE"
            )
            state.add_debug(
                f"Operación enviada: {asset} {direccion} ${monto_real:.2f} {tipo_op} ID:{order_id}",
                "TRADE",
                asset=asset,
            )
            return True
        else:
            msg = str(order_id) if order_id else "error"
            if "time" in msg.lower() or "purchasing" in msg.lower():
                state.add_log(f"{asset}: tiempo vencido, operacion descartada", "WARN")
            else:
                state.add_log(f"Error al operar {asset}: {msg}", "ERROR")
            state.add_debug(f"{asset}: IQ Option rechazó la orden — {msg}", "ERROR", asset=asset)
            return False
    except Exception as e:
        state.add_log(f"Excepcion en trade ({asset}): {e} — bloqueando activo", "ERROR")
        state.add_debug(f"{asset}: excepción enviando orden — {e}", "ERROR", asset=asset)
        _activos_exception.add(asset)
        return False


def _hilo_verificar_resultado(api, state, trade=None):
    """
    Hilo daemon independiente que espera y verifica el resultado de UNA operación.
    El loop principal NUNCA se bloquea — este hilo opera en paralelo.
    Timeout dinámico según la duración del trade (1min = 90s, 5min = 370s).
    Se pueden correr múltiples instancias simultáneas (una por operación activa).
    """
    if trade is None:
        trade = state.current_trade
    if not trade:
        return

    duracion_min = trade.get('_duracion', 1)
    max_espera   = duracion_min * 65 + 25   # 90s para 1min, 350s para 5min
    inicio       = time.time()
    consultado   = False

    while state.running and trade in state.active_trades and (time.time() - inicio) < max_espera:
        try:
            resultado = verificar_resultado_trade(api, state, trade)
            if resultado:
                consultado = True
                break
        except Exception as e:
            state.add_log(f"Verificador resultado: {e}", "WARN")
        time.sleep(1.0)

    # Timeout: si el trade sigue pendiente, liberarlo
    if trade in state.active_trades and not consultado:
        trade['estado']   = 'DEVUELTA'
        trade['ganancia'] = 0.0
        state.add_trade(trade)
        if trade in state.active_trades:
            state.active_trades.remove(trade)
        state.add_log(
            f"Trade {trade['asset']} liberado por timeout del verificador",
            "WARN"
        )


def verificar_resultado_trade(api, state, trade=None):
    if trade is None:
        trade = state.current_trade
    if trade is None or trade not in state.active_trades:
        return False

    try:
        # Calcular tiempo transcurrido desde que se abrió el trade
        ahora = datetime.now(ecuador)
        ts_creado = trade.get('_ts_creado', time.time() - 120)
        segundos_desde_apertura = time.time() - ts_creado

        # Timeout dinámico basado en la duración del trade
        duracion_trade = trade.get('_duracion', 1)
        timeout_seg    = duracion_trade * 60 + 30  # 90s para 1min, 330s para 5min
        if segundos_desde_apertura > timeout_seg:
            state.add_log(
                f"Trade {trade['asset']} timeout "
                f"(>{timeout_seg}s, dur={duracion_trade}min) → DEVUELTA",
                "WARN"
            )
            trade['estado']  = 'DEVUELTA'
            trade['ganancia'] = 0.0
            state.add_trade(trade)
            if trade in state.active_trades:
                state.active_trades.remove(trade)
            return True

        # Esperar a que expire antes de consultar
        venc_time = datetime.strptime(trade['vencimiento'], "%H:%M:%S").time()
        venc_dt   = datetime.combine(ahora.date(), venc_time)
        if venc_dt.replace(tzinfo=None) < ahora.replace(tzinfo=None):
            venc_dt += timedelta(days=1)
        if ahora.replace(tzinfo=None) < venc_dt.replace(tzinfo=None) - timedelta(seconds=2):
            return False

        resultado = api.check_win_v4(trade['order_id'])
        if resultado is not None:
            if isinstance(resultado, (list, tuple)) and len(resultado) >= 2:
                estado, ganancia = resultado[0], float(resultado[1])
            elif isinstance(resultado, str):
                estado, ganancia = resultado, 0.0
            else:
                estado, ganancia = str(resultado), 0.0

            if estado in ('win', 'Win', 'WIN'):
                trade['estado']   = 'GANADA'
                trade['ganancia'] = ganancia
                state.saldo += ganancia
                if state.martingala_activa:
                    state.add_log(
                        f"⚡ MARTINGALA GANADA: {trade['asset']} +${ganancia:.2f} | "
                        f"Recuperado ${state.martingala_monto_base:.2f} → volviendo a base",
                        "WIN"
                    )
                else:
                    state.add_log(
                        f"GANADA: {trade['asset']} {trade['direccion']} +${ganancia:.2f}",
                        "WIN"
                    )
                # Siempre resetear martingala al ganar
                state.martingala_activa     = False
                state.martingala_nivel      = 0
                state.martingala_monto_base = 0.0
                state.perdidas_consecutivas = 0
                # Resetear racha de pérdidas del activo+estrategia
                clave = (trade['asset'], trade.get('estrategia', ''))
                if clave in state.bloqueo_asset_est:
                    state.bloqueo_asset_est[clave]['racha'] = 0
                    state.bloqueo_asset_est[clave]['bloqueado_hasta'] = None

            elif estado in ('loose', 'loss', 'Loose', 'LOSE', 'Loss'):
                trade['estado']   = 'PERDIDA'
                trade['ganancia'] = -trade['monto']
                state.saldo -= trade['monto']
                # Nota: perdidas_consecutivas y pausa_protectora los maneja add_trade()

                # ── Racha de pérdidas por activo+estrategia (spec: bloqueo 1h si ≥2) ──
                clave = (trade['asset'], trade.get('estrategia', ''))
                entrada_bloqueo = state.bloqueo_asset_est.get(clave, {'racha': 0, 'bloqueado_hasta': None})
                entrada_bloqueo['racha'] = entrada_bloqueo.get('racha', 0) + 1
                if entrada_bloqueo['racha'] >= 2:
                    entrada_bloqueo['bloqueado_hasta'] = datetime.now(ecuador) + timedelta(hours=1)
                    state.add_log(
                        f"⛔ {trade['asset']} [{ESTRATEGIA_NOMBRES.get(trade.get('estrategia',''), '')}] "
                        f"bloqueado 1h (2 pérdidas consecutivas)",
                        "WARN"
                    )
                state.bloqueo_asset_est[clave] = entrada_bloqueo

                if state.martingala_activa:
                    state.add_log(
                        f"⚡ MARTINGALA Nv1 PERDIDA: {trade['asset']} -${trade['monto']:.2f} | "
                        f"Reset completo — Nv2 eliminado",
                        "LOSS"
                    )
                    state.martingala_activa     = False
                    state.martingala_nivel      = 0
                    state.martingala_monto_base = 0.0
                    state.martingala_pendiente  = None
                else:
                    # Primera pérdida: activar martingala nivel 1
                    monto_base     = trade['monto']
                    monto_recupera = round(monto_base * 2.5, 2)
                    state.martingala_activa     = True
                    state.martingala_nivel      = 1
                    state.martingala_monto_base = monto_base

                    ahora_dt   = datetime.now(ecuador)
                    sig_minuto = (ahora_dt + timedelta(minutes=1)).replace(
                        second=0, microsecond=0
                    )

                    state.add_log(
                        f"PERDIDA: {trade['asset']} {trade['direccion']} -${monto_base:.2f} | "
                        f"⚡ MARTINGALA Nv1 preparada → disparará entre s59-s01 en {sig_minuto.strftime('%H:%M:%S')} "
                        f"(${monto_recupera:.2f} = 2.5×)",
                        "LOSS"
                    )

                    state.martingala_pendiente = {
                        'asset':        trade['asset'],
                        'direccion':    trade['direccion'],
                        'estrategia':   trade.get('estrategia', ''),
                        'duracion':     trade.get('_duracion', VENCIMIENTO_MINUTOS),
                        'no_antes_de':  sig_minuto,   # esperar inicio siguiente vela
                    }

            else:
                trade['estado']   = 'DEVUELTA'
                trade['ganancia'] = 0.0
                # Devuelta: no activa ni cancela martingala
                state.add_log(f"DEVUELTA: {trade['asset']} {trade['direccion']}", "INFO")

            state.add_trade(trade)
            # Remover de la lista de activos; la martingala (si aplica) se añade
            # como un trade nuevo e independiente — no depende de este slot.
            if trade in state.active_trades:
                state.active_trades.remove(trade)
            return True

        # resultado es None: no disponible aún, seguir esperando
        return False
    except Exception as e:
        state.add_log(f"Error verificando resultado: {e}", "WARN")
        return False


# ─────────────────────────────────────────────
# MOTOR PRINCIPAL CON AUTO-RECONEXIÓN
# ─────────────────────────────────────────────

def intentar_reconexion(state):
    """Intenta reconectar a IQ Option usando las credenciales almacenadas."""
    if not hasattr(state, '_email') or not state._email:
        return False
    try:
        from iqoptionapi.stable_api import IQ_Option
        api = IQ_Option(state._email, state._password)
        check, reason = api.connect()
        if check:
            api.change_balance(state.tipo_cuenta)
            saldo = api.get_balance()
            state.saldo = float(saldo) if saldo else state.saldo
            state.api = api
            state.add_log("Reconexion exitosa", "INFO")
            return True
        state.add_log(f"Reconexion fallida: {reason}", "ERROR")
        return False
    except Exception as e:
        state.add_log(f"Error reconectando: {e}", "ERROR")
        return False


def _verificar_senal_fresca(api, señal, state):
    """
    Re-verificación pre-ejecución — última línea de defensa antes de operar.

    Bloqueos duros (cancelan siempre):
      - Estrella fugaz / pin bear en la última vela completada → no CALL
      - Martillo / pin bull en la última vela completada → no PUT
      - Volumen colapsado (<0.5× media) → mercado muerto, no operar

    Bloqueo suave (cancela solo con convicción clara):
      - IA ve dirección opuesta con score ≥ 82 Y ≥ 12pts más que señal original
    """
    try:
        df = obtener_velas(api, señal['asset'], n=40, forzar_fresco=True)
        if df is None or len(df) < 22:
            return True   # sin datos frescos → confiar en el análisis previo
        df  = calcular_indicadores(df)
        u   = df.iloc[-1]
        dir_senal = señal['direccion']

        calidad_ok, calidad_msg, _ = validar_filtro_calidad_direccional(df, dir_senal, señal['asset'])
        if not calidad_ok:
            state.add_log(
                f"🚫 BLOQUEADA: {señal['asset']} {dir_senal} — {calidad_msg}",
                "WARN"
            )
            state.add_debug(
                f"{señal['asset']} {dir_senal}: bloqueada justo antes de operar — {calidad_msg}",
                "BLOCK",
                asset=señal['asset'],
                direccion=dir_senal,
                score=señal.get('score', 0),
                razon="verificacion_fresca",
            )
            return False

        state.add_debug(
            f"{señal['asset']} {dir_senal}: verificación fresca OK — {calidad_msg}",
            "SIGNAL",
            asset=señal['asset'],
            direccion=dir_senal,
            score=señal.get('score', 0),
        )
        return True
    except Exception:
        return True   # ante cualquier error, confiar en el análisis previo


def _hilo_scanner(api, state):
    """
    Hilo daemon de escaneo controlado — 25 activos cada 30 segundos.

    Ciclo de trabajo:
      1. Escanea lote de 25 activos (blocking OK, es daemon thread)
      2. Espera 30 s; durante esa espera re-chequea lista caliente cada 5 s
         → si hay pre-señales, las confirma y agrega al cache sin esperar
      3. Si hay trade activo, solo re-chequea calientes (sin lote nuevo)
      4. Al terminar el ciclo, escanea el siguiente lote de 25

    API calls estimadas: ~25 velas/lote × 2/min = muy por debajo del límite.
    """
    while state.running:
        try:
            if not api or not state.running:
                time.sleep(1)
                continue

            if not state.activos_disponibles:
                _refresh_activos_si_necesario(api, state)
                time.sleep(2)
                continue

            # ── PASO 1: Escanear lote regular de activos (siempre, concurrente) ─
            # Con hasta 4 trades simultáneos, el scanner NUNCA se detiene.
            scan_siguiente_lote(api, state)

            # ── PASO 2: Esperar 30s re-chequeando calientes cada 5s ──────────
            elapsed = 0
            while elapsed < PAUSA_ENTRE_LOTES and state.running:
                time.sleep(PAUSA_CALIENTES)
                elapsed += PAUSA_CALIENTES
                _rechequear_calientes(api, state)

        except Exception as e:
            state.add_log(f"Error en scanner: {e}", "ERROR")
            time.sleep(3)


def _rechequear_calientes(api, state):
    """
    Re-analiza activos en lista caliente (pre-señal) con máxima prioridad.
    Se llama cada PAUSA_CALIENTES segundos entre lotes regulares.
    Solo ejecuta si hay activos calientes y no hay trade activo.
    """
    with _scan_lock:
        calientes = [a for a in state._lista_caliente.keys() if a not in _activos_exception]

    if not calientes:
        return

    state.add_log(
        f"🔥 Pre-señal detectada — vigilando {len(calientes)} activo(s): "
        f"{', '.join(calientes[:4])}{'...' if len(calientes) > 4 else ''}",
        "INFO"
    )

    hot_args    = [(api, a, state, [0]) for a in calientes]
    hot_workers = min(MAX_SCAN_WORKERS, len(calientes))
    nuevos      = []

    with ThreadPoolExecutor(max_workers=hot_workers) as executor:
        futures = [executor.submit(_analizar_wrapper, args) for args in hot_args]
        for future in as_completed(futures):
            r = future.result()
            if r:
                nuevos.append(r)

    if nuevos:
        with _scan_lock:
            state._candidatos_cache.extend(nuevos)
            state._candidatos_cache.sort(key=lambda x: x['score'], reverse=True)
            state._candidatos_cache = state._candidatos_cache[:20]
        mejor = max(nuevos, key=lambda x: x['score'])
        state.add_log(
            f"🔥 Pre-señal CONFIRMADA → {mejor['asset']} "
            f"{mejor['direccion']} score={mejor['score']} "
            f"| {mejor['nombre_estrategia']}",
            "SIGNAL"
        )


def bot_engine(state):
    """
    Motor NeuroTrader Pro v6 — Arquitectura de dos hilos:

      ┌──────────────────────────────────────────────────────────────────┐
      │  HILO SCANNER (daemon): escanea activos continuamente en segundo │
      │  plano, acumula señales en state._candidatos_cache               │
      │                                                                   │
      │  HILO PRINCIPAL (este): solo lee la caché, verifica y ejecuta.   │
      │  NUNCA llama scan directamente — no bloquea jamás.               │
      │                                                                   │
      │  Entrada precisa: ventana s59-s01 con verificación fresca        │
      └──────────────────────────────────────────────────────────────────┘
    """
    import threading as _t

    state.add_log(
        "NeuroTrader Pro v6 — Scanner independiente | IA 22F + IA Pro Cinética",
        "INFO"
    )

    ultimo_minuto_operado = -1
    intentos_reconexion   = 0
    MAX_INTENTOS_RECONEX  = 5
    _ultimo_log_min       = -1   # evitar spam "sin señal"

    # ── Lanzar scanner en hilo daemon propio ──────────────────────────────
    hilo_scan = _t.Thread(
        target=_hilo_scanner,
        args=(state.api, state),
        daemon=True,
        name="neuro-scanner"
    )
    hilo_scan.start()
    state.add_log("Hilo scanner iniciado — analizando activos...", "INFO")

    # ── Helper para ejecutar señal y lanzar verificador de resultado ───────
    def _disparar_señal(señal):
        """Valida límites concurrentes, ejecuta y lanza hilo verificador propio."""
        # No operar el mismo activo si ya hay trade activo sobre él
        if any(t['asset'] == señal['asset'] for t in state.active_trades):
            state.add_debug(f"{señal['asset']}: señal no disparada, activo ya tiene operación activa", "BLOCK")
            return False
        # Límite máximo de operaciones simultáneas
        if len(state.active_trades) >= MAX_CONCURRENT_TRADES:
            state.add_debug("Señal no disparada: límite de operaciones simultáneas lleno", "BLOCK")
            return False
        ahora_ent = datetime.now(ecuador)
        dur = señal.get('duracion', VENCIMIENTO_MINUTOS)
        tipo_tag = " [DIGITAL]" if getattr(state, 'tipo_operacion', 'binaria') == 'digital' else ""
        dur_tag  = " [5MIN]" if dur == 5 else ""
        n_est = señal.get('n_estrategias', 1)
        consenso_tag = f" ⚡×{n_est}" if n_est >= 2 else ""
        state.add_log(
            f"▶ ENTRADA{tipo_tag}{dur_tag}{consenso_tag} s{ahora_ent.second} — "
            f"{señal['asset']} {señal['direccion']} "
            f"| Score:{señal['score']} "
            f"| Fuerza:{señal.get('fuerza',0)} "
            f"| IA:{señal['confianza_ia']}% "
            f"| {señal['nombre_estrategia']} "
            f"| {señal['regimen']}"
            f"| [{len(state.active_trades)+1}/{MAX_CONCURRENT_TRADES}]",
            "SIGNAL"
        )
        ok = ejecutar_trade(
            state.api, señal['asset'], señal['direccion'],
            state.monto, señal['estrategia'], state, duracion=dur
        )
        if ok:
            # Obtener el trade recién añadido (último de la lista)
            nuevo_trade = state.active_trades[-1] if state.active_trades else None
            hilo_v = _t.Thread(
                target=_hilo_verificar_resultado,
                args=(state.api, state, nuevo_trade),
                daemon=True, name=f"verificador-{señal['asset']}"
            )
            hilo_v.start()
        return ok

    while state.running:
        try:
            if not state.api:
                time.sleep(0.5)
                continue

            # ── Verificar conexión (ligero) ────────────────────────────────
            try:
                conectado = state.api.check_connect()
            except Exception:
                conectado = False

            if not conectado:
                intentos_reconexion += 1
                state.add_log(
                    f"Conexion perdida. Intento {intentos_reconexion}/{MAX_INTENTOS_RECONEX}...",
                    "WARN"
                )
                if intentos_reconexion <= MAX_INTENTOS_RECONEX:
                    time.sleep(3)
                    if intentar_reconexion(state):
                        intentos_reconexion = 0
                    continue
                else:
                    state.add_log("No se pudo reconectar. Deteniendo bot.", "ERROR")
                    state.running = False
                    break

            intentos_reconexion = 0

            ahora         = datetime.now(ecuador)
            segundo       = ahora.second
            minuto_actual = ahora.minute

            # ── Limpiar cache en segundo 2 — DESPUÉS de la ventana s59-s01 ──
            # Flujo correcto:
            #   s59-s01: ejecutar usando señales del scan previo
            #   s02: limpiar cache → scanner rellena durante el resto del minuto
            if 2 <= segundo <= 4 and minuto_actual != state._ultimo_ciclo_min:
                with _scan_lock:
                    state._candidatos_cache = []
                    state._cursor_activos   = 0
                    state._lista_caliente   = {}
                state._ultimo_ciclo_min = minuto_actual
                ts_ahora = time.time()
                claves_exp = [
                    a for a, (ts, _) in list(_velas_cache.items())
                    if ts_ahora - ts > 90
                ]
                for a in claves_exp:
                    _velas_cache.pop(a, None)
                state.add_log(
                    f"⏱ Minuto {minuto_actual:02d} — cache limpiado tras s59-s01, "
                    f"{len(state.activos_disponibles)} activos en análisis",
                    "INFO"
                )

            # ── Martingala pendiente: disparar al inicio de la siguiente vela ──
            # Siempre espera al inicio del siguiente minuto (no_antes_de) y luego
            # valida las condiciones de mercado antes de ejecutar.
            en_ventana_entrada = segundo >= VENTANA_ENTRADA_INICIO_SEG or segundo <= VENTANA_ENTRADA_FIN_SEG
            if (len(state.active_trades) < MAX_CONCURRENT_TRADES and
                    getattr(state, 'martingala_pendiente', None) and
                    en_ventana_entrada):
                pend    = state.martingala_pendiente
                ahora_n = datetime.now(ecuador)

                # Esperar hasta el segundo indicado (inicio de la siguiente vela)
                no_antes = pend.get('no_antes_de', ahora_n)
                if ahora_n < no_antes:
                    # Aún no es momento — seguir esperando
                    time.sleep(0.1)
                    continue

                # ── Validar condiciones antes de disparar ──────────────────
                state.add_log(
                    f"⚡ MARTINGALA: validando condiciones para "
                    f"{pend['asset']} {pend['direccion']}…",
                    "WARN"
                )
                ok_val, razon_val = _validar_martingala(
                    state.api, pend['asset'], pend['direccion'], state
                )

                state.martingala_pendiente = None  # consumir en ambos casos

                if not ok_val:
                    # Mercado cambió — cancelar recuperación
                    state.add_log(
                        f"⚡ MARTINGALA CANCELADA: {pend['asset']} — {razon_val}",
                        "WARN"
                    )
                    state.martingala_activa     = False
                    state.martingala_nivel      = 0
                    state.martingala_monto_base = 0.0
                    time.sleep(0.1)
                    continue

                # Condiciones válidas → ejecutar
                _mult_nv = 2.5
                _monto_nv = round(state.martingala_monto_base * _mult_nv, 2)
                state.add_log(
                    f"⚡ MARTINGALA Nv{state.martingala_nivel} → {pend['asset']} {pend['direccion']} "
                    f"${_monto_nv:.2f} (×{_mult_nv}) | {razon_val}",
                    "WARN"
                )
                ok_pend = ejecutar_trade(
                    state.api,
                    pend['asset'], pend['direccion'],
                    state.monto,
                    pend.get('estrategia', ''),
                    state,
                    duracion=pend.get('duracion', VENCIMIENTO_MINUTOS),
                    es_martingala=True
                )
                if ok_pend:
                    trade_mp = state.active_trades[-1] if state.active_trades else None
                    hilo_mp = _t.Thread(
                        target=_hilo_verificar_resultado,
                        args=(state.api, state, trade_mp),
                        daemon=True, name=f"verificador-martingala-{pend['asset']}"
                    )
                    hilo_mp.start()
                time.sleep(0.1)
                continue

            # ── Pausa protectora ───────────────────────────────────────────
            if state.pausa_hasta:
                if datetime.now(ecuador) < state.pausa_hasta:
                    diff = int(
                        (state.pausa_hasta - datetime.now(ecuador)).total_seconds()
                    )
                    if diff % 30 == 0:   # log cada 30s para no saturar
                        state.add_log(
                            f"Pausa protectora — reanuda en {diff//60}m {diff%60}s",
                            "WARN"
                        )
                    time.sleep(5)
                    continue
                else:
                    state.pausa_hasta = None
                    state.perdidas_consecutivas = 0
                    state.add_log("Pausa terminada. Operaciones reanudadas.", "INFO")

            # ── Activos no cargados aún ────────────────────────────────────
            if not state.activos_disponibles:
                time.sleep(0.5)
                continue

            en_ventana_op = en_ventana_entrada

            if minuto_actual != ultimo_minuto_operado and en_ventana_op:
                ultimo_minuto_operado = minuto_actual

                with _scan_lock:
                    cache_snap = [c for c in state._candidatos_cache
                                  if c.get('estrategia', '') in ESTRATEGIAS_PERMITIDAS]
                state.add_debug(
                    f"Ventana de entrada s{segundo:02d} ({VENTANA_ENTRADA_INICIO_SEG}-59 / 00-{VENTANA_ENTRADA_FIN_SEG}): {len(cache_snap)} candidato(s) en caché",
                    "INFO",
                )

                if cache_snap:
                    top = sorted(cache_snap, key=lambda x: x['score'], reverse=True)
                    slots = MAX_CONCURRENT_TRADES - len(state.active_trades)
                    disparadas     = 0
                    bloqueadas_vf  = 0   # bloqueadas por _verificar_senal_fresca
                    sin_score      = 0   # descartadas por score bajo
                    for candidato in top[:max(slots, 3)]:
                        if candidato['score'] < MIN_SCORE_PARA_OPERAR:
                            sin_score += 1
                            break
                        if disparadas >= slots:
                            break
                        if _verificar_senal_fresca(state.api, candidato, state):
                            state.señal_actual = candidato
                            if _disparar_señal(candidato):
                                disparadas += 1
                        else:
                            bloqueadas_vf += 1

                    if disparadas == 0 and minuto_actual != _ultimo_log_min:
                        state.señal_actual = None
                        if top:
                            top_s = top[0]['score']
                            top_a = top[0]['asset']
                            if sin_score:
                                state.add_log(
                                    f"Min {minuto_actual:02d} — score máx={top_s} ({top_a}) "
                                    f"< umbral {MIN_SCORE_PARA_OPERAR} — sin señal",
                                    "WARN"
                                )
                            elif bloqueadas_vf:
                                state.add_log(
                                    f"Min {minuto_actual:02d} — {bloqueadas_vf} señal(es) bloqueadas "
                                    f"por verificación pre-trade (vela adversa / IA contradice)",
                                    "WARN"
                                )
                                state.add_debug(
                                    f"Min {minuto_actual:02d}: {bloqueadas_vf} señal(es) no pasaron la verificación fresca",
                                    "BLOCK",
                                )
                            else:
                                state.add_log(
                                    f"Min {minuto_actual:02d} — candidato {top_a} score={top_s} "
                                    f"rechazado por límite concurrente o activo en uso",
                                    "WARN"
                                )
                                state.add_debug(
                                    f"Min {minuto_actual:02d}: candidato rechazado por límite concurrente o activo en uso",
                                    "BLOCK",
                                )
                        _ultimo_log_min = minuto_actual
                else:
                    state.add_debug(
                        f"Min {minuto_actual:02d}: llegó la ventana s59-s01 sin candidatos listos",
                        "WARN",
                    )

            time.sleep(0.15)   # loop muy rápido y no bloqueante

        except Exception as e:
            state.add_log(f"Error en motor principal: {e}", "ERROR")
            time.sleep(2)

    state.add_log("Motor detenido", "INFO")
